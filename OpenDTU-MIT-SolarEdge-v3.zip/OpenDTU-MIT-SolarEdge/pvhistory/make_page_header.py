#!/usr/bin/env python3
"""Regenerates include/PvHistoryPage.h from pvhistory/history.html"""
import pathlib
root = pathlib.Path(__file__).resolve().parent.parent
html = (root / "pvhistory" / "history.html").read_text(encoding="utf-8")
assert ")PVH\"" not in html
out = ("// SPDX-License-Identifier: GPL-2.0-or-later\n"
       "// Generated from pvhistory/history.html by pvhistory/make_page_header.py - do not edit\n"
       "#pragma once\n\n"
       "static const char PV_HISTORY_PAGE[] = R\"PVH(" + html + ")PVH\";\n")
(root / "include" / "PvHistoryPage.h").write_text(out, encoding="utf-8")
print("PvHistoryPage.h: %d bytes of HTML" % len(html.encode("utf-8")))
