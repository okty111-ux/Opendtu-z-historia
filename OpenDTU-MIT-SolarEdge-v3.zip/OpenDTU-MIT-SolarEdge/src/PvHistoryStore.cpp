// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Persistent PV production statistics (portable part, POSIX file API).
 */
#include "PvHistoryStore.h"
#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <dirent.h>
#include <sys/stat.h>

static constexpr size_t MIN_RESERVE_BYTES = 48 * 1024;
static constexpr size_t KEEP_SAMPLE_FILES = 2; // never delete the newest sample days
static constexpr size_t KEEP_DAY_FILES = 1; // never delete the newest month

void PvHistoryStore::init(const std::string& basePath, SizeFn totalFn, SizeFn usedFn)
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    _base = basePath;
    _totalFn = totalFn;
    _usedFn = usedFn;
    ensureDirs();
}

void PvHistoryStore::ensureDirs()
{
    mkdir(dir().c_str(), 0775);
    mkdir((dir() + "/s").c_str(), 0775);
    mkdir((dir() + "/d").c_str(), 0775);
}

std::string PvHistoryStore::samplePath(uint32_t date) const
{
    char buf[32];
    snprintf(buf, sizeof(buf), "/s/%08u.bin", static_cast<unsigned>(date));
    return dir() + buf;
}

std::string PvHistoryStore::dayPath(uint32_t month) const
{
    char buf[32];
    snprintf(buf, sizeof(buf), "/d/%06u.bin", static_cast<unsigned>(month));
    return dir() + buf;
}

uint32_t PvHistoryStore::localDate(uint32_t ts)
{
    time_t t = ts;
    struct tm tm;
    localtime_r(&t, &tm);
    return (tm.tm_year + 1900) * 10000 + (tm.tm_mon + 1) * 100 + tm.tm_mday;
}

size_t PvHistoryStore::freeBytes() const
{
    if (!_totalFn || !_usedFn) {
        return SIZE_MAX;
    }
    const size_t total = _totalFn();
    const size_t used = _usedFn();
    return used >= total ? 0 : total - used;
}

size_t PvHistoryStore::reserveBytes() const
{
    const size_t pct = totalBytes() / 8; // 12.5 % of the file system stays free
    return std::max(MIN_RESERVE_BYTES, pct);
}

std::vector<uint32_t> PvHistoryStore::listNumbers(const std::string& d, size_t digits)
{
    std::vector<uint32_t> out;
    DIR* dp = opendir(d.c_str());
    if (dp == nullptr) {
        return out;
    }
    struct dirent* e;
    while ((e = readdir(dp)) != nullptr) {
        const char* name = e->d_name;
        // VFS may return the full path on some implementations - use the basename
        const char* slash = strrchr(name, '/');
        if (slash != nullptr) {
            name = slash + 1;
        }
        if (strlen(name) != digits + 4 || strcmp(name + digits, ".bin") != 0) {
            continue;
        }
        bool ok = true;
        for (size_t i = 0; i < digits; i++) {
            if (name[i] < '0' || name[i] > '9') {
                ok = false;
                break;
            }
        }
        if (ok) {
            out.push_back(static_cast<uint32_t>(strtoul(name, nullptr, 10)));
        }
    }
    closedir(dp);
    std::sort(out.begin(), out.end());
    return out;
}

std::vector<uint32_t> PvHistoryStore::listSampleDates()
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    return listNumbers(dir() + "/s", 8);
}

std::vector<uint32_t> PvHistoryStore::listDayMonths()
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    return listNumbers(dir() + "/d", 6);
}

template <typename T>
bool PvHistoryStore::readFile(const std::string& path, std::vector<T>& out)
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    out.clear();
    FILE* f = fopen(path.c_str(), "rb");
    if (f == nullptr) {
        return false;
    }
    T rec;
    while (fread(&rec, sizeof(T), 1, f) == 1) {
        out.push_back(rec);
    }
    fclose(f);
    return true;
}

bool PvHistoryStore::appendSample(const HistSample& s, uint32_t localDate)
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    enforceRetention();
    FILE* f = fopen(samplePath(localDate).c_str(), "ab");
    if (f == nullptr) {
        ensureDirs();
        f = fopen(samplePath(localDate).c_str(), "ab");
        if (f == nullptr) {
            return false;
        }
    }
    const bool ok = fwrite(&s, sizeof(s), 1, f) == 1;
    fclose(f);
    return ok;
}

bool PvHistoryStore::appendDay(const HistDay& d)
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    enforceRetention();
    const std::string path = dayPath(d.date / 100);

    // Replace an existing record of the same date (e.g. after a crash), keep order
    std::vector<HistDay> days;
    readFile(path, days);
    bool replaced = false;
    for (auto& r : days) {
        if (r.date == d.date) {
            r = d;
            replaced = true;
        }
    }
    if (!replaced) {
        days.push_back(d);
        std::stable_sort(days.begin(), days.end(), [](const HistDay& a, const HistDay& b) { return a.date < b.date; });
    }

    const std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (f == nullptr) {
        ensureDirs();
        f = fopen(tmp.c_str(), "wb");
        if (f == nullptr) {
            return false;
        }
    }
    const bool ok = days.empty() || fwrite(days.data(), sizeof(HistDay), days.size(), f) == days.size();
    fclose(f);
    if (!ok) {
        remove(tmp.c_str());
        return false;
    }
    if (rename(tmp.c_str(), path.c_str()) != 0) {
        remove(path.c_str());
        return rename(tmp.c_str(), path.c_str()) == 0;
    }
    return true;
}

bool PvHistoryStore::loadState(HistState& st)
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    FILE* f = fopen((dir() + "/state.bin").c_str(), "rb");
    if (f == nullptr) {
        return false;
    }
    HistState tmp;
    const bool ok = fread(&tmp, sizeof(tmp), 1, f) == 1;
    fclose(f);
    if (!ok || tmp.magic != HIST_STATE_MAGIC) {
        return false;
    }
    st = tmp;
    return true;
}

bool PvHistoryStore::saveState(const HistState& st)
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    const std::string path = dir() + "/state.bin";
    const std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (f == nullptr) {
        ensureDirs();
        f = fopen(tmp.c_str(), "wb");
        if (f == nullptr) {
            return false;
        }
    }
    const bool ok = fwrite(&st, sizeof(st), 1, f) == 1;
    fclose(f);
    if (!ok) {
        remove(tmp.c_str());
        return false;
    }
    if (rename(tmp.c_str(), path.c_str()) != 0) {
        remove(path.c_str());
        return rename(tmp.c_str(), path.c_str()) == 0;
    }
    return true;
}

bool PvHistoryStore::deleteOldestSampleFile(uint32_t)
{
    auto dates = listNumbers(dir() + "/s", 8);
    if (dates.size() <= KEEP_SAMPLE_FILES) {
        return false;
    }
    return remove(samplePath(dates.front()).c_str()) == 0;
}

bool PvHistoryStore::deleteOldestDayFile()
{
    auto months = listNumbers(dir() + "/d", 6);
    if (months.size() <= KEEP_DAY_FILES) {
        return false;
    }
    return remove(dayPath(months.front()).c_str()) == 0;
}

void PvHistoryStore::enforceRetention()
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    const size_t reserve = reserveBytes();
    // Samples are removed first; daily summaries are tiny and kept as long as possible.
    for (int guard = 0; guard < 4000 && freeBytes() < reserve; guard++) {
        if (deleteOldestSampleFile(0)) {
            continue;
        }
        if (deleteOldestDayFile()) {
            continue;
        }
        break;
    }
}

void PvHistoryStore::clearAll()
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    for (auto d : listNumbers(dir() + "/s", 8)) {
        remove(samplePath(d).c_str());
    }
    for (auto m : listNumbers(dir() + "/d", 6)) {
        remove(dayPath(m).c_str());
    }
}

uint32_t PvHistoryStore::oldestSampleDate()
{
    auto d = listSampleDates();
    return d.empty() ? 0 : d.front();
}

uint32_t PvHistoryStore::oldestDayDate()
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    auto months = listNumbers(dir() + "/d", 6);
    std::vector<HistDay> days;
    for (auto m : months) {
        if (readFile(dayPath(m), days) && !days.empty()) {
            return days.front().date;
        }
    }
    return 0;
}

size_t PvHistoryStore::dayRecordCount()
{
    std::lock_guard<std::recursive_mutex> lock(_mutex);
    size_t n = 0;
    for (auto m : listNumbers(dir() + "/d", 6)) {
        struct stat st;
        if (stat(dayPath(m).c_str(), &st) == 0) {
            n += st.st_size / sizeof(HistDay);
        }
    }
    return n;
}

std::vector<uint32_t> PvHistoryStore::sampleDatesForRange(uint32_t fromTs, uint32_t toTs)
{
    const uint32_t dFrom = localDate(fromTs);
    const uint32_t dTo = localDate(toTs);
    std::vector<uint32_t> out;
    for (auto d : listSampleDates()) {
        if (d >= dFrom && d <= dTo) {
            out.push_back(d);
        }
    }
    return out;
}

// ---------------------------------------------------------------------------

PvHistoryStore::SampleCursor::SampleCursor(PvHistoryStore& store, uint32_t fromTs, uint32_t toTs, std::vector<uint32_t> dates)
    : _store(store)
    , _from(fromTs)
    , _to(toTs)
    , _dates(std::move(dates))
{
}

bool PvHistoryStore::SampleCursor::next(HistSample& out)
{
    while (true) {
        while (_bufPos < _buf.size()) {
            const HistSample& s = _buf[_bufPos++];
            if (s.ts >= _from && s.ts <= _to) {
                out = s;
                return true;
            }
        }
        if (_idx >= _dates.size()) {
            return false;
        }
        _store.readFile(_store.samplePath(_dates[_idx++]), _buf);
        _bufPos = 0;
    }
}

PvHistoryStore::DayCursor::DayCursor(PvHistoryStore& store, uint32_t fromDate, uint32_t toDate)
    : _store(store)
    , _from(fromDate)
    , _to(toDate)
{
    for (auto m : store.listDayMonths()) {
        if (m >= fromDate / 100 && m <= toDate / 100) {
            _months.push_back(m);
        }
    }
}

bool PvHistoryStore::DayCursor::next(HistDay& out)
{
    while (true) {
        while (_bufPos < _buf.size()) {
            const HistDay& d = _buf[_bufPos++];
            if (d.date >= _from && d.date <= _to) {
                out = d;
                return true;
            }
        }
        if (_idx >= _months.size()) {
            return false;
        }
        _store.readFile(_store.dayPath(_months[_idx++]), _buf);
        _bufPos = 0;
    }
}
