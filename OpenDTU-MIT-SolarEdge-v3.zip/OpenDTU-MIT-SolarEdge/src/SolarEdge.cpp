// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * SolarEdge inverter reader (SunSpec over Modbus TCP or Modbus RTU / RS485)
 */
#include "SolarEdge.h"
#include "NetworkSettings.h"
#include "PvDisplay.h"
#include "PvPins.h"
#include <ArduinoJson.h>
#include <LittleFS.h>
#include <ctime>

#undef TAG
static const char* TAG = "solaredge";

#define SOLAREDGE_CONFIG_FILE "/solaredge.json"
static constexpr uint32_t TCP_RESPONSE_TIMEOUT_MS = 3000;
static constexpr uint32_t RTU_RESPONSE_TIMEOUT_MS = 1000;
static constexpr uint32_t CONNECT_TIMEOUT_MS = 3000;
static constexpr uint32_t ONLINE_TIMEOUT_MS = 60000;

static const uint32_t ALLOWED_BAUD[] = { 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200 };

SolarEdgeClass SolarEdge;

void SolarEdgeClass::init(Scheduler&)
{
    loadConfig();
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _snap.enabled = _cfg.enabled;
    }
    // Core 0, low priority: I/O only, results are handed over via _mutex
    xTaskCreatePinnedToCore(taskEntry, "solaredge", 6144, this, 1, &_task, 0);
    ESP_LOGI(TAG, "SolarEdge reader started (%s, unit %u)", _cfg.transport == SolarEdgeTransport::Rtu ? "RS485" : _cfg.host, _cfg.unitId);
}

SolarEdgeConfig SolarEdgeClass::getConfig()
{
    std::lock_guard<std::mutex> lock(_mutex);
    return _cfg;
}

bool SolarEdgeClass::setConfig(const SolarEdgeConfig& cfg)
{
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _cfg = cfg;
        _snap.enabled = cfg.enabled;
        _snap.common = SunSpec::Common();
        _snap.lastUpdateMs = 0;
        _snap.lastError[0] = 0;
    }
    _reconnect = true;
    return saveConfig();
}

SolarEdgeSnapshot SolarEdgeClass::getSnapshot()
{
    std::lock_guard<std::mutex> lock(_mutex);
    SolarEdgeSnapshot s = _snap;
    s.online = s.enabled && s.lastUpdateMs != 0 && (millis() - s.lastUpdateMs) < ONLINE_TIMEOUT_MS;
    return s;
}

String SolarEdgeClass::validateRtu(const SolarEdgeConfig& cfg)
{
    bool baudOk = false;
    for (auto b : ALLOWED_BAUD) {
        baudOk |= (b == cfg.baud);
    }
    if (!baudOk) {
        return "Nieobsługiwana prędkość RS485";
    }
    if (cfg.parity != 'N' && cfg.parity != 'E' && cfg.parity != 'O') {
        return "Niepoprawna parzystość";
    }
    if (cfg.rxPin < 0 || cfg.txPin < 0) {
        return "Ustaw piny RX i TX dla RS485";
    }
    const int pins[3] = { cfg.rxPin, cfg.txPin, cfg.dePin };
    const bool outputs[3] = { false, true, true };
    const PvDisplayConfig dc = PvDisplay.getConfig();
    const int disp[5] = { dc.clk, dc.mosi, dc.cs, dc.dc, dc.rst };
    return PvPins::checkSet(pins, 3, outputs, disp, dc.enabled ? 5 : 0, "wyświetlacz");
}

static SolarEdgeTransport transportFromString(const char* s)
{
    return (s != nullptr && strcmp(s, "rtu") == 0) ? SolarEdgeTransport::Rtu : SolarEdgeTransport::Tcp;
}

bool SolarEdgeClass::loadConfig()
{
    File f = LittleFS.open(SOLAREDGE_CONFIG_FILE, "r", false);
    if (!f) {
        ESP_LOGI(TAG, "No %s, using defaults", SOLAREDGE_CONFIG_FILE);
        return false;
    }
    JsonDocument doc;
    const DeserializationError err = deserializeJson(doc, f);
    f.close();
    if (err) {
        ESP_LOGW(TAG, "Failed to parse %s: %s", SOLAREDGE_CONFIG_FILE, err.c_str());
        return false;
    }
    std::lock_guard<std::mutex> lock(_mutex);
    _cfg.enabled = doc["enabled"] | _cfg.enabled;
    _cfg.transport = transportFromString(doc["transport"] | "tcp");
    strlcpy(_cfg.host, doc["host"] | _cfg.host, sizeof(_cfg.host));
    _cfg.port = doc["port"] | _cfg.port;
    _cfg.unitId = doc["unit"] | _cfg.unitId;
    strlcpy(_cfg.name, doc["name"] | _cfg.name, sizeof(_cfg.name));
    _cfg.intervalSec = constrain(static_cast<int>(doc["interval"] | _cfg.intervalSec), 5, 300);
    _cfg.baud = doc["baud"] | _cfg.baud;
    const char* par = doc["parity"] | "N";
    _cfg.parity = par[0] ? par[0] : 'N';
    _cfg.rxPin = doc["rx"] | _cfg.rxPin;
    _cfg.txPin = doc["tx"] | _cfg.txPin;
    _cfg.dePin = doc["de"] | _cfg.dePin;
    return true;
}

bool SolarEdgeClass::saveConfig()
{
    JsonDocument doc;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        doc["enabled"] = _cfg.enabled;
        doc["transport"] = _cfg.transport == SolarEdgeTransport::Rtu ? "rtu" : "tcp";
        doc["host"] = _cfg.host;
        doc["port"] = _cfg.port;
        doc["unit"] = _cfg.unitId;
        doc["name"] = _cfg.name;
        doc["interval"] = _cfg.intervalSec;
        doc["baud"] = _cfg.baud;
        const char par[2] = { _cfg.parity, 0 };
        doc["parity"] = par;
        doc["rx"] = _cfg.rxPin;
        doc["tx"] = _cfg.txPin;
        doc["de"] = _cfg.dePin;
    }
    File f = LittleFS.open(SOLAREDGE_CONFIG_FILE, "w");
    if (!f) {
        return false;
    }
    const bool ok = serializeJson(doc, f) > 0;
    f.close();
    return ok;
}

void SolarEdgeClass::setError(const char* msg)
{
    std::lock_guard<std::mutex> lock(_mutex);
    if (strcmp(_snap.lastError, msg) != 0) {
        ESP_LOGW(TAG, "%s", msg);
    }
    strlcpy(_snap.lastError, msg, sizeof(_snap.lastError));
}

// ---------------------------------------------------------------------------

bool SolarEdgeClass::openTransport(const SolarEdgeConfig& cfg)
{
    if (cfg.transport == SolarEdgeTransport::Tcp) {
        if (!_client.connect(cfg.host, cfg.port, CONNECT_TIMEOUT_MS)) {
            char msg[64];
            snprintf(msg, sizeof(msg), "Brak połączenia z %s:%u", cfg.host, cfg.port);
            setError(msg);
            return false;
        }
        _client.setNoDelay(true);
        ESP_LOGI(TAG, "Connected to %s:%u", cfg.host, cfg.port);
        return true;
    }

    const String err = validateRtu(cfg);
    if (err.length() > 0) {
        setError(err.c_str());
        return false;
    }
    const uint32_t mode = cfg.parity == 'E' ? SERIAL_8E1 : (cfg.parity == 'O' ? SERIAL_8O1 : SERIAL_8N1);
    _serial.setRxBufferSize(512);
    _serial.begin(cfg.baud, mode, cfg.rxPin, cfg.txPin);
    if (cfg.dePin >= 0) {
        pinMode(cfg.dePin, OUTPUT);
        digitalWrite(cfg.dePin, LOW); // receive
    }
    _openDePin = cfg.dePin;
    _serialOpen = true;
    ESP_LOGI(TAG, "RS485 open: %u 8%c1, RX %d, TX %d, DE %d", cfg.baud, cfg.parity, cfg.rxPin, cfg.txPin, cfg.dePin);
    return true;
}

void SolarEdgeClass::closeTransport()
{
    if (_client.connected()) {
        _client.stop();
    }
    if (_serialOpen) {
        _serial.end();
        if (_openDePin >= 0) {
            pinMode(_openDePin, INPUT);
        }
        _serialOpen = false;
        _openDePin = -1;
    }
}

bool SolarEdgeClass::readRegisters(const SolarEdgeConfig& cfg, uint16_t addr, uint16_t count, uint16_t* regs)
{
    return cfg.transport == SolarEdgeTransport::Rtu ? readRtu(cfg, addr, count, regs) : readTcp(cfg, addr, count, regs);
}

bool SolarEdgeClass::readTcp(const SolarEdgeConfig& cfg, uint16_t addr, uint16_t count, uint16_t* regs)
{
    // drop stale bytes from an earlier, timed out request
    while (_client.available()) {
        _client.read();
    }

    const uint16_t tid = _transId++;
    uint8_t req[12];
    SunSpec::buildReadRequest(req, tid, cfg.unitId, addr, count);
    if (_client.write(req, sizeof(req)) != sizeof(req)) {
        setError("Błąd wysyłania zapytania Modbus");
        return false;
    }

    const size_t expected = 9 + 2 * count;
    uint8_t buf[9 + 2 * 125];
    size_t len = 0;
    const uint32_t start = millis();
    while (millis() - start < TCP_RESPONSE_TIMEOUT_MS) {
        const int avail = _client.available();
        if (avail > 0) {
            const int n = _client.read(buf + len, std::min(static_cast<size_t>(avail), sizeof(buf) - len));
            if (n > 0) {
                len += n;
            }
            uint8_t exc = 0;
            const auto res = SunSpec::parseReadResponse(buf, len, tid, count, regs, &exc);
            if (res == SunSpec::ParseResult::Ok) {
                return true;
            }
            if (res == SunSpec::ParseResult::Exception) {
                char msg[64];
                snprintf(msg, sizeof(msg), "Modbus wyjątek %u (adres %u)", exc, addr);
                setError(msg);
                return false;
            }
            if (res != SunSpec::ParseResult::Incomplete || len >= expected) {
                setError("Niepoprawna odpowiedź Modbus");
                return false;
            }
        } else if (!_client.connected()) {
            setError("Połączenie Modbus zerwane");
            return false;
        } else {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
    }
    setError("Brak odpowiedzi Modbus TCP (timeout)");
    return false;
}

bool SolarEdgeClass::readRtu(const SolarEdgeConfig& cfg, uint16_t addr, uint16_t count, uint16_t* regs)
{
    // inter-frame gap (> 3.5 characters) and drop line noise
    vTaskDelay(pdMS_TO_TICKS(5 + 40000 / cfg.baud));
    while (_serial.available()) {
        _serial.read();
    }

    uint8_t req[8];
    SunSpec::buildRtuRequest(req, cfg.unitId, addr, count);
    if (cfg.dePin >= 0) {
        digitalWrite(cfg.dePin, HIGH);
    }
    _serial.write(req, sizeof(req));
    _serial.flush(); // wait until the last bit left the UART
    if (cfg.dePin >= 0) {
        digitalWrite(cfg.dePin, LOW);
    }

    const size_t expected = 5 + 2 * count;
    uint8_t buf[8 + 5 + 2 * 125];
    size_t len = 0;
    const uint32_t start = millis();
    while (millis() - start < RTU_RESPONSE_TIMEOUT_MS) {
        bool got = false;
        while (_serial.available() && len < sizeof(buf)) {
            buf[len++] = static_cast<uint8_t>(_serial.read());
            got = true;
        }
        if (got) {
            uint8_t exc = 0;
            const auto res = SunSpec::parseRtuResponse(buf, len, cfg.unitId, count, regs, &exc, req);
            switch (res) {
            case SunSpec::RtuResult::Ok:
                return true;
            case SunSpec::RtuResult::Incomplete:
                break;
            case SunSpec::RtuResult::Exception: {
                char msg[64];
                snprintf(msg, sizeof(msg), "Modbus wyjątek %u (adres %u)", exc, addr);
                setError(msg);
                return false;
            }
            case SunSpec::RtuResult::WrongDevice:
                setError("Odpowiedź z innego adresu Modbus");
                return false;
            case SunSpec::RtuResult::BadCrc:
                if (len >= expected + 8) {
                    setError("Błąd CRC RS485 (zakłócenia / zła prędkość?)");
                    return false;
                }
                break; // could still be our echo + partial frame
            case SunSpec::RtuResult::WrongLength:
                setError("Niepoprawna długość odpowiedzi RS485");
                return false;
            }
        } else {
            vTaskDelay(pdMS_TO_TICKS(5));
        }
    }
    if (len == 0) {
        char msg[64];
        snprintf(msg, sizeof(msg), "Brak odpowiedzi RS485 (ID %u, %u bd)", cfg.unitId, static_cast<unsigned>(cfg.baud));
        setError(msg);
    } else {
        setError("Niepełna odpowiedź RS485 (timeout)");
    }
    return false;
}

// ---------------------------------------------------------------------------

void SolarEdgeClass::taskEntry(void* arg)
{
    static_cast<SolarEdgeClass*>(arg)->taskLoop();
}

void SolarEdgeClass::taskLoop()
{
    uint16_t regs[SunSpec::REG_COMMON_COUNT];

    for (;;) {
        const SolarEdgeConfig cfg = getConfig();
        const bool tcp = cfg.transport == SolarEdgeTransport::Tcp;

        if (!cfg.enabled) {
            closeTransport();
            vTaskDelay(pdMS_TO_TICKS(2000));
            continue;
        }

        if (tcp && !NetworkSettings.isConnected()) {
            setError("Brak połączenia sieciowego");
            vTaskDelay(pdMS_TO_TICKS(2000));
            continue;
        }

        const bool open = tcp ? _client.connected() : _serialOpen;
        if (_reconnect || !open) {
            closeTransport();
            _reconnect = false;
            if (!openTransport(cfg)) {
                vTaskDelay(pdMS_TO_TICKS(std::max<uint32_t>(cfg.intervalSec, 15) * 1000));
                continue;
            }
        }

        bool needCommon;
        {
            std::lock_guard<std::mutex> lock(_mutex);
            needCommon = !_snap.common.valid;
        }
        if (needCommon && readRegisters(cfg, SunSpec::REG_COMMON_START, SunSpec::REG_COMMON_COUNT, regs)) {
            const SunSpec::Common c = SunSpec::decodeCommon(regs);
            std::lock_guard<std::mutex> lock(_mutex);
            _snap.common = c;
            if (c.valid) {
                ESP_LOGI(TAG, "Found %s %s, SN %s, FW %s", c.manufacturer, c.model, c.serial, c.version);
            }
        }

        if (readRegisters(cfg, SunSpec::REG_INVERTER_START, SunSpec::REG_INVERTER_COUNT, regs)) {
            const SunSpec::Inverter inv = SunSpec::decodeInverter(regs);
            if (inv.valid) {
                std::lock_guard<std::mutex> lock(_mutex);
                _snap.inv = inv;
                _snap.lastUpdateMs = millis();
                if (_snap.lastUpdateMs == 0) {
                    _snap.lastUpdateMs = 1;
                }
                _snap.lastUpdateEpoch = time(nullptr);
                _snap.lastError[0] = 0;
            } else {
                setError("Nieobsługiwany model SunSpec (oczekiwano 101-103)");
            }
        } else if (tcp) {
            closeTransport(); // reconnect on the next round
        }

        vTaskDelay(pdMS_TO_TICKS(cfg.intervalSec * 1000));
    }
}
