// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Page rendering for the 256x64 status display (u8g2 C API only).
 */
#include "PvDisplayRender.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>

namespace {

const uint8_t* const F_SMALL = u8g2_font_helvR08_te;
const uint8_t* const F_SMALL_B = u8g2_font_helvB08_te;
const uint8_t* const F_UNIT = u8g2_font_helvB12_te;
const uint8_t* const F_BIG = u8g2_font_logisoso28_tn;
const uint8_t* const F_BIG2 = u8g2_font_logisoso24_tn;
const uint8_t* const F_CLOCK = u8g2_font_logisoso32_tn;

constexpr int W = 256;

struct Ctx {
    u8g2_t* g;
    int sx;
    int sy;

    int text(int x, int y, const uint8_t* font, const char* s)
    {
        u8g2_SetFont(g, font);
        return u8g2_DrawUTF8(g, x + sx, y + sy, s);
    }
    int width(const uint8_t* font, const char* s)
    {
        u8g2_SetFont(g, font);
        return u8g2_GetUTF8Width(g, s);
    }
    void right(int xr, int y, const uint8_t* font, const char* s) { text(xr - width(font, s), y, font, s); }
    void center(int xc, int y, const uint8_t* font, const char* s) { text(xc - width(font, s) / 2, y, font, s); }
    void hline(int x, int y, int w) { u8g2_DrawHLine(g, x + sx, y + sy, w); }
    void vline(int x, int y, int h) { u8g2_DrawVLine(g, x + sx, y + sy, h); }
    void box(int x, int y, int w, int h)
    {
        if (w > 0 && h > 0) {
            u8g2_DrawBox(g, x + sx, y + sy, w, h);
        }
    }
    void frame(int x, int y, int w, int h) { u8g2_DrawFrame(g, x + sx, y + sy, w, h); }
    void pixel(int x, int y) { u8g2_DrawPixel(g, x + sx, y + sy); }
};

// Number with decimal comma; "-" for NaN
void fmt(char* buf, size_t n, double v, int dec, const char* unit = "")
{
    if (std::isnan(v)) {
        snprintf(buf, n, "-%s", unit);
        return;
    }
    snprintf(buf, n, "%.*f%s", dec, v, unit);
    for (char* p = buf; *p; p++) {
        if (*p == '.') {
            *p = ',';
        }
    }
}

void fmtKwh(char* buf, size_t n, double kwh, const char* unit = " kWh")
{
    const int dec = kwh < 100 ? 2 : (kwh < 1000 ? 1 : 0);
    fmt(buf, n, kwh, dec, unit);
}

// Big power value + unit, returns right edge
int bigPower(Ctx& c, int x, int y, const uint8_t* font, float w)
{
    char num[16];
    const char* unit = "W";
    if (std::isnan(w)) {
        snprintf(num, sizeof(num), "-");
    } else if (w >= 10000) {
        fmt(num, sizeof(num), w / 1000.0, w >= 100000 ? 0 : 1);
        unit = "kW";
    } else {
        snprintf(num, sizeof(num), "%.0f", std::round(std::max(0.0f, w)));
    }
    const int nw = c.text(x, y, font, num);
    return x + nw + 3 + c.text(x + nw + 3, y, F_UNIT, unit);
}

void clockText(char* buf, size_t n, uint32_t ts)
{
    if (ts == 0) {
        snprintf(buf, n, "--:--");
        return;
    }
    time_t t = ts;
    struct tm tm;
    localtime_r(&t, &tm);
    snprintf(buf, n, "%02d:%02d", tm.tm_hour, tm.tm_min);
}

void header(Ctx& c, const PvDisplayData& d, const char* title, const char* status, uint8_t pageNo, uint8_t pageCount, const char* rightExtra = nullptr)
{
    char buf[32];
    char clk[8];
    clockText(clk, sizeof(clk), d.now);
    if (pageCount > 1) {
        snprintf(buf, sizeof(buf), "%s  %u/%u", clk, pageNo + 1, pageCount);
    } else {
        snprintf(buf, sizeof(buf), "%s", clk);
    }
    int rightStart = W - c.width(F_SMALL, buf);
    c.text(rightStart, 8, F_SMALL, buf);
    if (rightExtra != nullptr && rightExtra[0]) {
        rightStart -= c.width(F_SMALL, rightExtra) + 8;
        c.text(rightStart, 8, F_SMALL, rightExtra);
    }

    const int x = c.text(0, 8, F_SMALL_B, title);
    if (status != nullptr && status[0] && x + 5 + c.width(F_SMALL, status) < rightStart - 4) {
        c.text(x + 5, 8, F_SMALL, status);
    }
    c.hline(0, 11, W);
}

void offlineStatus(char* buf, size_t n, uint32_t lastSeen)
{
    if (lastSeen == 0) {
        snprintf(buf, n, "offline");
        return;
    }
    char clk[8];
    clockText(clk, sizeof(clk), lastSeen);
    snprintf(buf, n, "offline, odczyt %s", clk);
}

// "String 3" -> "S3", other names are shortened to fit
void shortName(Ctx& c, const char* name, uint8_t idx, int maxW, char* out, size_t n)
{
    if (name[0] == 0 || strncmp(name, "String ", 7) == 0) {
        snprintf(out, n, "S%u", idx + 1);
        return;
    }
    snprintf(out, n, "%s", name);
    while (strlen(out) > 1 && c.width(F_SMALL, out) > maxW) {
        size_t l = strlen(out) - 1; // drop the last UTF-8 character
        while (l > 0 && (static_cast<uint8_t>(out[l]) & 0xC0) == 0x80) {
            l--;
        }
        out[l] = 0;
    }
}

// Word-wrapped text, at most maxLines lines of 10 px
void wrapText(Ctx& c, int x, int y, int maxW, int maxLines, const char* text)
{
    char line[64] = {};
    const char* p = text;
    for (int ln = 0; ln < maxLines && *p; ln++) {
        line[0] = 0;
        const char* lastFit = p;
        const char* q = p;
        while (true) {
            const char* sp = strchr(q, ' ');
            const size_t len = sp ? static_cast<size_t>(sp - p) : strlen(p);
            if (len >= sizeof(line)) {
                break;
            }
            char tmp[64];
            memcpy(tmp, p, len);
            tmp[len] = 0;
            if (c.width(F_SMALL, tmp) > maxW && lastFit != p) {
                break;
            }
            memcpy(line, tmp, len + 1);
            lastFit = sp ? sp + 1 : p + len;
            if (!sp) {
                break;
            }
            q = sp + 1;
        }
        if (lastFit == p) { // single word too long - cut it
            snprintf(line, sizeof(line), "%s", p);
            lastFit = p + strlen(p);
        }
        c.text(x, y + ln * 10, F_SMALL, line);
        p = lastFit;
    }
}

void row(Ctx& c, int x0, int x1, int y, const char* label, const char* value, const uint8_t* vfont = F_SMALL)
{
    c.text(x0, y, F_SMALL, label);
    c.right(x1, y, vfont, value);
}

// ---------------------------------------------------------------------------

void pageSummary(Ctx& c, const PvDisplayData& d, uint8_t no, uint8_t cnt)
{
    header(c, d, "Produkcja PV", nullptr, no, cnt);
    c.text(0, 22, F_SMALL, "Moc teraz");
    bigPower(c, 0, 53, F_BIG, d.totalPac);
    char buf[40];
    char v[24];
    fmtKwh(v, sizeof(v), d.totalTodayWh / 1000.0);
    snprintf(buf, sizeof(buf), "Dziś %s", v);
    c.text(0, 64, F_SMALL_B, buf);

    c.vline(140, 15, 49);
    const int x0 = 146;
    int y = 22;
    for (uint8_t i = 0; i < d.nInv && i < PVD_MAX_INV; i++) {
        const PvDisplayInv& inv = d.inv[i];
        if (inv.reachable) {
            fmt(v, sizeof(v), inv.pac, 0, " W");
        } else {
            snprintf(v, sizeof(v), "offline");
        }
        row(c, x0, W, y, inv.name, v, F_SMALL_B);
        y += 11;
    }
    if (d.se.enabled) {
        if (d.se.online) {
            fmt(v, sizeof(v), d.se.pac, 0, " W");
        } else {
            snprintf(v, sizeof(v), "offline");
        }
        row(c, x0, W, y, d.se.name, v, F_SMALL_B);
        y += 11;
    }
    if (y <= 53) {
        fmt(v, sizeof(v), d.peakW, 0, " W");
        row(c, x0, W, 53, "Szczyt dziś", v);
    }
    fmtKwh(v, sizeof(v), d.totalKwh);
    row(c, x0, W, 64, "Łącznie", v);
}

void pageInverter(Ctx& c, const PvDisplayData& d, uint8_t idx, uint8_t no, uint8_t cnt)
{
    const PvDisplayInv& inv = d.inv[idx];
    char st[40] = {};
    if (!inv.reachable) {
        offlineStatus(st, sizeof(st), inv.lastSeen);
    }
    char t[16] = {};
    if (!std::isnan(inv.temp)) {
        fmt(t, sizeof(t), inv.temp, 1, "°C");
    }
    header(c, d, inv.name, st, no, cnt, t);

    c.text(0, 22, F_SMALL, "Moc AC");
    bigPower(c, 0, 51, F_BIG2, inv.reachable ? inv.pac : 0);
    char buf[32];
    char v[24];
    fmtKwh(v, sizeof(v), inv.todayWh / 1000.0);
    snprintf(buf, sizeof(buf), "Dziś %s", v);
    c.text(0, 64, F_SMALL_B, buf);

    const uint8_t n = std::min<uint8_t>(inv.nStr, PVD_MAX_DC);
    if (n == 0) {
        return;
    }
    c.vline(86, 15, 49);
    const int x0 = 90;
    const int colW = (W - x0) / n;
    const int barTop = 25;
    const int barBottom = 54;

    // common scale: nominal power if configured, otherwise the best string (min. 400 W)
    float scale = 0;
    for (uint8_t s = 0; s < n; s++) {
        scale = std::max(scale, inv.str[s].maxW > 0 ? inv.str[s].maxW : inv.str[s].pdc);
    }
    scale = std::max(scale, 400.0f);

    for (uint8_t s = 0; s < n; s++) {
        const PvDisplayString& ps = inv.str[s];
        const int cx = x0 + s * colW + colW / 2;
        const float p = inv.reachable ? std::max(0.0f, ps.pdc) : 0;
        fmt(v, sizeof(v), p, 0, " W");
        if (c.width(F_SMALL_B, v) > colW - 2) {
            fmt(v, sizeof(v), p, 0, "");
        }
        c.center(cx, 22, F_SMALL_B, v);
        const int bw = std::max(6, std::min(colW - 12, 30));
        const int bh = barBottom - barTop;
        c.frame(cx - bw / 2, barTop, bw, bh);
        const int fill = static_cast<int>(std::lround(std::min(1.0f, p / scale) * (bh - 2)));
        c.box(cx - bw / 2 + 1, barBottom - 1 - fill, bw - 2, fill);
        char nm[16];
        shortName(c, ps.name, s, colW - 2, nm, sizeof(nm));
        c.center(cx, 64, F_SMALL, nm);
    }
}

void pageInverterDetails(Ctx& c, const PvDisplayData& d, uint8_t idx, uint8_t no, uint8_t cnt)
{
    const PvDisplayInv& inv = d.inv[idx];
    char title[40];
    snprintf(title, sizeof(title), "%s - szczegóły", inv.name);
    char st[40] = {};
    if (!inv.reachable) {
        offlineStatus(st, sizeof(st), inv.lastSeen);
    }
    header(c, d, title, st, no, cnt);

    char v[24];
    const int xl = 0;
    const int xr = 82;
    int y = 22;
    static const char* const ph[3] = { "L1", "L2", "L3" };
    for (uint8_t i = 0; i < inv.uacCount && i < 3; i++) {
        fmt(v, sizeof(v), inv.uac[i], 1, " V");
        row(c, xl, xr, y, inv.uacCount == 1 ? "Napięcie" : ph[i], v);
        y += 10;
    }
    if (y <= 52) {
        fmt(v, sizeof(v), inv.freq, 2, " Hz");
        row(c, xl, xr, y, "Częst.", v);
        y += 10;
    }
    if (y <= 52 && !std::isnan(inv.eff)) {
        fmt(v, sizeof(v), inv.eff, 1, " %");
        row(c, xl, xr, y, "Sprawn.", v);
        y += 10;
    }
    fmtKwh(v, sizeof(v), inv.totalKwh);
    row(c, xl, xr, 63, "Suma", v);

    c.vline(88, 15, 49);
    // string table: name | U | I | today
    const int xn = 93;
    const int xu = 160;
    const int xi = 202;
    const int xe = W;
    c.text(xn, 21, F_SMALL, "String");
    c.right(xu, 21, F_SMALL, "U");
    c.right(xi, 21, F_SMALL, "I");
    c.right(xe, 21, F_SMALL, "dziś kWh");
    const uint8_t n = std::min<uint8_t>(inv.nStr, 4);
    for (uint8_t s = 0; s < n; s++) {
        const PvDisplayString& ps = inv.str[s];
        const int yy = 32 + s * 10;
        char nm[16];
        shortName(c, ps.name, s, xu - xn - 30, nm, sizeof(nm));
        c.text(xn, yy, F_SMALL_B, nm);
        fmt(v, sizeof(v), inv.reachable ? ps.udc : NAN, 1, " V");
        c.right(xu, yy, F_SMALL, v);
        fmt(v, sizeof(v), inv.reachable ? ps.idc : NAN, 2, " A");
        c.right(xi, yy, F_SMALL, v);
        fmt(v, sizeof(v), ps.todayWh / 1000.0, 2);
        c.right(xe, yy, F_SMALL, v);
    }
}

void pageSolarEdge(Ctx& c, const PvDisplayData& d, uint8_t no, uint8_t cnt)
{
    const PvDisplaySe& se = d.se;
    char st[48] = {};
    if (se.online) {
        snprintf(st, sizeof(st), "%s", se.status);
    } else {
        offlineStatus(st, sizeof(st), se.lastSeen);
    }
    char t[16] = {};
    if (se.online && !std::isnan(se.temp)) {
        fmt(t, sizeof(t), se.temp, 1, "°C");
    }
    header(c, d, se.name, st, no, cnt, t);

    char buf[48];
    char v[24];
    if (!se.online && se.error[0]) {
        c.text(0, 22, F_SMALL_B, "Brak danych:");
        wrapText(c, 0, 33, 118, 3, se.error);
    } else {
        c.text(0, 22, F_SMALL, "Moc AC");
        bigPower(c, 0, 51, F_BIG2, se.online ? se.pac : 0);
    }
    fmtKwh(v, sizeof(v), se.todayWh / 1000.0);
    snprintf(buf, sizeof(buf), "Dziś %s", v);
    c.text(0, 64, F_SMALL_B, buf);

    c.vline(124, 15, 49);
    const int x0 = 130;
    if (se.uacCount > 0) {
        buf[0] = 0;
        for (uint8_t i = 0; i < se.uacCount && i < 3; i++) {
            char one[12];
            fmt(one, sizeof(one), se.uac[i], 0);
            if (i) {
                strncat(buf, "/", sizeof(buf) - strlen(buf) - 1);
            }
            strncat(buf, one, sizeof(buf) - strlen(buf) - 1);
        }
        strncat(buf, " V", sizeof(buf) - strlen(buf) - 1);
        row(c, x0, W, 22, se.uacCount == 3 ? "L1/L2/L3" : "Napięcie", buf);
    }
    fmt(v, sizeof(v), se.freq, 2, " Hz");
    row(c, x0, W, 33, "Częstotliwość", v);
    fmt(v, sizeof(v), se.udc, 0, " V");
    row(c, x0, W, 44, "Napięcie DC", v);
    fmtKwh(v, sizeof(v), se.totalKwh);
    row(c, x0, W, 64, "Łącznie", v);
}

void pageChart(Ctx& c, const PvDisplayData& d, uint8_t no, uint8_t cnt)
{
    char v[24];
    fmtKwh(v, sizeof(v), d.totalTodayWh / 1000.0);
    header(c, d, "Wykres dnia", v, no, cnt);

    const int x0 = 20; // 96 slots x 2 px
    const int top = 15;
    const int bottom = 55;
    const int h = bottom - top;
    uint16_t maxW = 0;
    for (int i = 0; i < PVD_CURVE_SLOTS; i++) {
        if (d.curveValid[i]) {
            maxW = std::max(maxW, d.curve[i]);
        }
    }
    // nice axis maximum
    float axis = 500;
    static const float steps[] = { 500, 1000, 2000, 2500, 4000, 5000, 6000, 8000, 10000, 12500, 15000, 20000, 25000, 30000, 40000, 50000 };
    for (float s : steps) {
        axis = s;
        if (s >= maxW) {
            break;
        }
    }
    fmt(v, sizeof(v), axis >= 1000 ? axis / 1000.0 : axis, axis >= 1000 && std::fmod(axis, 1000.0f) != 0 ? 1 : 0, axis >= 1000 ? "k" : "");
    c.right(x0 - 3, top + 7, F_SMALL, v);
    c.right(x0 - 3, bottom, F_SMALL, "0");
    c.vline(x0 - 1, top, h + 1);
    c.hline(x0 - 1, bottom, 2 * PVD_CURVE_SLOTS + 2);
    // dotted half line
    for (int x = x0; x < x0 + 2 * PVD_CURVE_SLOTS; x += 4) {
        c.pixel(x, top + h / 2);
    }
    for (int i = 0; i < PVD_CURVE_SLOTS; i++) {
        if (!d.curveValid[i]) {
            continue;
        }
        const int bh = static_cast<int>(std::lround(std::min(1.0f, d.curve[i] / axis) * h));
        c.box(x0 + 2 * i, bottom - bh, 2, bh);
    }
    // hour labels and "now" marker
    for (int hr = 0; hr <= 24; hr += 6) {
        char hl[4];
        snprintf(hl, sizeof(hl), "%d", hr);
        const int x = x0 + hr * 8;
        c.vline(x, bottom + 1, 2);
        c.center(x, 64, F_SMALL, hl);
    }
    if (d.now != 0) {
        time_t t = d.now;
        struct tm tm;
        localtime_r(&t, &tm);
        const int x = x0 + (tm.tm_hour * 60 + tm.tm_min) * 2 / 15;
        for (int y = top; y < bottom; y += 2) {
            c.pixel(x, y);
        }
    }
    // right column: peak + current
    const int xr = W;
    c.right(xr, 24, F_SMALL, "szczyt");
    fmt(v, sizeof(v), d.peakW, 0, "W");
    c.right(xr, 34, F_SMALL_B, v);
    c.right(xr, 47, F_SMALL, "teraz");
    fmt(v, sizeof(v), d.totalPac, 0, "W");
    c.right(xr, 57, F_SMALL_B, v);
}

} // namespace

uint8_t pvDisplayPages(const PvDisplayData& d, PvPageRef* out, uint8_t max)
{
    uint8_t n = 0;
    auto add = [&](PvPage p, uint8_t i) {
        if (n < max) {
            out[n++] = { p, i };
        }
    };
    add(PvPage::Summary, 0);
    for (uint8_t i = 0; i < d.nInv && i < PVD_MAX_INV; i++) {
        add(PvPage::Inverter, i);
        add(PvPage::InverterDetails, i);
    }
    if (d.se.enabled) {
        add(PvPage::SolarEdge, 0);
    }
    add(PvPage::Chart, 0);
    return n;
}

void pvDisplayRender(u8g2_t* u8g2, const PvDisplayData& d, const PvPageRef& page, uint8_t pageNo, uint8_t pageCount, int8_t shiftX, int8_t shiftY)
{
    Ctx c { u8g2, shiftX, shiftY };
    u8g2_SetDrawColor(u8g2, 1);
    u8g2_SetFontMode(u8g2, 1);
    switch (page.page) {
    case PvPage::Summary:
        pageSummary(c, d, pageNo, pageCount);
        break;
    case PvPage::Inverter:
        pageInverter(c, d, page.index, pageNo, pageCount);
        break;
    case PvPage::InverterDetails:
        pageInverterDetails(c, d, page.index, pageNo, pageCount);
        break;
    case PvPage::SolarEdge:
        pageSolarEdge(c, d, pageNo, pageCount);
        break;
    case PvPage::Chart:
        pageChart(c, d, pageNo, pageCount);
        break;
    }
}

void pvDisplayRenderNight(u8g2_t* u8g2, const PvDisplayData& d, int8_t shiftX, int8_t shiftY)
{
    Ctx c { u8g2, shiftX, shiftY };
    u8g2_SetDrawColor(u8g2, 1);
    u8g2_SetFontMode(u8g2, 1);
    char clk[8];
    clockText(clk, sizeof(clk), d.now);
    c.text(4, 46, F_CLOCK, clk);
    char v[24];
    c.text(136, 22, F_SMALL, "Dziś");
    fmtKwh(v, sizeof(v), d.totalTodayWh / 1000.0);
    c.text(136, 36, F_SMALL_B, v);
    c.text(136, 52, F_SMALL, "Łącznie");
    fmtKwh(v, sizeof(v), d.totalKwh);
    c.text(136, 63, F_SMALL_B, v);
}
