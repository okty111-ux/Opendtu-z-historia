// SPDX-License-Identifier: GPL-2.0-or-later
#include "PvPins.h"
#include "PinMapping.h"
#include <driver/gpio.h>
#include <vector>

namespace PvPins {

static std::vector<int> reservedPins()
{
    // strapping pins
    std::vector<int> reserved = { 0, 45, 46 };
#if CONFIG_IDF_TARGET_ESP32S3
    // USB D-/D+, SPI flash / PSRAM
    reserved.insert(reserved.end(), { 19, 20, 26, 27, 28, 29, 30, 31, 32 });
#elif CONFIG_IDF_TARGET_ESP32
    reserved.insert(reserved.end(), { 1, 3, 6, 7, 8, 9, 10, 11 });
#endif
    const PinMapping_t& pm = PinMapping.get();
    const gpio_num_t used[] = {
        pm.nrf24_miso, pm.nrf24_mosi, pm.nrf24_clk, pm.nrf24_irq, pm.nrf24_en, pm.nrf24_cs,
        pm.cmt_clk, pm.cmt_cs, pm.cmt_fcs, pm.cmt_gpio2, pm.cmt_gpio3, pm.cmt_sdio,
        pm.w5500_mosi, pm.w5500_miso, pm.w5500_sclk, pm.w5500_cs, pm.w5500_int, pm.w5500_rst,
        pm.eth_power, pm.eth_mdc, pm.eth_mdio,
        pm.display_data, pm.display_clk, pm.display_cs, pm.display_reset
    };
    for (auto p : used) {
        if (p >= 0) {
            reserved.push_back(p);
        }
    }
    for (auto p : pm.led) {
        if (p >= 0) {
            reserved.push_back(p);
        }
    }
    return reserved;
}

String problem(int pin, bool output)
{
    if (pin < 0) {
        return "";
    }
    if (!GPIO_IS_VALID_GPIO(pin) || (output && !GPIO_IS_VALID_OUTPUT_GPIO(pin))) {
        return String("GPIO ") + String(pin) + " nie istnieje / nie może być wyjściem";
    }
    for (int r : reservedPins()) {
        if (pin == r) {
            return String("GPIO ") + String(pin) + " jest zajęty przez płytkę/OpenDTU";
        }
    }
    return "";
}

String checkSet(const int* pins, size_t count, const bool* outputs, const int* otherPins, size_t otherCount, const char* otherName)
{
    for (size_t i = 0; i < count; i++) {
        if (pins[i] < 0) {
            continue;
        }
        const String p = problem(pins[i], outputs[i]);
        if (p.length() > 0) {
            return p;
        }
        for (size_t j = i + 1; j < count; j++) {
            if (pins[j] == pins[i]) {
                return String("GPIO ") + String(pins[i]) + " użyty dwa razy";
            }
        }
        for (size_t j = 0; j < otherCount; j++) {
            if (otherPins[j] == pins[i]) {
                return String("GPIO ") + String(pins[i]) + " jest już używany przez " + otherName;
            }
        }
    }
    return "";
}

} // namespace PvPins
