// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * Real-time status display: 3.12" OLED 256x64 (SSD1322), 4-wire software SPI
 */
#include "PvDisplay.h"
#include "Configuration.h"
#include "PvHistory.h"
#include "PvPins.h"
#include "SolarEdge.h"
#include <ArduinoJson.h>
#include <Hoymiles.h>
#include <LittleFS.h>
#include <U8g2lib.h>
#include <ctime>

#undef TAG
static const char* TAG = "pvdisplay";

#define PV_DISPLAY_CONFIG_FILE "/pvdisplay.json"
static constexpr uint32_t FRAME_MS = 1000;
static constexpr uint32_t NIGHT_AFTER_MS = 15 * 60 * 1000; // no production for 15 min
static constexpr time_t MIN_VALID_EPOCH = 1700000000;

PvDisplayClass PvDisplay;

PvDisplayClass::PvDisplayClass()
    : _collectTask(1 * TASK_SECOND, TASK_FOREVER, std::bind(&PvDisplayClass::collect, this))
{
}

void PvDisplayClass::init(Scheduler& scheduler)
{
    loadConfig();
    scheduler.addTask(_collectTask);
    _collectTask.enable();
    // Core 0, low priority: drawing + bit-banged SPI never delays the radios in loop()
    xTaskCreatePinnedToCore(taskEntry, "pvdisplay", 6144, this, 1, nullptr, 0);
}

PvDisplayConfig PvDisplayClass::getConfig()
{
    std::lock_guard<std::mutex> lock(_mutex);
    return _cfg;
}

bool PvDisplayClass::setConfig(const PvDisplayConfig& cfg)
{
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _cfg = cfg;
    }
    _reinit = true;
    return saveConfig();
}

String PvDisplayClass::validate(const PvDisplayConfig& cfg)
{
    if (!cfg.enabled) {
        return "";
    }
    if (cfg.clk < 0 || cfg.mosi < 0 || cfg.cs < 0 || cfg.dc < 0) {
        return "Ustaw piny CLK, DIN, CS i DC wyświetlacza";
    }
    if (cfg.rotation != 0 && cfg.rotation != 2) {
        return "Obrót: 0° albo 180°";
    }
    const int pins[5] = { cfg.clk, cfg.mosi, cfg.cs, cfg.dc, cfg.rst };
    const bool outputs[5] = { true, true, true, true, true };
    const SolarEdgeConfig se = SolarEdge.getConfig();
    const bool rtu = se.enabled && se.transport == SolarEdgeTransport::Rtu;
    const int rs[3] = { se.rxPin, se.txPin, se.dePin };
    return PvPins::checkSet(pins, 5, outputs, rs, rtu ? 3 : 0, "RS485 SolarEdge");
}

bool PvDisplayClass::loadConfig()
{
    File f = LittleFS.open(PV_DISPLAY_CONFIG_FILE, "r", false);
    if (!f) {
        return false;
    }
    JsonDocument doc;
    const DeserializationError err = deserializeJson(doc, f);
    f.close();
    if (err) {
        ESP_LOGW(TAG, "Failed to parse %s: %s", PV_DISPLAY_CONFIG_FILE, err.c_str());
        return false;
    }
    std::lock_guard<std::mutex> lock(_mutex);
    _cfg.enabled = doc["enabled"] | _cfg.enabled;
    _cfg.clk = doc["clk"] | _cfg.clk;
    _cfg.mosi = doc["mosi"] | _cfg.mosi;
    _cfg.cs = doc["cs"] | _cfg.cs;
    _cfg.dc = doc["dc"] | _cfg.dc;
    _cfg.rst = doc["rst"] | _cfg.rst;
    _cfg.rotation = doc["rotation"] | _cfg.rotation;
    _cfg.contrast = doc["contrast"] | _cfg.contrast;
    _cfg.pageSec = doc["pageSec"] | _cfg.pageSec;
    _cfg.nightMode = doc["night"] | _cfg.nightMode;
    _cfg.shift = doc["shift"] | _cfg.shift;
    return true;
}

bool PvDisplayClass::saveConfig()
{
    JsonDocument doc;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        doc["enabled"] = _cfg.enabled;
        doc["clk"] = _cfg.clk;
        doc["mosi"] = _cfg.mosi;
        doc["cs"] = _cfg.cs;
        doc["dc"] = _cfg.dc;
        doc["rst"] = _cfg.rst;
        doc["rotation"] = _cfg.rotation;
        doc["contrast"] = _cfg.contrast;
        doc["pageSec"] = _cfg.pageSec;
        doc["night"] = _cfg.nightMode;
        doc["shift"] = _cfg.shift;
    }
    File f = LittleFS.open(PV_DISPLAY_CONFIG_FILE, "w");
    if (!f) {
        return false;
    }
    const bool ok = serializeJson(doc, f) > 0;
    f.close();
    return ok;
}

// ---------------------------------------------------------------------------
// Data collection - main loop, every second
// ---------------------------------------------------------------------------

static float fieldOr(StatisticsParser* st, ChannelType_t t, ChannelNum_t c, FieldId_t f, float def)
{
    return st->hasChannelFieldValue(t, c, f) ? st->getChannelFieldValue(t, c, f) : def;
}

static float totalField(StatisticsParser* st, FieldId_t f)
{
    if (st->hasChannelFieldValue(TYPE_AC, CH0, f)) {
        return st->getChannelFieldValue(TYPE_AC, CH0, f);
    }
    return fieldOr(st, TYPE_INV, CH0, f, NAN);
}

void PvDisplayClass::collect()
{
    if (!_running) {
        return;
    }
    PvDisplayData& d = _collectBuf; // member: keeps ~1.5 kB off the loop() stack
    d = PvDisplayData();
    const time_t now = time(nullptr);
    d.now = now >= MIN_VALID_EPOCH ? static_cast<uint32_t>(now) : 0;
    const HistState st = PvHistory.getState();

    double totalKwh = 0;
    double totalPac = 0;
    uint32_t todayWh = 0;

    const uint8_t count = std::min<uint8_t>(PVD_MAX_INV, Hoymiles.getNumInverters());
    for (uint8_t i = 0; i < count; i++) {
        auto inv = Hoymiles.getInverterByPos(i);
        if (inv == nullptr) {
            continue;
        }
        StatisticsParser* stat = inv->Statistics();
        PvDisplayInv& o = d.inv[d.nInv++];
        const uint32_t lu = stat->getLastUpdate();
        o.present = true;
        o.reachable = inv->isReachable() && lu != 0;
        strlcpy(o.name, inv->name(), sizeof(o.name));
        o.pac = o.reachable ? fieldOr(stat, TYPE_AC, CH0, FLD_PAC, 0) : 0;
        o.temp = fieldOr(stat, TYPE_INV, CH0, FLD_T, NAN);
        o.totalKwh = totalField(stat, FLD_YT);
        o.freq = fieldOr(stat, TYPE_AC, CH0, FLD_F, NAN);
        o.pf = fieldOr(stat, TYPE_AC, CH0, FLD_PF, NAN);
        o.eff = fieldOr(stat, TYPE_INV, CH0, FLD_EFF, NAN);
        o.pdcTotal = fieldOr(stat, TYPE_INV, CH0, FLD_PDC, NAN);
        const FieldId_t uf[3] = { FLD_UAC_1N, FLD_UAC_2N, FLD_UAC_3N };
        for (auto f : uf) {
            if (stat->hasChannelFieldValue(TYPE_AC, CH0, f)) {
                o.uac[o.uacCount++] = stat->getChannelFieldValue(TYPE_AC, CH0, f);
            }
        }
        if (o.uacCount == 0 && stat->hasChannelFieldValue(TYPE_AC, CH0, FLD_UAC)) {
            o.uac[o.uacCount++] = stat->getChannelFieldValue(TYPE_AC, CH0, FLD_UAC);
        }
        o.todayWh = st.invAc[i].dayWh();
        o.lastSeen = (lu == 0 || d.now == 0) ? 0 : d.now - (millis() - lu) / 1000;

        const INVERTER_CONFIG_T* cfg = Configuration.getInverterConfig(inv->serial());
        for (auto c : stat->getChannelsByType(TYPE_DC)) {
            if (c >= PVD_MAX_DC) {
                continue;
            }
            PvDisplayString& s = o.str[c];
            const char* n = cfg != nullptr ? cfg->channel[c].Name : "";
            if (n != nullptr && n[0]) {
                strlcpy(s.name, n, sizeof(s.name));
            } else {
                snprintf(s.name, sizeof(s.name), "String %u", static_cast<unsigned>(c) + 1);
            }
            s.pdc = o.reachable ? fieldOr(stat, TYPE_DC, c, FLD_PDC, 0) : 0;
            s.udc = fieldOr(stat, TYPE_DC, c, FLD_UDC, NAN);
            s.idc = fieldOr(stat, TYPE_DC, c, FLD_IDC, NAN);
            s.maxW = cfg != nullptr ? cfg->channel[c].MaxChannelPower : 0;
            s.todayWh = st.invDc[i][c].dayWh();
            o.nStr = std::max<uint8_t>(o.nStr, static_cast<uint8_t>(c) + 1);
        }
        totalPac += o.pac;
        todayWh += o.todayWh;
        if (!std::isnan(o.totalKwh)) {
            totalKwh += o.totalKwh;
        }
    }

    const SolarEdgeSnapshot se = SolarEdge.getSnapshot();
    const SolarEdgeConfig sec = SolarEdge.getConfig();
    d.se.enabled = sec.enabled;
    d.se.online = se.online;
    strlcpy(d.se.name, sec.name, sizeof(d.se.name));
    strlcpy(d.se.error, se.lastError, sizeof(d.se.error));
    d.se.lastSeen = se.lastUpdateEpoch;
    d.se.todayWh = st.se.dayWh();
    if (se.inv.valid) {
        d.se.pac = se.online && !std::isnan(se.inv.pac) ? se.inv.pac : 0;
        d.se.temp = se.inv.temp;
        d.se.totalKwh = se.inv.energyWh / 1000.0;
        d.se.udc = se.inv.udc;
        d.se.freq = se.inv.freq;
        const int phases = se.inv.did == 103 ? 3 : (se.inv.did == 102 ? 2 : 1);
        for (int p = 0; p < phases; p++) {
            d.se.uac[d.se.uacCount++] = se.inv.uacLN[p];
        }
        strlcpy(d.se.status, SunSpec::statusText(se.inv.status), sizeof(d.se.status));
        if (!std::isnan(d.se.totalKwh)) {
            totalKwh += d.se.totalKwh;
        }
    }
    if (d.se.enabled) {
        totalPac += d.se.pac;
        todayWh += d.se.todayWh;
    }

    d.totalPac = totalPac;
    d.totalTodayWh = todayWh;
    d.totalKwh = totalKwh;
    d.peakW = st.peakW;

    std::lock_guard<std::mutex> lock(_mutex);
    _data = d;
}

// ---------------------------------------------------------------------------
// Drawing task
// ---------------------------------------------------------------------------

void PvDisplayClass::updateCurve(PvDisplayData& d)
{
    if (d.now == 0) {
        return;
    }
    time_t now = d.now;
    struct tm tm;
    localtime_r(&now, &tm);
    tm.tm_hour = tm.tm_min = tm.tm_sec = 0;
    tm.tm_isdst = -1;
    const uint32_t midnight = static_cast<uint32_t>(mktime(&tm));
    const uint32_t date = PvHistoryStore::localDate(d.now);

    if (date != _curveDate || d.now - _curveUpdated >= 60) {
        _curveDate = date;
        _curveUpdated = d.now;
        uint32_t sum[PVD_CURVE_SLOTS] = {};
        uint16_t cnt[PVD_CURVE_SLOTS] = {};
        PvHistoryStore& store = PvHistory.store();
        PvHistoryStore::SampleCursor cur(store, midnight, d.now, store.sampleDatesForRange(midnight, d.now));
        HistSample s;
        while (cur.next(s)) {
            const uint32_t slot = (s.ts - midnight) / 900;
            if (slot < PVD_CURVE_SLOTS) {
                sum[slot] += PvHistoryLogic::sampleTotalW(s);
                cnt[slot]++;
            }
        }
        // samples are only stored while producing - fill the gaps of today's daylight with 0
        int first = -1;
        int last = -1;
        for (int i = 0; i < PVD_CURVE_SLOTS; i++) {
            if (cnt[i]) {
                if (first < 0) {
                    first = i;
                }
                last = i;
            }
        }
        for (int i = 0; i < PVD_CURVE_SLOTS; i++) {
            _curveValid[i] = first >= 0 && i >= first && i <= last;
            _curve[i] = cnt[i] ? static_cast<uint16_t>(std::min<uint32_t>(sum[i] / cnt[i], 65000)) : 0;
        }
    }
    memcpy(d.curve, _curve, sizeof(_curve));
    memcpy(d.curveValid, _curveValid, sizeof(_curveValid));
    // live value for the running slot
    const uint32_t slot = (d.now - midnight) / 900;
    if (slot < PVD_CURVE_SLOTS && d.totalPac > 0 && !d.curveValid[slot]) {
        d.curve[slot] = static_cast<uint16_t>(std::min(d.totalPac, 65000.0f));
        d.curveValid[slot] = true;
    }
}

void PvDisplayClass::taskEntry(void* arg)
{
    static_cast<PvDisplayClass*>(arg)->taskLoop();
}

void PvDisplayClass::taskLoop()
{
    uint32_t lastFrame = 0;
    uint32_t pageStart = 0;
    uint8_t page = 0;
    uint32_t lowSince = 0;
    PvDisplayConfig cfg;

    for (;;) {
        if (_reinit) {
            _reinit = false;
            cfg = getConfig();
            if (_u8g2 != nullptr) {
                _u8g2->clearDisplay();
                _u8g2->setPowerSave(1);
                delete _u8g2;
                _u8g2 = nullptr;
            }
            _running = false;
            const String err = validate(cfg);
            if (cfg.enabled && err.length() == 0) {
                _u8g2 = new U8G2_SSD1322_NHD_256X64_F_4W_SW_SPI(cfg.rotation == 2 ? U8G2_R2 : U8G2_R0,
                    cfg.clk, cfg.mosi, cfg.cs, cfg.dc, cfg.rst >= 0 ? cfg.rst : U8X8_PIN_NONE);
                _u8g2->begin();
                _u8g2->setContrast(cfg.contrast);
                _contrastSet = cfg.contrast;
                _off = false;
                _running = true;
                page = 0;
                pageStart = millis();
                lastFrame = 0;
                ESP_LOGI(TAG, "Display started: CLK %d DIN %d CS %d DC %d RST %d", cfg.clk, cfg.mosi, cfg.cs, cfg.dc, cfg.rst);
            } else if (cfg.enabled) {
                ESP_LOGW(TAG, "Display not started: %s", err.c_str());
            }
        }

        if (_u8g2 == nullptr) {
            vTaskDelay(pdMS_TO_TICKS(500));
            continue;
        }
        if (lastFrame != 0 && millis() - lastFrame < FRAME_MS) {
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }
        lastFrame = millis();
        if (lastFrame == 0) {
            lastFrame = 1;
        }

        {
            std::lock_guard<std::mutex> lock(_mutex);
            _work = _data;
        }
        updateCurve(_work);

        // night: nothing produced for a while
        if (_work.totalPac >= 1) {
            lowSince = 0;
        } else if (lowSince == 0) {
            lowSince = millis() | 1;
        }
        const bool night = _work.now != 0 && lowSince != 0 && millis() - lowSince > NIGHT_AFTER_MS;

        if (night && cfg.nightMode == 2) {
            if (!_off) {
                _u8g2->setPowerSave(1);
                _off = true;
            }
            continue;
        }
        if (_off) {
            _u8g2->setPowerSave(0);
            _off = false;
        }
        const uint8_t contrast = (night && cfg.nightMode == 1) ? std::max(1, cfg.contrast / 6) : cfg.contrast;
        if (contrast != _contrastSet) {
            _u8g2->setContrast(contrast);
            _contrastSet = contrast;
        }

        int8_t sx = 0;
        int8_t sy = 0;
        if (cfg.shift) {
            static const int8_t pattern[4][2] = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 0, 1 } };
            const uint8_t ph = (millis() / 120000) % 4;
            sx = pattern[ph][0];
            sy = pattern[ph][1];
        }

        _u8g2->clearBuffer();
        if (night && cfg.nightMode == 1) {
            pvDisplayRenderNight(_u8g2->getU8g2(), _work, sx, sy);
        } else {
            PvPageRef pages[2 + 2 * PVD_MAX_INV + 1];
            const uint8_t n = pvDisplayPages(_work, pages, sizeof(pages) / sizeof(pages[0]));
            if (cfg.pageSec == 0) {
                page = 0;
            } else if (millis() - pageStart >= cfg.pageSec * 1000UL) {
                page++;
                pageStart = millis();
            }
            if (page >= n) {
                page = 0;
            }
            pvDisplayRender(_u8g2->getU8g2(), _work, pages[page], page, cfg.pageSec == 0 ? 1 : n, sx, sy);
        }
        _u8g2->sendBuffer();
    }
}
