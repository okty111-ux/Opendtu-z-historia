// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include "HMT_Abstract.h"

class MIT_8CH : public HMT_Abstract {
public:
    explicit MIT_8CH(HoymilesRadio* radio, const uint64_t serial);
    static bool isValidSerial(const uint64_t serial);
    String typeName() const;
    const byteAssign_t* getByteAssignment() const;
    uint8_t getByteAssignmentSize() const;
    uint32_t getSingleDataCommandTimeout() const override;
    uint32_t getRealTimeRunDataCommandTimeout() const override;
    uint32_t getAlarmDataCommandTimeout() const override;
    uint8_t getMaxRetransmitCount() const override;
};
