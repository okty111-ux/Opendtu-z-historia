// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include "types.h"
#include "RadioRecoverySettings.h"
#include <Stream.h>
#include <WString.h>
#include <cstdint>

#define RF_LEN 32
#define MAX_RESEND_COUNT 4 // Used if all packages are missing
#define MAX_DEFAULT_RETRANSMIT_COUNT 5 // Used to send the retransmit package
#define MAX_MIT_RETRANSMIT_COUNT 20 // Used to send the retransmit package to MIT inverters

class InverterAbstract;

enum class QueueInsertType {
    AllowMultiple,
    // Remove from  beginning of the queue
    RemoveOldest,

    // Don't insert command if it already exist
    RemoveNewest,

    // Replace the existing entry in the queue by the one to be added
    ReplaceExistent,
};

class CommandAbstract {
public:
    explicit CommandAbstract(InverterAbstract* inv, const uint64_t router_address = 0);
    virtual ~CommandAbstract() { };

    const uint8_t* getDataPayload();
    String dumpDataPayload();

    uint8_t getDataSize() const;

    uint64_t getTargetAddress() const;

    void setRouterAddress(const uint64_t address);
    uint64_t getRouterAddress() const;

    void setTimeout(const uint32_t timeout);
    uint32_t getTimeout() const;

    // Initialize at construction, refresh before the first transmission, then retain for retries.
    void prepareRadioRecoverySettings();
    uint32_t getFragmentReplyTimeout() const;

    virtual String getCommandName() const = 0;

    uint8_t getMainCmd() const { return _payload[0]; }

    void setSendCount(const uint8_t count);
    uint8_t getSendCount() const;
    uint8_t incrementSendCount();

    virtual CommandAbstract* getRequestFrameCommand(const uint8_t frame_no);

    virtual bool handleResponse(const fragment_t fragment[], const uint8_t max_fragment_id) = 0;
    virtual void gotTimeout();

    // Sets the amount how often the specific command is resent if all fragments where missing
    virtual uint8_t getMaxResendCount() const;

    // Sets the amount how often a missing fragment is re-requested if it was not available
    virtual uint8_t getMaxRetransmitCount() const;

    // Returns whether multiple instances of this command are allowed in the command queue.
    virtual QueueInsertType getQueueInsertType() const { return QueueInsertType::RemoveNewest; }
    virtual bool areSameParameter(CommandAbstract* other);

    // Some inverters answer certain commands with a single fragment that does
    // not carry the "last fragment" flag (0x80) which the generic fragment
    // reassembly otherwise requires. If set, the highest numbered fragment
    // received so far is accepted as the complete answer.
    bool acceptsSingleFragmentAnswer() const { return _singleFragmentAnswer; }

    void setFrequency(const uint32_t frequency) { _frequency = frequency; }
    uint32_t getFrequency() const { return _frequency; }

    virtual bool usesBootFrequency() const { return false; }

    InverterAbstract* getInverter() const { return _inv; }

protected:
    uint8_t _payload[RF_LEN];
    uint8_t _payload_size;
    bool _singleFragmentAnswer;
    uint32_t _timeout;
    uint8_t _sendCount;
    uint32_t _frequency = 0;

    uint64_t _targetAddress;
    uint64_t _routerAddress;

    InverterAbstract* _inv;

    RadioRecoverySettings _radioRecoverySettings;

private:
    void setTargetAddress(const uint64_t address);
    static void convertSerialToPacketId(uint8_t buffer[], const uint64_t serial);
};
