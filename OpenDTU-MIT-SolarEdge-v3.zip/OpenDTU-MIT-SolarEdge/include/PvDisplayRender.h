// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * Page rendering for the 256x64 status display (SSD1322 OLED).
 * Platform independent: only uses the u8g2 C API, so pages can be rendered
 * into a bitmap on a PC for previews/tests.
 */

#if __has_include(<U8g2lib.h>)
#include <U8g2lib.h>
#else
#include <u8g2.h>
#endif
#include <cmath>
#include <cstdint>

#define PVD_MAX_INV 2
#define PVD_MAX_DC 6
#define PVD_CURVE_SLOTS 96 // 15-minute buckets of the current day

struct PvDisplayString {
    char name[16] = {};
    float pdc = 0;
    float udc = NAN;
    float idc = NAN;
    float maxW = 0; // nominal panel power for bar scaling, 0 = unknown
    uint32_t todayWh = 0;
};

struct PvDisplayInv {
    bool present = false;
    bool reachable = false;
    char name[24] = {};
    float pac = 0;
    float temp = NAN;
    float totalKwh = NAN;
    float freq = NAN;
    float pf = NAN;
    float eff = NAN;
    float pdcTotal = NAN;
    float uac[3] = { NAN, NAN, NAN };
    uint8_t uacCount = 0;
    uint32_t todayWh = 0;
    uint32_t lastSeen = 0; // epoch of last data, 0 = never
    uint8_t nStr = 0;
    PvDisplayString str[PVD_MAX_DC];
};

struct PvDisplaySe {
    bool enabled = false;
    bool online = false;
    char name[24] = {};
    float pac = 0;
    float temp = NAN;
    float totalKwh = NAN;
    float udc = NAN;
    float freq = NAN;
    float uac[3] = { NAN, NAN, NAN };
    uint8_t uacCount = 0;
    uint32_t todayWh = 0;
    uint32_t lastSeen = 0;
    char status[24] = {};
    char error[48] = {};
};

struct PvDisplayData {
    uint32_t now = 0; // epoch, 0 = no time yet
    float totalPac = 0;
    uint32_t totalTodayWh = 0;
    float totalKwh = 0;
    uint16_t peakW = 0;
    uint8_t nInv = 0;
    PvDisplayInv inv[PVD_MAX_INV];
    PvDisplaySe se;
    uint16_t curve[PVD_CURVE_SLOTS] = {}; // W, average per 15 min, today
    bool curveValid[PVD_CURVE_SLOTS] = {};
    char ip[16] = {};
};

enum class PvPage : uint8_t {
    Summary,
    Inverter, // AC + bars per string
    InverterDetails, // voltages, frequency, string U/I
    SolarEdge,
    Chart,
};

struct PvPageRef {
    PvPage page;
    uint8_t index; // inverter index for Inverter*
};

// Pages that make sense for the given data (fills `out`, returns count)
uint8_t pvDisplayPages(const PvDisplayData& d, PvPageRef* out, uint8_t max);

// Render one page into the u8g2 buffer (does not clear / send).
// shiftX/shiftY: small offset against OLED burn-in (0..2 / 0..1).
void pvDisplayRender(u8g2_t* u8g2, const PvDisplayData& d, const PvPageRef& page, uint8_t pageNo, uint8_t pageCount, int8_t shiftX, int8_t shiftY);

// Minimal "night" page: clock + today's yield
void pvDisplayRenderNight(u8g2_t* u8g2, const PvDisplayData& d, int8_t shiftX, int8_t shiftY);
