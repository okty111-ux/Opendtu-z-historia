// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * PvHistoryStore - persistent production statistics stored in LittleFS.
 *
 * Portable (POSIX stdio only) so the logic can be unit-tested on a PC.
 * On the ESP32 the LittleFS partition is mounted under "/littlefs".
 *
 * Layout (all files append-only, oldest files are deleted when space runs out):
 *   <base>/hist1/s/YYYYMMDD.bin   5-minute samples of one (local) day
 *   <base>/hist1/d/YYYYMM.bin     one HistDay record per finished day
 *   <base>/hist1/state.bin        energy counters of the running day
 */

#include <cstdint>
#include <cstdio>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

#define HIST_MAX_INV 2 // number of Hoymiles inverters recorded
#define HIST_MAX_DC 6 // number of DC inputs per Hoymiles inverter recorded
#define HIST_TEMP_NONE INT16_MIN

#pragma pack(push, 1)
struct HistSampleInv {
    uint16_t pac; // W
    int16_t temp; // 0.1 °C, HIST_TEMP_NONE = unknown
    uint16_t pdc[HIST_MAX_DC]; // W
};

struct HistSample {
    uint32_t ts; // UTC epoch, start of the interval
    uint16_t sePac; // W
    int16_t seTemp; // 0.1 °C
    HistSampleInv inv[HIST_MAX_INV];
};

struct HistDayInv {
    uint32_t acWh;
    uint32_t dcWh[HIST_MAX_DC];
};

struct HistDay {
    uint32_t date; // YYYYMMDD (local)
    uint32_t seWh;
    HistDayInv inv[HIST_MAX_INV];
    uint16_t peakW; // max. 5-min average of total power
    uint16_t reserved;
};

// Energy counter: lifetime total at day start and last known lifetime total
struct HistCounter {
    uint32_t startWh;
    uint32_t lastWh;
    uint8_t valid; // 1 = start/last are meaningful
    uint8_t pad[3];

    uint32_t dayWh() const { return (valid && lastWh >= startWh) ? lastWh - startWh : 0; }
};

struct HistState {
    uint32_t magic;
    uint32_t date; // YYYYMMDD the counters belong to
    HistCounter se;
    HistCounter invAc[HIST_MAX_INV];
    HistCounter invDc[HIST_MAX_INV][HIST_MAX_DC];
    uint16_t peakW;
    uint16_t pad;
};
#pragma pack(pop)

static_assert(sizeof(HistSample) == 40, "HistSample layout changed - bump directory version");
static_assert(sizeof(HistDay) == 68, "HistDay layout changed - bump directory version");

#define HIST_STATE_MAGIC 0x50564831 // "PVH1"

class PvHistoryStore {
public:
    using SizeFn = std::function<size_t()>;

    // basePath: e.g. "/littlefs". totalFn/usedFn report the file system size.
    void init(const std::string& basePath, SizeFn totalFn, SizeFn usedFn);

    bool appendSample(const HistSample& s, uint32_t localDate);
    bool appendDay(const HistDay& d);

    bool loadState(HistState& st);
    bool saveState(const HistState& st);

    // Delete oldest files until enough free space is left.
    void enforceRetention();
    // Remove all samples and day records (state is kept).
    void clearAll();

    std::vector<uint32_t> listSampleDates(); // sorted ascending, YYYYMMDD
    std::vector<uint32_t> listDayMonths(); // sorted ascending, YYYYMM

    size_t freeBytes() const;
    size_t totalBytes() const { return _totalFn ? _totalFn() : 0; }
    size_t reserveBytes() const;
    uint32_t oldestSampleDate();
    uint32_t oldestDayDate();
    size_t dayRecordCount();

    // Streaming readers (used by the chunked HTTP responses)
    class SampleCursor {
    public:
        SampleCursor(PvHistoryStore& store, uint32_t fromTs, uint32_t toTs, std::vector<uint32_t> dates);
        bool next(HistSample& out);

    private:
        PvHistoryStore& _store;
        uint32_t _from, _to;
        std::vector<uint32_t> _dates;
        size_t _idx = 0; // next file to load
        std::vector<HistSample> _buf; // content of the current day file
        size_t _bufPos = 0;
    };

    class DayCursor {
    public:
        DayCursor(PvHistoryStore& store, uint32_t fromDate, uint32_t toDate);
        bool next(HistDay& out);

    private:
        PvHistoryStore& _store;
        uint32_t _from, _to;
        std::vector<uint32_t> _months;
        size_t _idx = 0;
        std::vector<HistDay> _buf;
        size_t _bufPos = 0;
    };

    // Dates (YYYYMMDD) whose sample files may contain data for [fromTs, toTs]
    std::vector<uint32_t> sampleDatesForRange(uint32_t fromTs, uint32_t toTs);

    std::recursive_mutex& mutex() { return _mutex; }

    static uint32_t localDate(uint32_t ts); // YYYYMMDD in the configured TZ

private:
    std::string dir() const { return _base + "/hist1"; }
    std::string samplePath(uint32_t date) const;
    std::string dayPath(uint32_t month) const;
    std::vector<uint32_t> listNumbers(const std::string& d, size_t digits);
    void ensureDirs();
    template <typename T>
    bool readFile(const std::string& path, std::vector<T>& out);
    bool deleteOldestSampleFile(uint32_t keepFrom);
    bool deleteOldestDayFile();

    std::string _base;
    SizeFn _totalFn;
    SizeFn _usedFn;
    std::recursive_mutex _mutex;
};
