// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * Platform independent bookkeeping for PvHistory:
 *  - daily energy from lifetime counters (robust against night-time
 *    unreachability, reboots and counter glitches)
 *  - averaging of power readings over one sample interval
 */

#include "PvHistoryStore.h"
#include <cmath>
#include <cstring>

namespace PvHistoryLogic {

// A lifetime counter may not jump by more than this between two readings
static constexpr uint32_t MAX_PLAUSIBLE_STEP_WH = 50000;

/*
 * Feed a fresh lifetime reading (Wh) into a day counter.
 * ydHintWh: the device's own "yield today" (Wh) or -1 if unknown. It is only
 * used to place the start of the day when the counter was not valid yet
 * (first reading after a reboot that happened on another day).
 */
inline void updateCounter(HistCounter& c, uint32_t lifetimeWh, int64_t ydHintWh = -1)
{
    if (lifetimeWh == 0) {
        return; // not reported / invalid
    }
    if (!c.valid) {
        c.startWh = (ydHintWh >= 0 && static_cast<uint64_t>(ydHintWh) <= lifetimeWh) ? lifetimeWh - static_cast<uint32_t>(ydHintWh) : lifetimeWh;
        c.lastWh = lifetimeWh;
        c.valid = 1;
        return;
    }
    if (lifetimeWh < c.startWh) {
        // Counter was reset or replaced - keep what was already produced today
        const uint32_t done = c.dayWh();
        c.startWh = lifetimeWh >= done ? lifetimeWh - done : 0;
        c.lastWh = lifetimeWh;
        return;
    }
    if (lifetimeWh < c.lastWh) {
        return; // small backwards glitch, ignore
    }
    if (lifetimeWh - c.lastWh > MAX_PLAUSIBLE_STEP_WH) {
        return; // implausible spike (corrupted frame), ignore
    }
    c.lastWh = lifetimeWh;
}

inline uint32_t kwhToWh(double kwh)
{
    if (!(kwh > 0) || kwh > 4.0e6) {
        return 0;
    }
    return static_cast<uint32_t>(std::llround(kwh * 1000.0));
}

inline HistDay dayFromState(const HistState& st)
{
    HistDay d;
    memset(&d, 0, sizeof(d));
    d.date = st.date;
    d.seWh = st.se.dayWh();
    for (int i = 0; i < HIST_MAX_INV; i++) {
        d.inv[i].acWh = st.invAc[i].dayWh();
        for (int c = 0; c < HIST_MAX_DC; c++) {
            d.inv[i].dcWh[c] = st.invDc[i][c].dayWh();
        }
    }
    d.peakW = st.peakW;
    return d;
}

inline uint32_t totalDayWh(const HistDay& d)
{
    uint32_t t = d.seWh;
    for (int i = 0; i < HIST_MAX_INV; i++) {
        t += d.inv[i].acWh;
    }
    return t;
}

inline void resetCounters(HistState& st, bool carryOver)
{
    auto reset = [carryOver](HistCounter& c) {
        if (carryOver && c.valid) {
            c.startWh = c.lastWh; // nothing is produced around midnight
        } else {
            c.valid = 0;
            c.startWh = c.lastWh = 0;
        }
    };
    reset(st.se);
    for (int i = 0; i < HIST_MAX_INV; i++) {
        reset(st.invAc[i]);
        for (int c = 0; c < HIST_MAX_DC; c++) {
            reset(st.invDc[i][c]);
        }
    }
    st.peakW = 0;
}

/*
 * Switch the state to `today`.
 * contiguous = true for a rollover observed while running (midnight),
 * false when the stored state is from an earlier boot.
 * Returns true and fills `finished` if a day record has to be written.
 */
inline bool rollover(HistState& st, uint32_t today, bool contiguous, HistDay& finished)
{
    if (st.magic != HIST_STATE_MAGIC) {
        memset(&st, 0, sizeof(st));
        st.magic = HIST_STATE_MAGIC;
    }
    if (st.date == today) {
        return false;
    }
    bool have = false;
    if (st.date != 0) {
        finished = dayFromState(st);
        have = true;
    }
    resetCounters(st, contiguous && st.date != 0);
    st.date = today;
    return have;
}

// ---------------------------------------------------------------------------

struct Accumulator {
    uint32_t n = 0;
    double se = 0;
    double seT = 0;
    uint32_t seTn = 0;
    double pac[HIST_MAX_INV] = {};
    double t[HIST_MAX_INV] = {};
    uint32_t tn[HIST_MAX_INV] = {};
    double pdc[HIST_MAX_INV][HIST_MAX_DC] = {};

    void reset() { *this = Accumulator(); }

    // One reading of all sources. NAN temperatures are ignored.
    struct Reading {
        float se = 0;
        float seT = NAN;
        float pac[HIST_MAX_INV] = {};
        float t[HIST_MAX_INV] = { NAN, NAN };
        float pdc[HIST_MAX_INV][HIST_MAX_DC] = {};
    };

    void add(const Reading& r)
    {
        n++;
        se += r.se > 0 ? r.se : 0;
        if (!std::isnan(r.seT)) {
            seT += r.seT;
            seTn++;
        }
        for (int i = 0; i < HIST_MAX_INV; i++) {
            pac[i] += r.pac[i] > 0 ? r.pac[i] : 0;
            if (!std::isnan(r.t[i])) {
                t[i] += r.t[i];
                tn[i]++;
            }
            for (int c = 0; c < HIST_MAX_DC; c++) {
                pdc[i][c] += r.pdc[i][c] > 0 ? r.pdc[i][c] : 0;
            }
        }
    }

    static uint16_t w(double sum, uint32_t cnt)
    {
        if (cnt == 0) {
            return 0;
        }
        const double v = sum / cnt;
        return static_cast<uint16_t>(v > 65000 ? 65000 : std::lround(v));
    }

    static int16_t temp(double sum, uint32_t cnt)
    {
        return cnt == 0 ? HIST_TEMP_NONE : static_cast<int16_t>(std::lround(sum / cnt * 10.0));
    }

    HistSample toSample(uint32_t ts) const
    {
        HistSample s;
        memset(&s, 0, sizeof(s));
        s.ts = ts;
        s.sePac = w(se, n);
        s.seTemp = temp(seT, seTn);
        for (int i = 0; i < HIST_MAX_INV; i++) {
            s.inv[i].pac = w(pac[i], n);
            s.inv[i].temp = temp(t[i], tn[i]);
            for (int c = 0; c < HIST_MAX_DC; c++) {
                s.inv[i].pdc[c] = w(pdc[i][c], n);
            }
        }
        return s;
    }
};

inline uint32_t sampleTotalW(const HistSample& s)
{
    uint32_t t = s.sePac;
    for (int i = 0; i < HIST_MAX_INV; i++) {
        t += s.inv[i].pac;
    }
    return t;
}

inline bool sampleIsZero(const HistSample& s)
{
    if (sampleTotalW(s) != 0) {
        return false;
    }
    for (int i = 0; i < HIST_MAX_INV; i++) {
        for (int c = 0; c < HIST_MAX_DC; c++) {
            if (s.inv[i].pdc[c] != 0) {
                return false;
            }
        }
    }
    return true;
}

} // namespace PvHistoryLogic
