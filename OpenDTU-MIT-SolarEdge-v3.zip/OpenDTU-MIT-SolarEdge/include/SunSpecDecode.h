// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * Decoding of the SunSpec inverter model (101/102/103) as implemented by
 * SolarEdge inverters (Modbus TCP, holding registers starting at 40069).
 * Header-only and platform independent.
 */

#include <cmath>
#include <cstdint>
#include <cstring>

namespace SunSpec {

static constexpr uint16_t REG_COMMON_START = 40000; // "SunS" + common model 1
static constexpr uint16_t REG_COMMON_COUNT = 69;
static constexpr uint16_t REG_INVERTER_START = 40069; // DID, length, inverter model
static constexpr uint16_t REG_INVERTER_COUNT = 40; // 40069 .. 40108

struct Common {
    bool valid = false;
    char manufacturer[33] = {};
    char model[33] = {};
    char version[17] = {};
    char serial[33] = {};
};

struct Inverter {
    bool valid = false;
    uint16_t did = 0; // 101 = 1-phase, 102 = split phase, 103 = 3-phase
    float iac = NAN; // A total
    float iacPh[3] = { NAN, NAN, NAN };
    float uacLL[3] = { NAN, NAN, NAN }; // AB, BC, CA
    float uacLN[3] = { NAN, NAN, NAN }; // AN, BN, CN
    float pac = NAN; // W
    float freq = NAN; // Hz
    float va = NAN;
    float var = NAN;
    float pf = NAN; // %
    double energyWh = NAN; // lifetime
    float idc = NAN;
    float udc = NAN;
    float pdc = NAN;
    float temp = NAN; // heat sink °C
    uint16_t status = 0;
    uint16_t vendorStatus = 0;
};

inline float applySf(int32_t raw, int16_t sf)
{
    if (sf < -10 || sf > 10) {
        return NAN;
    }
    return static_cast<float>(raw * std::pow(10.0, sf));
}

inline float u16(const uint16_t* r, int off, int16_t sf)
{
    return r[off] == 0xFFFF ? NAN : applySf(r[off], sf);
}

inline float s16(const uint16_t* r, int off, int16_t sf)
{
    return r[off] == 0x8000 ? NAN : applySf(static_cast<int16_t>(r[off]), sf);
}

inline void str(const uint16_t* r, int off, int regs, char* out)
{
    for (int i = 0; i < regs; i++) {
        out[2 * i] = static_cast<char>(r[off + i] >> 8);
        out[2 * i + 1] = static_cast<char>(r[off + i] & 0xFF);
    }
    out[2 * regs] = 0;
    // trim trailing spaces / zeros
    for (int i = 2 * regs - 1; i >= 0 && (out[i] == ' ' || out[i] == 0); i--) {
        out[i] = 0;
    }
}

// r = 69 registers starting at 40000
inline Common decodeCommon(const uint16_t* r)
{
    Common c;
    // 40000/40001 "SunS", 40002 = 1 (common model), 40003 = 65 (length)
    if (r[0] != 0x5375 || r[1] != 0x6e53) {
        return c;
    }
    str(r, 4, 16, c.manufacturer);
    str(r, 20, 16, c.model);
    str(r, 44, 8, c.version);
    str(r, 52, 16, c.serial);
    c.valid = true;
    return c;
}

// r = 40 registers starting at 40069
inline Inverter decodeInverter(const uint16_t* r)
{
    Inverter v;
    v.did = r[0];
    if (v.did < 101 || v.did > 103) {
        return v;
    }
    // offsets relative to 40069
    const int16_t iSf = static_cast<int16_t>(r[6]); // 40075
    v.iac = u16(r, 2, iSf);
    for (int i = 0; i < 3; i++) {
        v.iacPh[i] = u16(r, 3 + i, iSf);
    }
    const int16_t uSf = static_cast<int16_t>(r[13]); // 40082
    for (int i = 0; i < 3; i++) {
        v.uacLL[i] = u16(r, 7 + i, uSf);
        v.uacLN[i] = u16(r, 10 + i, uSf);
    }
    v.pac = s16(r, 14, static_cast<int16_t>(r[15])); // 40083/40084
    v.freq = u16(r, 16, static_cast<int16_t>(r[17])); // 40085/40086
    v.va = s16(r, 18, static_cast<int16_t>(r[19])); // 40087/40088
    v.var = s16(r, 20, static_cast<int16_t>(r[21])); // 40089/40090
    v.pf = s16(r, 22, static_cast<int16_t>(r[23])); // 40091/40092
    const uint32_t wh = (static_cast<uint32_t>(r[24]) << 16) | r[25]; // 40093/40094 acc32
    const int16_t whSf = static_cast<int16_t>(r[26]); // 40095
    if (wh != 0 && whSf >= 0 && whSf <= 6) {
        v.energyWh = static_cast<double>(wh) * std::pow(10.0, whSf);
    }
    v.idc = u16(r, 27, static_cast<int16_t>(r[28])); // 40096/40097
    v.udc = u16(r, 29, static_cast<int16_t>(r[30])); // 40098/40099
    v.pdc = s16(r, 31, static_cast<int16_t>(r[32])); // 40100/40101
    v.temp = s16(r, 34, static_cast<int16_t>(r[37])); // 40103 / SF 40106
    v.status = r[38]; // 40107
    v.vendorStatus = r[39]; // 40108
    if (std::isnan(v.pac) || v.pac < 0) {
        v.pac = std::isnan(v.pac) ? NAN : 0;
    }
    v.valid = true;
    return v;
}

inline const char* statusText(uint16_t s)
{
    switch (s) {
    case 1:
        return "Wyłączony";
    case 2:
        return "Uśpiony (noc)";
    case 3:
        return "Uruchamianie";
    case 4:
        return "Produkcja (MPPT)";
    case 5:
        return "Ograniczona moc";
    case 6:
        return "Wyłączanie";
    case 7:
        return "Błąd";
    case 8:
        return "Czuwanie / serwis";
    default:
        return "Nieznany";
    }
}

// Build a Modbus TCP "read holding registers" request (12 bytes)
inline void buildReadRequest(uint8_t* out, uint16_t transId, uint8_t unit, uint16_t addr, uint16_t count)
{
    out[0] = transId >> 8;
    out[1] = transId & 0xFF;
    out[2] = 0;
    out[3] = 0;
    out[4] = 0;
    out[5] = 6;
    out[6] = unit;
    out[7] = 0x03;
    out[8] = addr >> 8;
    out[9] = addr & 0xFF;
    out[10] = count >> 8;
    out[11] = count & 0xFF;
}

enum class ParseResult {
    Ok,
    Incomplete,
    BadHeader,
    Exception,
    WrongLength,
};

// Parse a response. buf/len = received bytes. On Ok, regs gets `count` registers.
inline ParseResult parseReadResponse(const uint8_t* buf, size_t len, uint16_t transId, uint16_t count, uint16_t* regs, uint8_t* exceptionCode = nullptr)
{
    if (len < 9) {
        return ParseResult::Incomplete;
    }
    const uint16_t tid = (buf[0] << 8) | buf[1];
    const uint16_t proto = (buf[2] << 8) | buf[3];
    const uint16_t mlen = (buf[4] << 8) | buf[5];
    if (tid != transId || proto != 0 || mlen < 3) {
        return ParseResult::BadHeader;
    }
    if (len < static_cast<size_t>(6 + mlen)) {
        return ParseResult::Incomplete;
    }
    if (buf[7] & 0x80) {
        if (exceptionCode) {
            *exceptionCode = buf[8];
        }
        return ParseResult::Exception;
    }
    if (buf[7] != 0x03 || buf[8] != count * 2 || mlen != 3 + count * 2) {
        return ParseResult::WrongLength;
    }
    for (uint16_t i = 0; i < count; i++) {
        regs[i] = (buf[9 + 2 * i] << 8) | buf[10 + 2 * i];
    }
    return ParseResult::Ok;
}

// ---------------------------------------------------------------------------
// Modbus RTU (RS485)
// ---------------------------------------------------------------------------

inline uint16_t crc16(const uint8_t* data, size_t len)
{
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (int b = 0; b < 8; b++) {
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
        }
    }
    return crc;
}

// Build a Modbus RTU "read holding registers" request (8 bytes)
inline void buildRtuRequest(uint8_t* out, uint8_t unit, uint16_t addr, uint16_t count)
{
    out[0] = unit;
    out[1] = 0x03;
    out[2] = addr >> 8;
    out[3] = addr & 0xFF;
    out[4] = count >> 8;
    out[5] = count & 0xFF;
    const uint16_t crc = crc16(out, 6);
    out[6] = crc & 0xFF; // CRC is sent low byte first
    out[7] = crc >> 8;
}

enum class RtuResult {
    Ok,
    Incomplete,
    WrongDevice, // answer from another slave address / unexpected function
    Exception,
    WrongLength,
    BadCrc,
};

/*
 * Parse an RTU response in buf/len. If the RS485 adapter echoes our own request,
 * pass it as `echo` (8 bytes) and it is skipped.
 */
inline RtuResult parseRtuResponse(const uint8_t* buf, size_t len, uint8_t unit, uint16_t count, uint16_t* regs,
    uint8_t* exceptionCode = nullptr, const uint8_t* echo = nullptr)
{
    if (echo != nullptr) {
        if (len < 8 && memcmp(buf, echo, len) == 0) {
            return RtuResult::Incomplete; // (part of) our own echo so far
        }
        if (len >= 8 && memcmp(buf, echo, 8) == 0) {
            buf += 8;
            len -= 8;
        }
    }
    if (len < 5) {
        return RtuResult::Incomplete;
    }
    if (buf[0] != unit) {
        return RtuResult::WrongDevice;
    }
    if (buf[1] == 0x83) {
        if (crc16(buf, 3) != (buf[3] | (buf[4] << 8))) {
            return RtuResult::BadCrc;
        }
        if (exceptionCode) {
            *exceptionCode = buf[2];
        }
        return RtuResult::Exception;
    }
    if (buf[1] != 0x03) {
        return RtuResult::WrongDevice;
    }
    if (buf[2] != count * 2) {
        return RtuResult::WrongLength;
    }
    const size_t need = 5 + 2 * static_cast<size_t>(count);
    if (len < need) {
        return RtuResult::Incomplete;
    }
    const uint16_t crc = buf[need - 2] | (buf[need - 1] << 8);
    if (crc16(buf, need - 2) != crc) {
        return RtuResult::BadCrc;
    }
    for (uint16_t i = 0; i < count; i++) {
        regs[i] = (buf[3 + 2 * i] << 8) | buf[4 + 2 * i];
    }
    return RtuResult::Ok;
}

} // namespace SunSpec
