// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

#include <ESPAsyncWebServer.h>
#include <TaskSchedulerDeclarations.h>

class WebApiDtuClass {
public:
    WebApiDtuClass();
    void init(AsyncWebServer& server, Scheduler& scheduler);

private:
    void onDtuAdminGet(AsyncWebServerRequest* request);
    void onDtuAdminPost(AsyncWebServerRequest* request);
    void onCaptureGet(AsyncWebServerRequest* request);
    void onCapturePost(AsyncWebServerRequest* request);

    Task _applyDataTask;
    void applyDataTaskCb();
};
