// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * GPIO checks shared by the SolarEdge RS485 and the status display settings:
 * rejects pins used by the board / OpenDTU pin mapping and pins taken by the
 * other add-on.
 */

#include <Arduino.h>

namespace PvPins {

// Empty if `pin` (>= 0) may be used, otherwise a reason (Polish). output: pin must drive a signal.
String problem(int pin, bool output);

// Checks a set of pins (-1 entries are ignored): validity, duplicates, reserved pins
// and pins already used by the other add-on (`otherPins`, -1 terminated count).
String checkSet(const int* pins, size_t count, const bool* outputs, const int* otherPins, size_t otherCount, const char* otherName);

} // namespace PvPins
