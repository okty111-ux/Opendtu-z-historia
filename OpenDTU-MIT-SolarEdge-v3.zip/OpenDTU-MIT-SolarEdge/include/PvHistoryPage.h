// SPDX-License-Identifier: GPL-2.0-or-later
// Generated from pvhistory/history.html by pvhistory/make_page_header.py - do not edit
#pragma once

static const char PV_HISTORY_PAGE[] = R"PVH(<!doctype html>
<html lang="pl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Statystyki PV</title>
<style>
:root{--bg:#171615;--card:#2a2826;--card2:#232120;--line:#3a3734;--txt:#f2efea;--mut:#a39d95;--acc:#f2a245;--sel:#6cc6ea;--bad:#ef7a6d;--ok:#7fd18b}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font:15px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:980px;margin:0 auto;padding:12px 16px 40px}
header{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}
header h1{font-size:18px;margin:0;font-weight:650}
header a{color:var(--mut);text-decoration:none;font-size:13px}
.row{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}
button,.btn{background:var(--card2);color:var(--txt);border:1px solid var(--line);border-radius:10px;padding:8px 14px;font:inherit;font-weight:600;cursor:pointer}
button:hover{border-color:#5a554f}
.tabs button.on{background:var(--acc);color:#2a1a05;border-color:var(--acc)}
.ranges button.on{background:var(--sel);color:#05202b;border-color:var(--sel)}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:12px 0}
.card{background:var(--card);border-radius:14px;padding:12px 14px}
.card .l{color:var(--mut);font-size:13px;font-weight:600}
.card .v{font-size:26px;font-weight:700;margin-top:2px;font-variant-numeric:tabular-nums}
.card .v.sm{font-size:18px;padding-top:6px}
.card .v small{font-size:14px;font-weight:600;color:var(--mut);margin-left:3px}
.card .s{color:var(--mut);font-size:12px;margin-top:2px}
.note{color:#e9c58f;margin:6px 0;font-size:14px}
.note.bad{color:var(--bad)}
.nav{align-items:stretch}
.nav input{background:var(--card2);color:var(--txt);border:1px solid var(--line);border-radius:10px;padding:7px 10px;font:inherit;color-scheme:dark}
.panel{background:var(--card2);border:1px solid var(--line);border-radius:14px;padding:12px;margin:10px 0}
.ch-head{display:flex;flex-wrap:wrap;gap:4px 14px;align-items:center;font-size:14px;margin-bottom:6px}
.ch-head b{margin-right:4px}
.lg{display:inline-flex;align-items:center;gap:5px}
.lg i{width:10px;height:10px;border-radius:2px;display:inline-block}
.cw{position:relative;height:300px}
canvas{width:100%;height:100%;display:block}
.tip{position:absolute;pointer-events:none;background:#0f0e0dee;border:1px solid var(--line);border-radius:8px;padding:6px 9px;font-size:12px;white-space:nowrap;display:none;z-index:2}
.tip div{display:flex;gap:6px;align-items:center}
.empty[hidden]{display:none}
.empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--mut);font-size:14px}
h2{font-size:16px;margin:16px 0 6px}
.tw{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:14px;font-variant-numeric:tabular-nums}
th,td{padding:6px 8px;text-align:right;border-bottom:1px solid var(--line);white-space:nowrap}
th:first-child,td:first-child{text-align:left}
th{color:var(--mut);font-weight:600}
tr.sum td{font-weight:700;border-top:2px solid var(--line)}
td.part{color:var(--sel)}
form label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:var(--mut)}
form input:not([type=range]),form select{background:var(--card);color:var(--txt);border:1px solid var(--line);border-radius:8px;padding:8px;font:inherit}
.hint{color:var(--mut);font-size:12.5px;margin:8px 0 0}
.grp{margin-top:10px}
.grp[hidden]{display:none}
.grid2{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}
.chk{flex-direction:row!important;align-items:center;color:var(--txt)!important}
.bar{height:10px;background:var(--card);border-radius:5px;overflow:hidden;margin:6px 0}
.bar i{display:block;height:100%;background:var(--acc)}
.msg{font-size:14px;margin-left:8px}
.danger{border-color:#7a3a33;color:var(--bad)}
.kv{display:grid;grid-template-columns:auto 1fr;gap:3px 14px;font-size:14px}
.kv span:nth-child(odd){color:var(--mut)}
</style>
</head>
<body>
<main>
<header><h1>Statystyki PV</h1><a href="/">← OpenDTU</a></header>
<div class="row tabs" id="tabs"></div>
<div id="view">
  <div class="cards" id="cards"></div>
  <div id="notes"></div>
  <div class="row ranges" id="ranges">
    <button data-r="day" class="on">Dzień</button><button data-r="7">7 dni</button><button data-r="30">30 dni</button><button data-r="all">Wszystko</button>
  </div>
  <div class="row nav">
    <button id="prev" aria-label="Poprzedni">‹</button><input type="date" id="date"><button id="next" aria-label="Następny">›</button>
    <button id="csv">Pobierz CSV</button>
  </div>
  <div class="panel">
    <div class="ch-head" id="legend"></div>
    <div class="cw" id="cw"><canvas id="cv"></canvas><div class="tip" id="tip"></div><div class="empty" id="empty" hidden>Brak danych w tym zakresie</div></div>
  </div>
  <h2>Historia dzienna</h2>
  <div class="tw"><table id="tbl"></table></div>
</div>
<div id="settings" hidden>
  <div class="panel">
    <h2 style="margin-top:0">SolarEdge</h2>
    <form id="seForm">
      <div class="grid2">
        <label class="chk"><input type="checkbox" name="enabled"> Włączony</label>
        <label>Nazwa<input name="name" maxlength="32"></label>
        <label>Połączenie<select name="transport"><option value="tcp">LAN – Modbus TCP</option><option value="rtu">RS485 – Modbus RTU</option></select></label>
        <label>Adres Modbus (ID)<input name="unit" type="number" min="1" max="247" required></label>
        <label>Odczyt co [s]<input name="interval" type="number" min="5" max="300"></label>
      </div>
      <div class="grid2 grp" data-g="tcp">
        <label>Adres IP<input name="host" maxlength="64"></label>
        <label>Port<input name="port" type="number" min="1" max="65535"></label>
      </div>
      <div class="grp" data-g="rtu">
        <div class="grid2">
          <label>Prędkość [bd]<select name="baud"><option>1200</option><option>2400</option><option>4800</option><option>9600</option><option>19200</option><option>38400</option><option>57600</option><option>115200</option></select></label>
          <label>Format<select name="parity"><option value="N">8N1 (bez parzystości)</option><option value="E">8E1 (parzysta)</option><option value="O">8O1 (nieparzysta)</option></select></label>
          <label>RX – GPIO<input name="rx" type="number" min="-1" max="48"></label>
          <label>TX – GPIO<input name="tx" type="number" min="-1" max="48"></label>
          <label>DE/RE – GPIO<input name="de" type="number" min="-1" max="48"></label>
        </div>
        <p class="hint">Moduł RS485 3,3 V (np. MAX3485) do portu <b>RS485-2</b> SolarEdge: A→A(+), B→B(−), GND→G. DE/RE = −1 dla modułu z automatycznym kierunkiem. W SetApp: <i>RS485-2 → Protokół: SunSpec (Non-SE Logger)</i>, ten sam adres (ID) i prędkość co tutaj. Piny zajęte przez radio, LED, USB i pamięć są blokowane.</p>
      </div>
      <div class="row"><button type="submit">Zapisz</button><span class="msg" id="seMsg"></span></div>
    </form>
    <div class="kv" id="seInfo"></div>
  </div>
  <div class="panel">
    <h2 style="margin-top:0">Wyświetlacz OLED 3,12" 256×64 (SSD1322, SPI)</h2>
    <form id="dpForm">
      <div class="grid2">
        <label class="chk"><input type="checkbox" name="enabled"> Włączony</label>
        <label>CLK / SCK / D0 – GPIO<input name="clk" type="number" min="-1" max="48"></label>
        <label>DIN / SDA / D1 – GPIO<input name="mosi" type="number" min="-1" max="48"></label>
        <label>CS – GPIO<input name="cs" type="number" min="-1" max="48"></label>
        <label>DC – GPIO<input name="dc" type="number" min="-1" max="48"></label>
        <label>RES – GPIO (−1 = brak)<input name="rst" type="number" min="-1" max="48"></label>
        <label>Obrót<select name="rotation"><option value="0">0°</option><option value="2">180°</option></select></label>
        <label>Jasność <span id="ctV"></span><input name="contrast" type="range" min="1" max="255"></label>
        <label>Zmiana strony co [s] (0 = tylko podsumowanie)<input name="pageSec" type="number" min="0" max="120"></label>
        <label>W nocy<select name="night"><option value="0">strony jak w dzień</option><option value="1">zegar, przyciemniony</option><option value="2">wyłączony</option></select></label>
        <label class="chk"><input type="checkbox" name="shift"> Ochrona przed wypaleniem (przesuw 1 px)</label>
      </div>
      <p class="hint">Moduł musi być ustawiony na <b>4-wire SPI</b> (zworki/rezystory BS0/BS1 – wiele modułów 3,12" wychodzi z fabryki w trybie równoległym 80xx). Zasilanie 3,3 V. Strony: podsumowanie, falownik ze stringami, szczegóły AC/DC, SolarEdge, wykres dnia. Noc = brak produkcji przez 15 min.</p>
      <div class="row"><button type="submit">Zapisz</button><span class="msg" id="dpMsg"></span></div>
    </form>
  </div>
  <div class="panel">
    <h2 style="margin-top:0">Pamięć</h2>
    <div id="stInfo"></div>
    <p style="color:var(--mut);font-size:13px">Próbki co 5 minut i podsumowania dzienne są zapisywane w pamięci flash. Gdy brakuje miejsca, najstarsze dni są automatycznie usuwane (najpierw próbki, potem podsumowania).</p>
    <div class="row"><button class="danger" id="clear">Usuń całą historię</button><span class="msg" id="clMsg"></span></div>
  </div>
</div>
</main>
<script>
"use strict";
const $=id=>document.getElementById(id);
const COL={tot:"#f2efea",se:"#c9a7ff",inv:["#6cc6ea","#62d0b4"],dc:["#f2a245","#8fd694","#ef7a6d","#e58fe0","#e8d36a","#7aa8ff"]};
let L=null,tab="tot",range="day",sel=today(),chart=null,tableRows=[],lastLoad=0;

function today(){const d=new Date();return new Date(d.getFullYear(),d.getMonth(),d.getDate())}
function ymd(d){return d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate()}
function fromYmd(n){return new Date(Math.floor(n/10000),Math.floor(n/100)%100-1,n%100)}
function iso(d){return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())}
function p2(n){return String(n).padStart(2,"0")}
function addDays(d,n){const x=new Date(d);x.setDate(x.getDate()+n);return x}
function fmtDate(d){return p2(d.getDate())+"."+p2(d.getMonth()+1)+"."+d.getFullYear()}
function fmtDT(ts){const d=new Date(ts*1000);return fmtDate(d)+" "+p2(d.getHours())+":"+p2(d.getMinutes())}
function num(v,dec){return v==null||isNaN(v)?"–":Number(v).toLocaleString("pl-PL",{minimumFractionDigits:dec,maximumFractionDigits:dec})}
function kwh(wh){return num(wh/1000,wh>=100000?1:2)}
function esc(s){return String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}

async function getJSON(u,o){const r=await fetch(u,o);if(!r.ok)throw new Error(r.status);return r.json()}

// ---- column helpers (layout must match PvHistory.cpp) ----
function sIdx(){const MI=L.maxInv,MD=L.maxDc;return{tot:1,se:2,inv:i=>3+i*(1+MD),dc:(i,c)=>4+i*(1+MD)+c,seT:3+MI*(1+MD),invT:i=>4+MI*(1+MD)+i}}
function dIdx(){const MI=L.maxInv,MD=L.maxDc;return{tot:1,se:2,inv:i=>3+i*(1+MD),dc:(i,c)=>4+i*(1+MD)+c,peak:3+MI*(1+MD),part:4+MI*(1+MD)}}

// ---- tabs ----
function tabsList(){
  const t=[{id:"tot",name:"Razem"}];
  const many=L.inverters.length>1;
  L.inverters.forEach((v,i)=>{
    t.push({id:"inv"+i,name:v.name||("Falownik "+(i+1))});
    v.strings.forEach((s,c)=>t.push({id:"dc"+i+"_"+c,name:(many?(v.name+": "):"")+s.name}));
  });
  if(L.solaredge.enabled)t.push({id:"se",name:L.solaredge.name||"SolarEdge"});
  t.push({id:"cfg",name:"⚙ Ustawienia"});
  return t;
}
function renderTabs(){
  const list=tabsList();
  if(!list.some(x=>x.id===tab))tab="tot";
  $("tabs").innerHTML=list.map(x=>`<button data-t="${x.id}" class="${x.id===tab?"on":""}">${esc(x.name)}</button>`).join("");
}
$("tabs").onclick=e=>{const b=e.target.closest("button");if(!b)return;tab=b.dataset.t;renderTabs();showView();renderLive();loadData()};

function parseTab(){
  if(tab.startsWith("inv"))return{k:"inv",i:+tab.slice(3)};
  if(tab.startsWith("dc")){const[a,b]=tab.slice(2).split("_");return{k:"dc",i:+a,c:+b}}
  return{k:tab};
}

// ---- live cards ----
function card(l,v,u,s){return`<div class="card"><div class="l">${l}</div><div class="v${String(v).length>9?" sm":""}">${v}${u?`<small>${u}</small>`:""}</div>${s?`<div class="s">${s}</div>`:""}</div>`}
function renderLive(){
  if(!L)return;
  const t=parseTab(),C=[],N=[];
  const invNote=v=>{if(!v.reachable)N.push(`Falownik „${esc(v.name)}” nieosiągalny (noc?)`+(v.lastSeen?` – pokazuję ostatni odczyt · ${fmtDT(v.lastSeen)}`:""))};
  const seNote=()=>{const s=L.solaredge;if(s.enabled&&!s.online)N.push(`${esc(s.name)} offline${s.error?": "+esc(s.error):""}`+(s.lastSeen?` · ostatni odczyt ${fmtDT(s.lastSeen)}`:""))};
  if(t.k==="tot"){
    C.push(card("Moc",num(L.total.pac,0),"W"),card("Dziś",kwh(L.total.todayWh),"kWh"),card("Razem",num(L.total.totalKwh,1),"kWh"),card("Szczyt dziś",num(L.total.peakW,0),"W"));
    L.inverters.forEach(v=>{C.push(card(esc(v.name),num(v.pac,0),"W",kwh(v.todayWh)+" kWh dziś"));invNote(v)});
    if(L.solaredge.enabled){const s=L.solaredge;C.push(card(esc(s.name),num(s.pac,0),"W",kwh(s.todayWh)+" kWh dziś"));seNote()}
  }else if(t.k==="inv"){
    const v=L.inverters[t.i];if(!v)return;
    C.push(card("Moc",num(v.reachable?v.pac:v.pacLast,0),"W"),card("Dziś",kwh(v.todayWh),"kWh"),card("Razem",num(v.totalKwh,1),"kWh"),card("Temperatura",num(v.temp,1),"°C"));
    if(v.uac&&v.uac.length)C.push(card("Napięcie AC",v.uac.map(x=>num(x,1)).join(" / "),"V"));
    if(v.freq!=null)C.push(card("Częstotliwość",num(v.freq,2),"Hz"));
    if(v.eff!=null)C.push(card("Sprawność",num(v.eff,1),"%"));
    invNote(v);
  }else if(t.k==="dc"){
    const v=L.inverters[t.i],s=v&&v.strings[t.c];if(!s)return;
    C.push(card("Moc",num(s.pdc,0),"W"),card("Dziś",kwh(s.todayWh),"kWh"),card("Razem",num(s.totalKwh,1),"kWh"),card("Napięcie / prąd",num(s.udc,1)+" V",""," "+num(s.idc,2)+" A"));
    invNote(v);
  }else if(t.k==="se"){
    const s=L.solaredge;
    C.push(card("Moc",num(s.pac,0),"W"),card("Dziś",kwh(s.todayWh),"kWh"),card("Razem",num(s.totalKwh,1),"kWh"),card("Temperatura",num(s.temp,1),"°C"));
    if(s.statusText)C.push(card("Status",esc(s.statusText),""));
    if(s.uac&&s.uac.length)C.push(card("Napięcie AC",s.uac.map(x=>num(x,1)).join(" / "),"V"));
    if(s.udc!=null)C.push(card("DC",num(s.udc,0)+" V",""," "+num(s.pdc,0)+" W"));
    seNote();
  }
  $("cards").innerHTML=C.join("");
  if(!L.synced)N.unshift("Brak synchronizacji czasu (NTP) – zapis historii wstrzymany");
  $("notes").innerHTML=N.map(n=>`<div class="note">${n}</div>`).join("");
  if(tab==="cfg")renderSettingsInfo();
}

// ---- series definition for current tab ----
function seriesFor(kind){
  const t=parseTab(),S=[],I=kind==="s"?sIdx():dIdx();
  if(t.k==="tot"){
    if(kind==="s")S.push({n:"Razem",c:COL.tot,i:I.tot,stack:false});
    L.inverters.forEach((v,i)=>S.push({n:v.name,c:COL.inv[i%2],i:I.inv(i),stack:true}));
    if(L.solaredge.enabled)S.push({n:L.solaredge.name,c:COL.se,i:I.se,stack:true});
  }else if(t.k==="inv"){
    const v=L.inverters[t.i];S.push({n:"AC",c:COL.inv[0],i:I.inv(t.i)});
    if(kind==="s"||range!=="all")v.strings.forEach((s,c)=>S.push({n:s.name,c:COL.dc[c%6],i:I.dc(t.i,c),noBar:true}));
  }else if(t.k==="dc"){
    const s=L.inverters[t.i].strings[t.c];S.push({n:s.name,c:COL.dc[t.c%6],i:I.dc(t.i,t.c)});
  }else if(t.k==="se")S.push({n:L.solaredge.name,c:COL.se,i:I.se});
  return S;
}

// ---- data loading ----
function rangeBounds(){
  const end=addDays(sel,1);
  if(range==="day")return{from:sel,to:end};
  if(range==="7")return{from:addDays(end,-7),to:end};
  if(range==="30")return{from:addDays(end,-30),to:end};
  return{from:new Date(2000,0,1),to:end};
}
async function loadData(){
  if(!L||tab==="cfg")return;
  lastLoad=Date.now();
  const b=rangeBounds(),f=Math.floor(b.from/1000),t=Math.floor(b.to/1000)-1;
  const dFrom=ymd(range==="day"?addDays(sel,-6):b.from),dTo=ymd(addDays(b.to,-1));
  try{
    const days=await getJSON(`/api/history/days?from=${dFrom}&to=${dTo}`);
    tableRows=days.rows;
    renderTable();
    if(range==="day"||range==="7"){
      const step=range==="day"?L.interval:1800;
      const s=await getJSON(`/api/history/samples?from=${f}&to=${t}&step=${step}`);
      drawLines(s.rows,seriesFor("s"),f,t,step);
    }else{
      drawBars(days.rows.filter(r=>r[0]>=ymd(b.from)),seriesFor("d"),range==="30"?b.from:null,b.to);
    }
  }catch(e){$("empty").hidden=false;$("empty").textContent="Błąd ładowania danych ("+e.message+")"}
}

// ---- table ----
function renderTable(){
  const t=parseTab(),I=dIdx();let cols;
  if(t.k==="tot"){cols=[{n:"Razem",i:I.tot}];L.inverters.forEach((v,i)=>cols.push({n:v.name,i:I.inv(i)}));if(L.solaredge.enabled)cols.push({n:L.solaredge.name,i:I.se});cols.push({n:"Szczyt",i:I.peak,w:1})}
  else if(t.k==="inv"){const v=L.inverters[t.i];cols=[{n:"Razem",i:I.inv(t.i)}];v.strings.forEach((s,c)=>cols.push({n:s.name,i:I.dc(t.i,c)}))}
  else if(t.k==="dc"){cols=[{n:L.inverters[t.i].strings[t.c].name,i:I.dc(t.i,t.c)}]}
  else cols=[{n:L.solaredge.name,i:I.se}];
  const rows=[...tableRows].sort((a,b)=>b[0]-a[0]);
  let h=`<tr><th>Data</th>${cols.map(c=>`<th>${esc(c.n)}${c.w?" [W]":" [kWh]"}</th>`).join("")}</tr>`;
  const sum=cols.map(()=>0);
  rows.forEach(r=>{h+=`<tr><td class="${r[I.part]?"part":""}">${fmtDate(fromYmd(r[0]))}${r[I.part]?" ●":""}</td>`+cols.map((c,k)=>{if(!c.w)sum[k]+=r[c.i];return`<td>${c.w?num(r[c.i],0):kwh(r[c.i])}</td>`}).join("")+"</tr>"});
  if(rows.length>1)h+=`<tr class="sum"><td>Suma</td>${cols.map((c,k)=>`<td>${c.w?"":kwh(sum[k])}</td>`).join("")}</tr>`;
  if(!rows.length)h+=`<tr><td colspan="${cols.length+1}" style="text-align:center;color:var(--mut)">Brak zapisanych dni</td></tr>`;
  $("tbl").innerHTML=h;
}

// ---- chart ----
const cv=$("cv"),ctx=cv.getContext("2d"),tip=$("tip");
function legend(title,S){$("legend").innerHTML=`<b>${title}</b>`+S.map(s=>`<span class="lg" style="color:${s.c}"><i style="background:${s.c}"></i>${esc(s.n)}</span>`).join("")}
function setupCanvas(){const r=cv.getBoundingClientRect(),d=window.devicePixelRatio||1;cv.width=r.width*d;cv.height=r.height*d;ctx.setTransform(d,0,0,d,0,0);return{w:r.width,h:r.height}}
function niceMax(v){if(v<=0)return 1;const e=Math.pow(10,Math.floor(Math.log10(v))),m=v/e;return(m<=1?1:m<=2?2:m<=2.5?2.5:m<=5?5:10)*e}
function frame(w,h,max,unit){
  const P={l:48,r:8,t:8,b:24},W=w-P.l-P.r,H=h-P.t-P.b;
  ctx.clearRect(0,0,w,h);ctx.font="11px system-ui,sans-serif";ctx.fillStyle="#a39d95";ctx.strokeStyle="#3a3734";ctx.lineWidth=1;
  for(let k=0;k<=4;k++){const y=P.t+H-H*k/4;ctx.beginPath();ctx.moveTo(P.l,y+.5);ctx.lineTo(P.l+W,y+.5);ctx.stroke();ctx.textAlign="right";ctx.textBaseline="middle";ctx.fillText(num(max*k/4,(max/4)%1?((max/4*10)%1?2:1):0),P.l-6,y)}
  return{P,W,H};
}
function drawLines(rows,S,f,t,step){
  legend("Moc [W]",S);
  const{w,h}=setupCanvas();$("empty").hidden=rows.length>0;
  // insert zeros where data is missing (night / outage)
  const pts=[];let prev=null;
  rows.forEach(r=>{if(prev&&r[0]-prev[0]>step*2.5){pts.push(zero(prev[0]+step,r.length));pts.push(zero(r[0]-step,r.length))}pts.push(r);prev=r});
  function zero(ts,n){const z=new Array(n).fill(0);z[0]=ts;return z}
  let max=0;pts.forEach(r=>S.forEach(s=>{if(r[s.i]>max)max=r[s.i]}));max=niceMax(max*1.05);
  const{P,W,H}=frame(w,h,max);
  const X=ts=>P.l+(ts-f)/(t-f)*W,Y=v=>P.t+H-v/max*H;
  // time axis
  ctx.textAlign="center";ctx.textBaseline="top";ctx.fillStyle="#a39d95";
  if(t-f<=86400*1.5){const hs=W<420?6:3;for(let hh=0;hh<=24;hh+=hs){const ts=f+hh*3600;ctx.fillText(p2(hh)+":00",Math.min(Math.max(X(ts),P.l+14),P.l+W-14),P.t+H+6)}}
  else{for(let ts=f;ts<t;ts+=86400){const d=new Date(ts*1000);ctx.fillText(p2(d.getDate())+"."+p2(d.getMonth()+1),X(ts+43200),P.t+H+6);ctx.strokeStyle="#2f2c29";ctx.beginPath();ctx.moveTo(X(ts)+.5,P.t);ctx.lineTo(X(ts)+.5,P.t+H);ctx.stroke()}}
  [...S].reverse().forEach(s=>{
    ctx.strokeStyle=s.c;ctx.lineWidth=s.i===1?2.2:1.6;ctx.lineJoin="round";ctx.beginPath();
    pts.forEach((r,k)=>{const x=X(r[0]+step/2),y=Y(r[s.i]);k?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();
    if(S.length===1||s.i===1){ctx.globalAlpha=.12;ctx.fillStyle=s.c;ctx.lineTo(X(pts.length?pts[pts.length-1][0]+step/2:f),P.t+H);ctx.lineTo(X(pts.length?pts[0][0]+step/2:f),P.t+H);ctx.fill();ctx.globalAlpha=1}
  });
  chart={type:"line",rows,S,X,P,W,H,step,label:r=>fmtDT(r[0])+(step>L.interval?" – "+fmtDT(r[0]+step).slice(11):""),val:v=>num(v,0)+" W"};
}
function drawBars(rows,S,from,to){
  const monthly=!from&&rows.length>92;
  let data=rows.map(r=>({k:r[0],r}));
  if(monthly){const m=new Map();rows.forEach(r=>{const k=Math.floor(r[0]/100);if(!m.has(k))m.set(k,r.map(()=>0));const a=m.get(k);r.forEach((v,i)=>a[i]+=v)});data=[...m].map(([k,a])=>{a[0]=k*100+1;return{k,r:a}})}
  else if(from){const all=[];for(let d=new Date(from);d<to;d=addDays(d,1)){const k=ymd(d);all.push(data.find(x=>x.k===k)||{k,r:null})}data=all}
  const BS=S.filter(s=>!s.noBar);
  legend("Energia [kWh]"+(monthly?" – miesięcznie":""),BS);
  const{w,h}=setupCanvas();$("empty").hidden=rows.length>0;
  const stacked=BS.some(s=>s.stack);
  let max=0;data.forEach(d=>{if(!d.r)return;const v=stacked?BS.reduce((a,s)=>a+d.r[s.i],0):Math.max(...BS.map(s=>d.r[s.i]));if(v>max)max=v});
  max=niceMax(max/1000*1.05);
  const{P,W,H}=frame(w,h,max);
  const n=Math.max(data.length,1),bw=W/n,gap=Math.min(bw*.25,6);
  const every=Math.ceil(n/(W/44));
  ctx.textAlign="center";ctx.textBaseline="top";
  data.forEach((d,k)=>{
    const x=P.l+k*bw+gap/2,iw=bw-gap;
    if(k%every===0){ctx.fillStyle="#a39d95";const lab=monthly?p2(d.k%100)+"."+String(Math.floor(d.k/100)).slice(2):p2(d.k%100)+"."+p2(Math.floor(d.k/100)%100);ctx.fillText(lab,x+iw/2,P.t+H+6)}
    if(!d.r)return;
    if(stacked){let y0=P.t+H;BS.forEach(s=>{const hh=d.r[s.i]/1000/max*H;ctx.fillStyle=s.c;ctx.fillRect(x,y0-hh,iw,hh);y0-=hh})}
    else{const sw=iw/BS.length;BS.forEach((s,j)=>{const hh=d.r[s.i]/1000/max*H;ctx.fillStyle=s.c;ctx.fillRect(x+j*sw,P.t+H-hh,sw,hh)})}
  });
  chart={type:"bar",data,S:BS,P,W,H,bw,label:d=>monthly?p2(d.k%100)+"."+Math.floor(d.k/100):fmtDate(fromYmd(d.k)),val:v=>kwh(v)+" kWh"};
}
cv.addEventListener("pointermove",e=>{
  if(!chart)return;const r=cv.getBoundingClientRect(),x=e.clientX-r.left;let row=null,lab="";
  if(chart.type==="line"){let best=1e18;chart.rows.forEach(q=>{const dx=Math.abs(chart.X(q[0]+chart.step/2)-x);if(dx<best){best=dx;row=q}});if(!row||best>30){tip.style.display="none";return}lab=chart.label(row)}
  else{const k=Math.floor((x-chart.P.l)/chart.bw),d=chart.data[k];if(!d||!d.r){tip.style.display="none";return}row=d.r;lab=chart.label(d)}
  let tot="";if(chart.type==="bar"&&chart.S.length>1&&chart.S.some(s=>s.stack))tot=`<div><b>Razem: ${chart.val(chart.S.reduce((a,s)=>a+row[s.i],0))}</b></div>`;
  tip.innerHTML=`<div><b>${lab}</b></div>`+chart.S.map(s=>`<div><i style="width:8px;height:8px;background:${s.c};display:inline-block;border-radius:2px"></i>${esc(s.n)}: ${chart.val(row[s.i])}</div>`).join("")+tot;
  tip.style.display="block";const tw=tip.offsetWidth;tip.style.left=Math.min(Math.max(x+12,0),r.width-tw-4)+"px";tip.style.top="8px";
});
cv.addEventListener("pointerleave",()=>tip.style.display="none");
window.addEventListener("resize",()=>{clearTimeout(window._rz);window._rz=setTimeout(loadData,200)});

// ---- range / date navigation ----
$("ranges").onclick=e=>{const b=e.target.closest("button");if(!b)return;range=b.dataset.r;[...$("ranges").children].forEach(x=>x.classList.toggle("on",x===b));loadData()};
function setDate(d){if(d>today())d=today();sel=d;$("date").value=iso(d);loadData()}
$("date").onchange=()=>{const v=$("date").value;if(v){const[a,b,c]=v.split("-").map(Number);setDate(new Date(a,b-1,c))}};
$("prev").onclick=()=>setDate(addDays(sel,range==="7"?-7:range==="30"?-30:-1));
$("next").onclick=()=>setDate(addDays(sel,range==="7"?7:range==="30"?30:1));
$("csv").onclick=()=>{
  const b=rangeBounds();
  if(range==="day"||range==="7")location.href=`/api/history/samples?csv=1&from=${Math.floor(b.from/1000)}&to=${Math.floor(b.to/1000)-1}`;
  else location.href=`/api/history/days?csv=1&from=${ymd(b.from)}&to=${ymd(addDays(b.to,-1))}`;
};

// ---- settings ----
function showView(){const c=tab==="cfg";$("view").hidden=c;$("settings").hidden=!c;if(c)loadSettings()}
async function loadSettings(){
  loadDisplay();
  try{const c=await getJSON("/api/history/config"),f=$("seForm");f.enabled.checked=c.enabled;["name","transport","host","port","unit","interval","baud","parity","rx","tx","de"].forEach(k=>{if(f[k]&&c[k]!=null)f[k].value=c[k]});showGroups()}catch(e){$("seMsg").textContent="Błąd: "+e.message}
  renderSettingsInfo();
}
async function loadDisplay(){
  try{const c=await getJSON("/api/history/display"),f=$("dpForm");f.enabled.checked=c.enabled;f.shift.checked=c.shift;
    ["clk","mosi","cs","dc","rst","rotation","contrast","pageSec","night"].forEach(k=>{if(c[k]!=null)f[k].value=c[k]});$("ctV").textContent=f.contrast.value;
    $("dpMsg").textContent=c.enabled?(c.running?"działa":(c.problem||"nie uruchomiony")):"";$("dpMsg").style.color=c.running?"var(--ok)":"var(--bad)"}
  catch(e){$("dpMsg").textContent="Błąd: "+e.message}
}
$("dpForm").contrast.oninput=e=>$("ctV").textContent=e.target.value;
$("dpForm").onsubmit=async e=>{
  e.preventDefault();const f=e.target,d={enabled:f.enabled.checked,shift:f.shift.checked};["clk","mosi","cs","dc","rst","rotation","contrast","pageSec","night"].forEach(k=>d[k]=+f[k].value);
  $("dpMsg").textContent="Zapisywanie…";$("dpMsg").style.color="";
  try{const r=await getJSON("/api/history/display",{method:"POST",body:new URLSearchParams({data:JSON.stringify(d)})});$("dpMsg").textContent=r.message||"OK";$("dpMsg").style.color=r.type==="success"?"var(--ok)":"var(--bad)"}
  catch(err){$("dpMsg").textContent=err.message==="401"?"Wymagane logowanie (admin + hasło OpenDTU)":"Błąd: "+err.message;$("dpMsg").style.color="var(--bad)"}
};
function renderSettingsInfo(){
  if(!L)return;const s=L.solaredge,st=L.storage;
  const kv=[["Połączenie",s.transport==="rtu"?"RS485 (Modbus RTU), ID "+s.unit:"LAN "+s.host+":"+s.port+", ID "+s.unit],["Stan",s.enabled?(s.online?"online":"offline"+(s.error?" – "+s.error:"")):"wyłączony"],["Model",[s.manufacturer,s.model].filter(Boolean).join(" ")||"–"],["Nr seryjny",s.serial||"–"],["Firmware",s.version||"–"],["Status",s.statusText||"–"],["Ostatni odczyt",s.lastSeen?fmtDT(s.lastSeen):"–"]];
  $("seInfo").innerHTML=kv.map(([a,b])=>`<span>${a}</span><span>${esc(b)}</span>`).join("");
  const pct=st.fsTotal?st.fsUsed/st.fsTotal*100:0;
  $("stInfo").innerHTML=`<div class="bar"><i style="width:${pct.toFixed(1)}%"></i></div><div class="kv"><span>Zajęte</span><span>${num(st.fsUsed/1024,0)} / ${num(st.fsTotal/1024,0)} kB (${num(pct,0)}%, rezerwa ${num(st.reserve/1024,0)} kB)</span><span>Dni z próbkami 5-min</span><span>${st.sampleDays}${st.oldestSample?" (od "+fmtDate(fromYmd(st.oldestSample))+")":""}</span><span>Podsumowania dzienne</span><span>${st.dayRecords}${st.oldestDay?" (od "+fmtDate(fromYmd(st.oldestDay))+")":""}</span></div>`;
}
function showGroups(){const t=$("seForm").transport.value;document.querySelectorAll(".grp").forEach(g=>g.hidden=g.dataset.g!==t)}
$("seForm").transport.onchange=showGroups;
$("seForm").onsubmit=async e=>{
  e.preventDefault();const f=e.target,d={enabled:f.enabled.checked,name:f.name.value.trim(),transport:f.transport.value,unit:+f.unit.value,interval:+f.interval.value,host:f.host.value.trim(),port:+f.port.value,baud:+f.baud.value,parity:f.parity.value,rx:+f.rx.value,tx:+f.tx.value,de:+f.de.value};
  $("seMsg").textContent="Zapisywanie…";
  try{const r=await getJSON("/api/history/config",{method:"POST",body:new URLSearchParams({data:JSON.stringify(d)})});$("seMsg").textContent=r.message||"OK";$("seMsg").style.color=r.type==="success"?"var(--ok)":"var(--bad)";refreshLive()}catch(err){$("seMsg").textContent=err.message==="401"?"Wymagane logowanie (admin + hasło OpenDTU)":"Błąd: "+err.message}
};
$("clear").onclick=async()=>{
  if(!confirm("Na pewno usunąć całą zapisaną historię? Tej operacji nie można cofnąć."))return;
  try{const r=await getJSON("/api/history/clear",{method:"POST"});$("clMsg").textContent=r.message;refreshLive()}catch(err){$("clMsg").textContent=err.message==="401"?"Wymagane logowanie":"Błąd: "+err.message}
};

// ---- live refresh ----
async function refreshLive(){
  try{
    const first=!L;L=await getJSON("/api/history/live");
    renderTabs();renderLive();
    if(first){showView();loadData()}
    else if(sel.getTime()===today().getTime()&&Date.now()-lastLoad>60000)loadData();
  }catch(e){$("notes").innerHTML=`<div class="note bad">Brak połączenia z OpenDTU (${esc(e.message)})</div>`}
}
$("date").value=iso(sel);
refreshLive();setInterval(refreshLive,10000);
</script>
</body>
</html>
)PVH";
