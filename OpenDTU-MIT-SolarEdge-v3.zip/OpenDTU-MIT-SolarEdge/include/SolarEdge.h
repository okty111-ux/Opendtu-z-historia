// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * SolarEdge inverter reader (SunSpec).
 * Transport: Modbus TCP (LAN) or Modbus RTU (RS485, e.g. SolarEdge RS485-2 port).
 * Polling runs in its own FreeRTOS task so a slow or unreachable inverter
 * never blocks the Hoymiles radio handling in the main loop.
 */

#include "SunSpecDecode.h"
#include <Arduino.h>
#include <HardwareSerial.h>
#include <TaskSchedulerDeclarations.h>
#include <WiFiClient.h>
#include <mutex>

enum class SolarEdgeTransport : uint8_t {
    Tcp = 0,
    Rtu = 1,
};

struct SolarEdgeConfig {
    bool enabled = true;
    SolarEdgeTransport transport = SolarEdgeTransport::Tcp;
    uint8_t unitId = 1; // Modbus device ID (both transports)
    char name[33] = "SolarEdge";
    uint16_t intervalSec = 10;

    // Modbus TCP
    char host[65] = "192.168.0.18";
    uint16_t port = 1502;

    // Modbus RTU (RS485)
    uint32_t baud = 9600;
    char parity = 'N'; // 'N', 'E' or 'O' (8 data bits, 1 stop bit)
    int8_t rxPin = -1;
    int8_t txPin = -1;
    int8_t dePin = -1; // DE/RE of the RS485 transceiver, -1 = module with automatic direction
};

struct SolarEdgeSnapshot {
    bool enabled = false;
    bool online = false; // successful poll within the last 60 s
    uint32_t lastUpdateMs = 0; // millis() of last successful poll, 0 = never
    uint32_t lastUpdateEpoch = 0;
    char lastError[64] = {};
    SunSpec::Common common;
    SunSpec::Inverter inv;
};

class SolarEdgeClass {
public:
    void init(Scheduler& scheduler);

    SolarEdgeConfig getConfig();
    bool setConfig(const SolarEdgeConfig& cfg); // saves to /solaredge.json and reconnects

    SolarEdgeSnapshot getSnapshot();

    // Empty string if the RS485 settings are usable, otherwise a reason (Polish)
    static String validateRtu(const SolarEdgeConfig& cfg);

private:
    static void taskEntry(void* arg);
    void taskLoop();
    bool loadConfig();
    bool saveConfig();
    bool readRegisters(const SolarEdgeConfig& cfg, uint16_t addr, uint16_t count, uint16_t* regs);
    bool readTcp(const SolarEdgeConfig& cfg, uint16_t addr, uint16_t count, uint16_t* regs);
    bool readRtu(const SolarEdgeConfig& cfg, uint16_t addr, uint16_t count, uint16_t* regs);
    bool openTransport(const SolarEdgeConfig& cfg);
    void closeTransport();
    void setError(const char* msg);

    std::mutex _mutex;
    SolarEdgeConfig _cfg;
    SolarEdgeSnapshot _snap;
    volatile bool _reconnect = true;
    uint16_t _transId = 1;
    TaskHandle_t _task = nullptr;

    WiFiClient _client;
    HardwareSerial _serial { 1 }; // UART1
    bool _serialOpen = false;
    int8_t _openDePin = -1;
};

extern SolarEdgeClass SolarEdge;
