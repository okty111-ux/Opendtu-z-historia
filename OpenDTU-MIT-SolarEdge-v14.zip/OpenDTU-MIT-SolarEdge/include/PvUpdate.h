// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * PvUpdate - firmware update pulled by the device itself from the GitHub
 * releases of the project repository ("releases/latest/download/...").
 * Only one click goes over a (slow) VPN; the 2.5 MB download runs on the
 * device's own internet connection. Integrity is checked with SHA-256.
 */

#include <Arduino.h>
#include <ESPAsyncWebServer.h>
#include <mutex>

#ifndef PV_BUILD_NUMBER
#define PV_BUILD_NUMBER 0 // set by the GitHub workflow (-DPV_BUILD_NUMBER=<run number>)
#endif

enum class PvUpdateState : uint8_t {
    Idle,
    Checking,
    Checked, // info about the latest release available
    Downloading,
    Done, // flashed, restarting
    Error,
};

struct PvUpdateInfo {
    uint32_t build = 0;
    uint32_t size = 0;
    char sha256[65] = {};
    char date[24] = {};
};

struct PvUpdateStatus {
    PvUpdateState state = PvUpdateState::Idle;
    PvUpdateInfo latest;
    uint32_t done = 0; // bytes written
    char message[200] = {};
};

struct PvUpdateConfig {
    char repo[96] = "okty111-ux/Opendtu-z-historia";
    bool insecure = false; // skip TLS certificate verification (fallback only)
};

class PvUpdateClass {
public:
    void init();
    void initWeb(AsyncWebServer& server);

    PvUpdateStatus getStatus();
    PvUpdateConfig getConfig();
    bool setConfig(const PvUpdateConfig& cfg);

    bool startCheck();
    bool startInstall();

private:
    enum class Job : uint8_t { Check,
        Install };

    bool start(Job job);
    static void taskEntry(void* arg);
    void run(Job job);
    bool fetchInfo(const PvUpdateConfig& cfg, PvUpdateInfo& info);
    bool install(const PvUpdateConfig& cfg, const PvUpdateInfo& info);
    String assetUrl(const PvUpdateConfig& cfg, const char* ext) const;
    void setState(PvUpdateState s, const char* msg = nullptr);
    void fail(const char* msg);

    void onGet(AsyncWebServerRequest* request);
    void onPost(AsyncWebServerRequest* request);

    bool loadConfig();
    bool saveConfig();

    std::mutex _mutex;
    PvUpdateStatus _status;
    PvUpdateConfig _cfg;
    volatile bool _busy = false;
    Job _job = Job::Check;
};

extern PvUpdateClass PvUpdate;
