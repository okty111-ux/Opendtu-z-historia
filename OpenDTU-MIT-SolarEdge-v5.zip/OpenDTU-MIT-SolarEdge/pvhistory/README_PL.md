# OpenDTU Fusion v2 + MIT-5000-8T + SolarEdge + historia

Ta paczka to OpenDTU z gałęzią obsługi MIT-5000-8T (PR #3161, commit b22cdb1) oraz dodatkami:

* **SolarEdge (SunSpec)** przez **LAN (Modbus TCP)** albo **RS485 (Modbus RTU)** z wyborem adresu (ID 1–247) –
  odczyt co 10 s: moc, energia, napięcia, DC, temperatura, status.
* **Historia produkcji w pamięci flash** – próbki co 5 minut (średnie) + podsumowania dzienne
  (MIT: AC i każdy string osobno, SolarEdge, razem, szczyt). Gdy kończy się miejsce,
  **najstarsze dni są automatycznie usuwane** (najpierw próbki 5-min, potem podsumowania).
* **Strona `http://192.168.0.222/history`** – zakładki Razem / falownik / String 1–4 / SolarEdge,
  zakresy Dzień / 7 dni / 30 dni / Wszystko, eksport CSV (do Excela), tabela „Historia dzienna”,
  ustawienia SolarEdge (LAN/RS485, adres) i stan pamięci.

* **Wyświetlacz OLED 3,12" 256×64 (SSD1322, SPI)** – dane na żywo, strony przełączane co kilka sekund:
  podsumowanie (moc, dziś, łącznie, każde źródło), falownik MIT ze słupkami 4 stringów, szczegóły
  (L1–L3, częstotliwość, U/I i kWh każdego stringa), SolarEdge, wykres produkcji dnia. W nocy przyciemniony zegar
  (albo wyłączony), przesuw o 1 px przeciw wypaleniu OLED.

## Wyświetlacz – co kupić i jak podłączyć
* Moduł **3,12" OLED 256×64, sterownik SSD1322, interfejs SPI** (kolor żółty/biały/zielony/niebieski).
  Szukaj ogłoszeń z „SPI” lub „4-wire SPI”. Wiele modułów wychodzi w trybie równoległym 80xx – wtedy trzeba
  przelutować rezystory/zworki BS0/BS1 na 4SPI według opisu sprzedawcy.
* Zasilanie **3,3 V** (moduł ma własną przetwornicę na OLED). Pobór do ok. 0,2 A przy jasnym obrazie.
* Przewody: GND, VCC 3,3 V, **CLK/SCK (D0)**, **DIN/SDA (D1)**, **CS**, **DC**, **RES** (opcjonalnie) – 5 wolnych GPIO
  z płytki Fusion. Numery GPIO wpisujesz w `/history` → ⚙ Ustawienia → Wyświetlacz; piny zajęte przez radio,
  LED, USB, pamięć PSRAM i RS485 są odrzucane.
* **Przełączanie ekranów:**
  * automatycznie co N sekund (ustawienie „Zmiana strony co”, 0 = tylko podsumowanie),
  * **przycisk** chwilowy między wolnym GPIO a GND (rezystor niepotrzebny – wewnętrzny pull-up), pin w ustawieniach:
    krótko = następny ekran (auto wraca po 60 s), przytrzymanie 1 s = przypnij / odepnij ekran,
    w nocy pierwsze naciśnięcie budzi wyświetlacz na minutę,
  * **ze strony `/history`** – pasek „🖥 Wyświetlacz” na górze: ◀ ▶, lista ekranów, „📌 Przypnij”.
  * Na ekranie numer strony w ramce = sterowanie ręczne, w odwróconym polu = ekran przypięty.
* Wyświetlacz działa niezależnie od wbudowanego ekranu OpenDTU (ten zostaw na „brak”) i rysuje w osobnym zadaniu,
  więc nie spowalnia komunikacji radiowej.

## 1. Przygotowanie SolarEdge
W SetApp (lub na wyświetlaczu falownika): *Communication → LAN Conf → Modbus TCP → Enable*,
port domyślnie **1502**, Device ID **1**. SolarEdge przyjmuje **tylko jedno** połączenie Modbus TCP –
jeśli Home Assistant ma już integrację „SolarEdge Modbus”, jedno z nich nie dostanie danych.

### Wariant RS485 (port RS485-2 SolarEdge)
* Moduł RS485 zasilany **3,3 V** (np. MAX3485 / SP3485; moduł 5 V tylko z konwerterem poziomów).
  Połączenie: A → A(+), B → B(−), GND → G. Na końcu linii terminator 120 Ω (w SolarEdge przełącznik).
* Piny wybierasz na stronie: RX, TX i opcjonalnie DE/RE (−1 = moduł z automatycznym kierunkiem).
  Piny używane przez radio CMT/NRF, LED, USB, PSRAM i ewentualny Ethernet są odrzucane przy zapisie.
* SetApp: *Communication → RS485-2 Conf → Protocol: SunSpec (Non-SE Logger)*, ustaw **Device ID**
  i prędkość – te same wartości wpisz na stronie (domyślnie 9600, 8N1, ID 1).
* Niektóre modele mają RS485-2 dopiero po dołożeniu modułu „RS485 Plug-in”.

## 2. Budowanie
1. VS Code + PlatformIO, otwórz ten folder.
2. Środowisko **`opendtufusionv2`** (to samo co teraz masz) → *Build*.
3. Plik: `.pio/build/opendtufusionv2/firmware.bin` → w OpenDTU: *Ustawienia → Aktualizacja oprogramowania* (OTA).
   Ustawienia OpenDTU zostają.

Domyślna partycja LittleFS ma 192 kB → ok. **2 tygodnie** wykresów 5-min i kilka lat podsumowań dziennych.

### Opcjonalnie: więcej historii (ok. 6–8 miesięcy wykresów 5-min)
Środowisko **`opendtufusionv2_history`** (2,9 MB na historię, OTA nadal działa). Zmiana partycji
wymaga **jednorazowego** wgrania przez USB i **kasuje ustawienia**:
1. OpenDTU → *Ustawienia → Zarządzanie konfiguracją* → pobierz kopię `config.json`.
2. Zbuduj `opendtufusionv2_history`, wgraj przez USB (*Upload*) lub `opendtu-*.factory.bin` pod adres 0x0.
3. Połącz się z AP „OpenDTU-…” (hasło `openDTU42`), przywróć `config.json`.

## 3. Konfiguracja
`/history` → **⚙ Ustawienia**: rodzaj połączenia (LAN / RS485), adres Modbus (ID), dla LAN IP i port
(domyślnie 192.168.0.18:1502), dla RS485 prędkość, format i piny; nazwa, interwał.
Zapis wymaga logowania: użytkownik `admin`, hasło OpenDTU.

## Szczegóły
* Energia dzienna liczona z liczników całkowitych (YieldTotal) – odporna na noc, restart i pojedyncze
  błędne ramki radiowe. Po restarcie w ciągu dnia dzisiejsza produkcja MIT jest odtwarzana z jego licznika „dziś”.
* Noc: zapisywana jest tylko pierwsza próbka zerowa (oszczędność miejsca), wykres i tak spada do 0.
* Zapis wymaga czasu z NTP. Pliki: `/hist1/s/RRRRMMDD.bin`, `/hist1/d/RRRRMM.bin`, `/hist1/state.bin`, `/solaredge.json`.
* API: `/api/history/screen` (GET stan, POST `{"action":"next|prev|goto|pin|auto|wake","index":n}`), `/api/history/live`, `/api/history/samples?from=&to=&step=&csv=1`, `/api/history/days?from=RRRRMMDD&to=…&csv=1`.
* Obsługiwane: do 2 falowników Hoymiles × 6 wejść DC + 1 SolarEdge.

## Zmienione / nowe pliki
Nowe: `include/PvHistory*.h`, `include/PvDisplay*.h`, `include/PvPins.h`, `include/SolarEdge.h`, `include/SunSpecDecode.h`,
`src/PvHistory*.cpp`, `src/PvDisplay*.cpp`, `src/PvPins.cpp`, `src/SolarEdge.cpp`, `pvhistory/` (źródło strony HTML + generator nagłówka), `partitions_history_8mb.csv`.
Zmienione: `src/main.cpp` (+3 inicjalizacje), `src/WebApi.cpp` (+1 linia), `platformio_override.ini`.
Po edycji `pvhistory/history.html` uruchom `python3 pvhistory/make_page_header.py`.
