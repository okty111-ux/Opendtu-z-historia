<template>
    <div class="row row-cols-1 row-cols-md-3 g-3" :class="{ 'pv-total-highlight': highlight }">
        <div class="col">
            <CardElement centerContent textVariant="text-bg-primary" :text="$t('invertertotalinfo.TotalYieldTotal')">
                <h2>
                    {{
                        $n(totalData.YieldTotal.v, 'decimal', {
                            minimumFractionDigits: totalData.YieldTotal.d,
                            maximumFractionDigits: totalData.YieldTotal.d,
                        })
                    }}
                    <small class="text-muted">{{ totalData.YieldTotal.u }}</small>
                </h2>
            </CardElement>
        </div>
        <div class="col">
            <CardElement centerContent textVariant="text-bg-primary" :text="$t('invertertotalinfo.TotalYieldDay')">
                <h2>
                    {{
                        $n(totalData.YieldDay.v, 'decimal', {
                            minimumFractionDigits: totalData.YieldDay.d,
                            maximumFractionDigits: totalData.YieldDay.d,
                        })
                    }}
                    <small class="text-muted">{{ totalData.YieldDay.u }}</small>
                </h2>
            </CardElement>
        </div>
        <div class="col">
            <CardElement centerContent textVariant="text-bg-primary" :text="$t('invertertotalinfo.TotalPower')">
                <h2>
                    {{
                        $n(totalData.Power.v, 'decimal', {
                            minimumFractionDigits: totalData.Power.d,
                            maximumFractionDigits: totalData.Power.d,
                        })
                    }}
                    <small class="text-muted">{{ totalData.Power.u }}</small>
                </h2>
            </CardElement>
        </div>
    </div>
</template>

<script lang="ts">
import type { Total } from '@/types/LiveDataStatus';
import CardElement from './CardElement.vue';
import { defineComponent, type PropType } from 'vue';

export default defineComponent({
    components: {
        CardElement,
    },
    props: {
        totalData: { type: Object as PropType<Total>, required: true },
        highlight: { type: Boolean, default: false },
    },
});
</script>

<style scoped>
.pv-total-highlight :deep(.card) {
    background-color: #ffd43b;
    border: 2px solid #f0b400;
    color: #212529;
}
.pv-total-highlight :deep(.card-header) {
    background-color: #f0b400 !important;
    color: #212529 !important;
    font-weight: 600;
}
.pv-total-highlight :deep(h2),
.pv-total-highlight :deep(small) {
    color: #212529 !important;
}
</style>
