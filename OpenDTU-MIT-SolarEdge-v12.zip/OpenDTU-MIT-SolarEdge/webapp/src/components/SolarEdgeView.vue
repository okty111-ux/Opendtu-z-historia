<template>
    <div class="card">
        <div
            class="card-header d-flex justify-content-between align-items-center"
            :class="{
                'text-bg-tertiary': !se.enabled,
                'text-bg-danger': se.enabled && !se.online,
                'text-bg-warning': se.enabled && se.online && !producing,
                'text-bg-success': se.enabled && se.online && producing,
            }"
        >
            <div class="p-1 flex-grow-1">
                <div class="d-flex flex-wrap">
                    <div style="padding-right: 2em">{{ se.name }}</div>
                    <div v-if="se.serial" style="padding-right: 2em">
                        {{ $t('home.SerialNumber') }}{{ se.serial }}
                    </div>
                    <div v-if="se.model" style="padding-right: 2em">{{ se.manufacturer }} {{ se.model }}</div>
                    <div style="padding-right: 2em">
                        {{ $t('solaredge.Connection') }}:
                        <template v-if="se.transport == 'rtu'">RS485 (ID {{ se.unit }})</template>
                        <template v-else>{{ se.host }}:{{ se.port }} (ID {{ se.unit }})</template>
                    </div>
                    <div v-if="se.lastSeen" style="padding-right: 2em">
                        <DataAgeDisplay :data-age-ms="ageSec * 1000" />
                    </div>
                    <div v-if="se.statusText">{{ $t('solaredge.Status') }}: {{ se.statusText }}</div>
                </div>
            </div>
            <a href="/history" class="btn btn-sm btn-light ms-2" :title="$t('home.PvHistory')">&#128200;</a>
        </div>

        <div class="card-body">
            <BootstrapAlert :show="!se.enabled" variant="secondary">{{ $t('solaredge.Disabled') }}</BootstrapAlert>
            <BootstrapAlert :show="se.enabled && !se.online" variant="danger">
                {{ $t('solaredge.Offline') }}<template v-if="se.error">: {{ se.error }}</template>
            </BootstrapAlert>

            <div v-if="se.pac !== undefined" class="row g-3">
                <div class="col-lg-4 col-md-6">
                    <div class="card card-table border-secondary">
                        <div class="card-header text-bg-secondary">{{ $t('inverterchannelinfo.General') }}</div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <tbody>
                                    <tr v-for="row in generalRows" :key="row.k">
                                        <th scope="row">{{ $t('inverterchannelproperty.' + row.k) }}</th>
                                        <td class="value">{{ fmt(row.v, row.d) }}</td>
                                        <td>{{ row.u }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card card-table border-info">
                        <div class="card-header text-bg-info">{{ $t('inverterchannelinfo.ACOutput') }}</div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.Power') }}</th>
                                        <td class="value">{{ fmt(se.pac, 0) }}</td>
                                        <td>W</td>
                                    </tr>
                                    <tr v-for="(u, i) in se.uac || []" :key="'u' + i">
                                        <th scope="row">
                                            {{
                                                $t(
                                                    'inverterchannelproperty.' +
                                                        ((se.uac || []).length > 1 ? 'Voltage Ph' + (i + 1) + '-N' : 'Voltage')
                                                )
                                            }}
                                        </th>
                                        <td class="value">{{ fmt(u, 1) }}</td>
                                        <td>V</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.Current') }}</th>
                                        <td class="value">{{ fmt(se.iac, 2) }}</td>
                                        <td>A</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.Frequency') }}</th>
                                        <td class="value">{{ fmt(se.freq, 2) }}</td>
                                        <td>Hz</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.PowerFactor') }}</th>
                                        <td class="value">{{ fmt(se.pf, 3) }}</td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card card-table">
                        <div class="card-header">DC</div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.Power') }}</th>
                                        <td class="value">{{ fmt(se.pdc, 0) }}</td>
                                        <td>W</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.Voltage') }}</th>
                                        <td class="value">{{ fmt(se.udc, 1) }}</td>
                                        <td>V</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">{{ $t('inverterchannelproperty.Current') }}</th>
                                        <td class="value">{{ fmt(se.idc, 2) }}</td>
                                        <td>A</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="se.version" class="text-muted small mt-3">
                {{ se.manufacturer }} {{ se.model }} · FW {{ se.version }}
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import BootstrapAlert from '@/components/BootstrapAlert.vue';
import DataAgeDisplay from '@/components/DataAgeDisplay.vue';
import { defineComponent, type PropType } from 'vue';

export interface SolarEdgeLive {
    enabled: boolean;
    online: boolean;
    name: string;
    host: string;
    port: number;
    transport: string;
    unit: number;
    error: string;
    lastSeen: number;
    manufacturer: string;
    model: string;
    serial: string;
    version: string;
    todayWh: number;
    pac?: number;
    temp?: number;
    totalKwh?: number;
    freq?: number;
    pf?: number;
    iac?: number;
    udc?: number;
    idc?: number;
    pdc?: number;
    status?: number;
    statusText?: string;
    uac?: number[];
}

export default defineComponent({
    components: { BootstrapAlert, DataAgeDisplay },
    props: {
        se: { type: Object as PropType<SolarEdgeLive>, required: true },
        now: { type: Number, required: true }, // device epoch seconds
    },
    computed: {
        producing(): boolean {
            return (this.se.pac ?? 0) > 0;
        },
        ageSec(): number {
            return Math.max(0, this.now - this.se.lastSeen);
        },
        generalRows(): { k: string; v: number | undefined; d: number; u: string }[] {
            return [
                { k: 'Power', v: this.se.pac, d: 0, u: 'W' },
                { k: 'YieldDay', v: this.se.todayWh, d: 0, u: 'Wh' },
                { k: 'YieldTotal', v: this.se.totalKwh, d: 3, u: 'kWh' },
                { k: 'Temperature', v: this.se.temp, d: 1, u: '°C' },
            ];
        },
    },
    methods: {
        fmt(v: number | null | undefined, d: number): string {
            if (v === undefined || v === null || Number.isNaN(v)) {
                return '-';
            }
            return this.$n(v, 'decimal', { minimumFractionDigits: d, maximumFractionDigits: d });
        },
    },
});
</script>
