<template>
    <NavBar />
    <router-view />
    <footer class="container-xxl text-center text-muted small mt-4 mb-2">
        Przygotował Okty na podstawie dostępnych materiałów z GitHub (OpenDTU, licencja GPL-2.0)
    </footer>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import NavBar from './components/NavBar.vue';

export default defineComponent({
    name: 'App',
    components: {
        NavBar,
    },
});
</script>

<style>
/* Show it is fixed to the top */
body {
    padding-bottom: 1rem;
    padding-top: 4.5rem;
}
</style>
