// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * PvTuya - PV production to the Tuya cloud (TuyaLink, MQTT standard protocol)
 */
#include "PvTuya.h"
#include "Datastore.h"
#include "NetworkSettings.h"
#include "PvHistory.h"
#include "PvTuyaCerts.h"
#include "SolarEdge.h"
#include "WebApi.h"
#include <ArduinoJson.h>
#include <AsyncJson.h>
#include <LittleFS.h>
#include <cmath>
#include <espMqttClient.h>
#include <mbedtls/md.h>

#undef TAG
static const char* TAG = "pvtuya";

#define PV_TUYA_CONFIG_FILE "/pvtuya.json"
static constexpr uint32_t RETRY_MS = 30000;
static constexpr uint32_t MIN_VALID_EPOCH = 1700000000;

PvTuyaClass PvTuya;

const PvTuyaProperty pvTuyaProperties[] = {
    { "pv_power", "W", 0, "Moc chwilowa razem (Hoymiles + SolarEdge)" },
    { "pv_energy_today", "Wh", 0, "Produkcja dzisiaj razem" },
    { "pv_energy_total", "kWh", 1, "Produkcja całkowita razem" },
    { "hm_power", "W", 0, "Moc Hoymiles (OpenDTU)" },
    { "hm_energy_today", "Wh", 0, "Produkcja dzisiaj Hoymiles" },
    { "se_power", "W", 0, "Moc SolarEdge" },
    { "se_energy_today", "Wh", 0, "Produkcja dzisiaj SolarEdge" },
};
const size_t pvTuyaPropertyCount = sizeof(pvTuyaProperties) / sizeof(pvTuyaProperties[0]);

static const char* stateName(PvTuyaState s)
{
    switch (s) {
    case PvTuyaState::Disabled:
        return "disabled";
    case PvTuyaState::NotConfigured:
        return "notConfigured";
    case PvTuyaState::WaitingForNetwork:
        return "waitingForNetwork";
    case PvTuyaState::WaitingForTime:
        return "waitingForTime";
    case PvTuyaState::Connecting:
        return "connecting";
    case PvTuyaState::Connected:
        return "connected";
    default:
        return "error";
    }
}

static String hmacSha256Hex(const String& key, const String& msg)
{
    uint8_t out[32];
    const mbedtls_md_info_t* info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    if (info == nullptr || mbedtls_md_hmac(info, reinterpret_cast<const unsigned char*>(key.c_str()), key.length(), reinterpret_cast<const unsigned char*>(msg.c_str()), msg.length(), out) != 0) {
        return String();
    }
    char hex[65];
    for (int i = 0; i < 32; i++) {
        snprintf(hex + 2 * i, 3, "%02x", out[i]);
    }
    return String(hex);
}

static const char* disconnectText(espMqttClientTypes::DisconnectReason r)
{
    switch (r) {
    case espMqttClientTypes::DisconnectReason::USER_OK:
        return "Rozłączono";
    case espMqttClientTypes::DisconnectReason::MQTT_UNACCEPTABLE_PROTOCOL_VERSION:
        return "Serwer odrzucił wersję MQTT";
    case espMqttClientTypes::DisconnectReason::MQTT_IDENTIFIER_REJECTED:
        return "Tuya odrzuciła identyfikator (DeviceID)";
    case espMqttClientTypes::DisconnectReason::MQTT_SERVER_UNAVAILABLE:
        return "Serwer Tuya niedostępny";
    case espMqttClientTypes::DisconnectReason::MQTT_MALFORMED_CREDENTIALS:
        return "Niepoprawne dane logowania";
    case espMqttClientTypes::DisconnectReason::MQTT_NOT_AUTHORIZED:
        return "Brak autoryzacji - sprawdź DeviceID, DeviceSecret i centrum danych";
    case espMqttClientTypes::DisconnectReason::TLS_BAD_FINGERPRINT:
        return "Błąd certyfikatu TLS";
    default:
        return "Połączenie TCP/TLS zerwane lub nieudane";
    }
}

// ---------------------------------------------------------------------------

PvTuyaClass::PvTuyaClass()
    : _loopTask(1 * TASK_SECOND, TASK_FOREVER, std::bind(&PvTuyaClass::loop, this))
{
}

void PvTuyaClass::init(Scheduler& scheduler)
{
    loadConfig();
    scheduler.addTask(_loopTask);
    _loopTask.enable();
    ESP_LOGI(TAG, "Tuya cloud reporting %s", _cfg.enabled ? "enabled" : "disabled");
}

PvTuyaConfig PvTuyaClass::getConfig()
{
    std::lock_guard<std::mutex> lock(_mutex);
    return _cfg;
}

bool PvTuyaClass::setConfig(const PvTuyaConfig& cfg)
{
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _cfg = cfg;
        _status.lastResponseCode = -1;
        _status.lastResponse[0] = 0;
        _status.lastError[0] = 0;
    }
    _reconfigure = true;
    return saveConfig();
}

PvTuyaStatus PvTuyaClass::getStatus()
{
    std::lock_guard<std::mutex> lock(_mutex);
    return _status;
}

void PvTuyaClass::setState(PvTuyaState s, const char* err)
{
    std::lock_guard<std::mutex> lock(_mutex);
    _status.state = s;
    if (err != nullptr) {
        if (strcmp(_status.lastError, err) != 0) {
            ESP_LOGW(TAG, "%s", err);
        }
        strlcpy(_status.lastError, err, sizeof(_status.lastError));
    }
}

bool PvTuyaClass::loadConfig()
{
    File f = LittleFS.open(PV_TUYA_CONFIG_FILE, "r", false);
    if (!f) {
        return false;
    }
    JsonDocument doc;
    const DeserializationError err = deserializeJson(doc, f);
    f.close();
    if (err) {
        return false;
    }
    std::lock_guard<std::mutex> lock(_mutex);
    _cfg.enabled = doc["enabled"] | _cfg.enabled;
    strlcpy(_cfg.host, doc["host"] | _cfg.host, sizeof(_cfg.host));
    _cfg.port = doc["port"] | _cfg.port;
    strlcpy(_cfg.deviceId, doc["deviceId"] | _cfg.deviceId, sizeof(_cfg.deviceId));
    strlcpy(_cfg.deviceSecret, doc["deviceSecret"] | _cfg.deviceSecret, sizeof(_cfg.deviceSecret));
    _cfg.intervalSec = constrain(static_cast<int>(doc["interval"] | _cfg.intervalSec), 10, 3600);
    _cfg.insecure = doc["insecure"] | _cfg.insecure;
    return true;
}

bool PvTuyaClass::saveConfig()
{
    JsonDocument doc;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        doc["enabled"] = _cfg.enabled;
        doc["host"] = String(_cfg.host);
        doc["port"] = _cfg.port;
        doc["deviceId"] = String(_cfg.deviceId);
        doc["deviceSecret"] = String(_cfg.deviceSecret);
        doc["interval"] = _cfg.intervalSec;
        doc["insecure"] = _cfg.insecure;
    }
    File f = LittleFS.open(PV_TUYA_CONFIG_FILE, "w");
    if (!f) {
        return false;
    }
    const bool ok = serializeJson(doc, f) > 0;
    f.close();
    return ok;
}

// ---------------------------------------------------------------------------

void PvTuyaClass::startConnect(const PvTuyaConfig& cfg)
{
    if (_client == nullptr) {
        _client = new espMqttClientSecure;
        _client->onConnect([this](bool) {
            _connected = true;
            setState(PvTuyaState::Connected);
            {
                std::lock_guard<std::mutex> lock(_mutex);
                _status.lastError[0] = 0;
            }
            _client->subscribe(_respTopic.c_str(), 1);
            _lastReportMs = 0; // report right away
            ESP_LOGI(TAG, "Connected to Tuya cloud");
        });
        _client->onDisconnect([this](espMqttClientTypes::DisconnectReason reason) {
            _connected = false;
            setState(PvTuyaState::Error, disconnectText(reason));
        });
        _client->onMessage([this](const espMqttClientTypes::MessageProperties&, const char* topic, const uint8_t* payload, size_t len, size_t index, size_t total) {
            if (index != 0 || len != total || len > 1024) {
                return; // responses are small, ignore fragments
            }
            JsonDocument doc;
            if (deserializeJson(doc, payload, len)) {
                return;
            }
            std::lock_guard<std::mutex> lock(_mutex);
            _status.lastResponseCode = doc["code"] | 0;
            const char* msg = doc["msg"] | (_status.lastResponseCode == 0 ? "OK" : "");
            strlcpy(_status.lastResponse, msg, sizeof(_status.lastResponse));
        });
    }

    const uint32_t ts = static_cast<uint32_t>(time(nullptr));
    const String id = cfg.deviceId;
    _clientId = "tuyalink_" + id;
    _username = id + "|signMethod=hmacSha256,timestamp=" + String(ts) + ",secureMode=1,accessType=1";
    _password = hmacSha256Hex(cfg.deviceSecret, "deviceId=" + id + ",timestamp=" + String(ts) + ",secureMode=1,accessType=1");
    _hostCopy = cfg.host;
    _respTopic = "tylink/" + id + "/thing/property/report_response";

    if (cfg.insecure) {
        _client->setInsecure();
    } else {
        _client->setCACert(PV_TUYA_ROOT_CA);
    }
    _client->setServer(_hostCopy.c_str(), cfg.port);
    _client->setClientId(_clientId.c_str());
    _client->setCredentials(_username.c_str(), _password.c_str());
    _client->setKeepAlive(60);
    _client->setCleanSession(true);

    setState(PvTuyaState::Connecting);
    ESP_LOGI(TAG, "Connecting to %s:%u as %s", cfg.host, cfg.port, cfg.deviceId);
    _client->connect();
}

void PvTuyaClass::report(const PvTuyaConfig& cfg)
{
    const float hmPower = Datastore.getTotalAcPowerEnabled();
    const float hmToday = Datastore.getTotalAcYieldDayEnabled();
    const float hmTotal = Datastore.getTotalAcYieldTotalEnabled();

    const SolarEdgeSnapshot se = SolarEdge.getSnapshot();
    const HistState st = PvHistory.getState();
    const float sePower = (se.online && se.inv.valid && !std::isnan(se.inv.pac)) ? se.inv.pac : 0;
    const float seToday = st.se.dayWh();
    const float seTotal = (se.inv.valid && !std::isnan(se.inv.energyWh)) ? se.inv.energyWh / 1000.0 : 0;

    auto clean = [](float v) { return (std::isnan(v) || std::isinf(v) || v < 0) ? 0.0f : v; };

    const uint64_t nowMs = static_cast<uint64_t>(time(nullptr)) * 1000ULL;
    const double values[] = {
        clean(hmPower) + clean(sePower),
        clean(hmToday) + clean(seToday),
        clean(hmTotal) + clean(seTotal),
        clean(hmPower),
        clean(hmToday),
        clean(sePower),
        clean(seToday),
    };

    JsonDocument doc;
    doc["msgId"] = String(_msgId++);
    doc["time"] = nowMs;
    JsonObject data = doc["data"].to<JsonObject>();
    for (size_t i = 0; i < pvTuyaPropertyCount; i++) {
        JsonObject p = data[pvTuyaProperties[i].code].to<JsonObject>();
        p["value"] = static_cast<int32_t>(std::lround(values[i] * std::pow(10.0, pvTuyaProperties[i].scale)));
        p["time"] = nowMs;
    }
    String payload;
    serializeJson(doc, payload);

    const String topic = "tylink/" + String(cfg.deviceId) + "/thing/property/report";
    if (_client->publish(topic.c_str(), 1, false, payload.c_str()) != 0) {
        std::lock_guard<std::mutex> lock(_mutex);
        _status.reports++;
        _status.lastReportEpoch = static_cast<uint32_t>(time(nullptr));
    } else {
        setState(PvTuyaState::Connected, "Nie udało się wysłać raportu");
    }
}

void PvTuyaClass::loop()
{
    const PvTuyaConfig cfg = getConfig();

    if (_reconfigure) {
        _reconfigure = false;
        if (_client != nullptr && _client->connected()) {
            _client->disconnect(true);
        }
        _connected = false;
        _lastAttemptMs = 0;
        return;
    }

    if (!cfg.enabled) {
        if (_client != nullptr && _client->connected()) {
            _client->disconnect(true);
            _connected = false;
        }
        setState(PvTuyaState::Disabled);
        return;
    }
    if (cfg.deviceId[0] == 0 || cfg.deviceSecret[0] == 0 || cfg.host[0] == 0) {
        setState(PvTuyaState::NotConfigured);
        return;
    }
    if (!NetworkSettings.isConnected()) {
        setState(PvTuyaState::WaitingForNetwork);
        return;
    }
    if (time(nullptr) < MIN_VALID_EPOCH) {
        setState(PvTuyaState::WaitingForTime); // the signature contains the current time
        return;
    }

    if (_client == nullptr || !_client->connected()) {
        _connected = false;
        if (_lastAttemptMs == 0 || millis() - _lastAttemptMs > RETRY_MS) {
            _lastAttemptMs = millis();
            if (_lastAttemptMs == 0) {
                _lastAttemptMs = 1;
            }
            if (_client != nullptr) {
                _client->disconnect(true);
            }
            startConnect(cfg);
        }
        return;
    }

    if (_lastReportMs == 0 || millis() - _lastReportMs >= cfg.intervalSec * 1000UL) {
        _lastReportMs = millis();
        if (_lastReportMs == 0) {
            _lastReportMs = 1;
        }
        report(cfg);
    }
}

// ---------------------------------------------------------------------------

void PvTuyaClass::initWeb(AsyncWebServer& server)
{
    using std::placeholders::_1;
    server.on("/api/history/tuya", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvTuyaClass::onGet, this, _1)));
    server.on("/api/history/tuya", HTTP_POST, static_cast<ArRequestHandlerFunction>(std::bind(&PvTuyaClass::onPost, this, _1)));
}

void PvTuyaClass::onGet(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    const PvTuyaConfig cfg = getConfig();
    const PvTuyaStatus st = getStatus();
    AsyncJsonResponse* response = new AsyncJsonResponse();
    auto& root = response->getRoot();
    root["enabled"] = cfg.enabled;
    root["host"] = String(cfg.host);
    root["port"] = cfg.port;
    root["deviceId"] = String(cfg.deviceId);
    root["secretSet"] = cfg.deviceSecret[0] != 0; // the secret itself is never sent back
    root["interval"] = cfg.intervalSec;
    root["insecure"] = cfg.insecure;
    root["state"] = stateName(st.state);
    root["error"] = String(st.lastError);
    root["lastReport"] = st.lastReportEpoch;
    root["reports"] = st.reports;
    root["responseCode"] = st.lastResponseCode;
    root["response"] = String(st.lastResponse);
    JsonArray props = root["properties"].to<JsonArray>();
    for (size_t i = 0; i < pvTuyaPropertyCount; i++) {
        JsonObject p = props.add<JsonObject>();
        p["code"] = pvTuyaProperties[i].code;
        p["unit"] = pvTuyaProperties[i].unit;
        p["scale"] = pvTuyaProperties[i].scale;
        p["desc"] = pvTuyaProperties[i].description;
    }
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvTuyaClass::onPost(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentials(request)) {
        return;
    }
    AsyncJsonResponse* response = new AsyncJsonResponse();
    JsonDocument doc;
    if (!WebApi.parseRequestData(request, response, doc)) {
        return;
    }
    auto& retMsg = response->getRoot();
    auto fail = [&](const char* msg) {
        retMsg["type"] = "warning";
        retMsg["message"] = msg;
        WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
    };

    PvTuyaConfig cfg = getConfig();
    String host = doc["host"] | String(cfg.host);
    String id = doc["deviceId"] | String(cfg.deviceId);
    String secret = doc["deviceSecret"] | String("");
    host.trim();
    id.trim();
    secret.trim();
    const int port = doc["port"] | static_cast<int>(cfg.port);
    const int interval = doc["interval"] | static_cast<int>(cfg.intervalSec);

    if (host.length() == 0 || host.length() >= sizeof(cfg.host) || host.indexOf(' ') >= 0) {
        return fail("Niepoprawny adres serwera Tuya");
    }
    if (port < 1 || port > 65535) {
        return fail("Niepoprawny port");
    }
    if (id.length() >= sizeof(cfg.deviceId) || id.indexOf(' ') >= 0 || id.indexOf('/') >= 0 || id.indexOf('#') >= 0 || id.indexOf('+') >= 0) {
        return fail("Niepoprawny DeviceID");
    }
    if (secret.length() >= sizeof(cfg.deviceSecret)) {
        return fail("DeviceSecret jest za długi");
    }
    if (interval < 10 || interval > 3600) {
        return fail("Interwał wysyłania: 10-3600 s");
    }

    cfg.enabled = doc["enabled"] | cfg.enabled;
    strlcpy(cfg.host, host.c_str(), sizeof(cfg.host));
    cfg.port = port;
    strlcpy(cfg.deviceId, id.c_str(), sizeof(cfg.deviceId));
    if (secret.length() > 0) { // empty = keep the stored secret
        strlcpy(cfg.deviceSecret, secret.c_str(), sizeof(cfg.deviceSecret));
    }
    cfg.intervalSec = interval;
    cfg.insecure = doc["insecure"] | cfg.insecure;

    if (cfg.enabled && (cfg.deviceId[0] == 0 || cfg.deviceSecret[0] == 0)) {
        return fail("Podaj DeviceID i DeviceSecret z platformy Tuya");
    }

    const bool ok = setConfig(cfg);
    retMsg["type"] = ok ? "success" : "danger";
    retMsg["message"] = ok ? (cfg.enabled ? "Zapisano - łączenie z chmurą Tuya" : "Zapisano - wysyłanie do Tuya wyłączone") : "Błąd zapisu";
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}
