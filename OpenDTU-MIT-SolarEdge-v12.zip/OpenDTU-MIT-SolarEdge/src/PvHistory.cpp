// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * PvHistory - production statistics for OpenDTU (Hoymiles) + SolarEdge
 */
#include "PvHistory.h"
#include "Configuration.h"
#include "PvDisplay.h"
#include "PvHistoryPage.h"
#include "PvTuya.h"
#include "PvUpdate.h"
#include "SolarEdge.h"
#include "WebApi.h"
#include <AsyncJson.h>
#include <Hoymiles.h>
#include <LittleFS.h>
#include <ctime>
#include <memory>

#undef TAG
static const char* TAG = "pvhistory";

using PvHistoryLogic::Accumulator;

PvHistoryClass PvHistory;

static constexpr time_t MIN_VALID_EPOCH = 1700000000; // time not synced before this

PvHistoryClass::PvHistoryClass()
    : _loopTask(PV_HISTORY_TICK_MS * TASK_MILLISECOND, TASK_FOREVER, std::bind(&PvHistoryClass::loop, this))
{
    memset(&_state, 0, sizeof(_state));
}

void PvHistoryClass::init(Scheduler& scheduler)
{
    _store.init(
        "/littlefs",
        []() { return static_cast<size_t>(LittleFS.totalBytes()); },
        []() { return static_cast<size_t>(LittleFS.usedBytes()); });

    if (!_store.loadState(_state)) {
        memset(&_state, 0, sizeof(_state));
        _state.magic = HIST_STATE_MAGIC;
    }
    _store.enforceRetention();

    ESP_LOGI(TAG, "History storage: FS %u/%u bytes used, %u sample days, %u day records",
        static_cast<unsigned>(LittleFS.usedBytes()), static_cast<unsigned>(LittleFS.totalBytes()),
        static_cast<unsigned>(_store.listSampleDates().size()), static_cast<unsigned>(_store.dayRecordCount()));

    scheduler.addTask(_loopTask);
    _loopTask.enable();
}

HistState PvHistoryClass::getState()
{
    std::lock_guard<std::mutex> lock(_stateMutex);
    return _state;
}

// ---------------------------------------------------------------------------
// Data collection (runs in the main loop via TaskScheduler)
// ---------------------------------------------------------------------------

static float fieldOr(StatisticsParser* st, ChannelType_t t, ChannelNum_t c, FieldId_t f, float def)
{
    return st->hasChannelFieldValue(t, c, f) ? st->getChannelFieldValue(t, c, f) : def;
}

// Totals are on TYPE_AC for most models and on TYPE_INV for 3-phase ones (HMT/MIT)
static float totalField(StatisticsParser* st, FieldId_t f)
{
    if (st->hasChannelFieldValue(TYPE_AC, CH0, f)) {
        return st->getChannelFieldValue(TYPE_AC, CH0, f);
    }
    return fieldOr(st, TYPE_INV, CH0, f, NAN);
}

void PvHistoryClass::handleDayChange(uint32_t now, uint32_t today)
{
    HistDay finished;
    bool write;
    HistState copy;
    {
        std::lock_guard<std::mutex> lock(_stateMutex);
        const bool contiguous = _stateReady; // false on the first call after boot
        _stateReady = true;
        if (_state.magic == HIST_STATE_MAGIC && _state.date == today) {
            return;
        }
        write = PvHistoryLogic::rollover(_state, today, contiguous, finished);
        copy = _state;
    }
    if (write) {
        ESP_LOGI(TAG, "Day %u finished: %u Wh", finished.date, PvHistoryLogic::totalDayWh(finished));
        if (!_store.appendDay(finished)) {
            ESP_LOGE(TAG, "Failed to write day record");
        }
    }
    _store.saveState(copy);
    (void)now;
}

void PvHistoryClass::collect(Accumulator::Reading& r)
{
    const SolarEdgeSnapshot se = SolarEdge.getSnapshot();

    std::lock_guard<std::mutex> lock(_stateMutex);

    if (se.online && se.inv.valid) {
        r.se = std::isnan(se.inv.pac) ? 0 : se.inv.pac;
        r.seT = se.inv.temp;
        if (!std::isnan(se.inv.energyWh) && se.inv.energyWh > 0 && se.inv.energyWh < 4.0e9) {
            PvHistoryLogic::updateCounter(_state.se, static_cast<uint32_t>(std::llround(se.inv.energyWh)));
        }
    }

    const uint8_t count = std::min<uint8_t>(HIST_MAX_INV, Hoymiles.getNumInverters());
    for (uint8_t i = 0; i < count; i++) {
        auto inv = Hoymiles.getInverterByPos(i);
        if (inv == nullptr) {
            continue;
        }
        StatisticsParser* st = inv->Statistics();
        if (!inv->isReachable() || st->getLastUpdate() == 0) {
            continue; // counts as 0 W for this reading
        }
        r.pac[i] = fieldOr(st, TYPE_AC, CH0, FLD_PAC, 0);
        r.t[i] = fieldOr(st, TYPE_INV, CH0, FLD_T, NAN);

        const float yt = totalField(st, FLD_YT);
        const float yd = totalField(st, FLD_YD);
        PvHistoryLogic::updateCounter(_state.invAc[i], PvHistoryLogic::kwhToWh(yt), std::isnan(yd) ? -1 : static_cast<int64_t>(yd));

        for (auto c : st->getChannelsByType(TYPE_DC)) {
            if (c >= HIST_MAX_DC) {
                continue;
            }
            r.pdc[i][c] = fieldOr(st, TYPE_DC, c, FLD_PDC, 0);
            const float cyt = fieldOr(st, TYPE_DC, c, FLD_YT, NAN);
            const float cyd = fieldOr(st, TYPE_DC, c, FLD_YD, NAN);
            PvHistoryLogic::updateCounter(_state.invDc[i][c], PvHistoryLogic::kwhToWh(cyt), std::isnan(cyd) ? -1 : static_cast<int64_t>(cyd));
        }
    }
}

void PvHistoryClass::storeSample(uint32_t slotTs)
{
    if (_acc.n == 0) {
        return;
    }
    const HistSample s = _acc.toSample(slotTs);
    const bool zero = PvHistoryLogic::sampleIsZero(s);
    // Night: store only the first zero sample so charts drop to 0, skip the rest
    if (!(zero && _lastSampleZero)) {
        if (!_store.appendSample(s, PvHistoryStore::localDate(slotTs))) {
            ESP_LOGE(TAG, "Failed to append sample");
        }
    }
    _lastSampleZero = zero;

    HistState copy;
    {
        std::lock_guard<std::mutex> lock(_stateMutex);
        const uint32_t tot = PvHistoryLogic::sampleTotalW(s);
        if (tot > _state.peakW) {
            _state.peakW = tot > 65000 ? 65000 : tot;
        }
        copy = _state;
    }
    _store.saveState(copy);
}

void PvHistoryClass::loop()
{
    const time_t nowT = time(nullptr);
    if (nowT < MIN_VALID_EPOCH) {
        return; // wait for NTP
    }
    const uint32_t now = static_cast<uint32_t>(nowT);
    handleDayChange(now, PvHistoryStore::localDate(now));

    Accumulator::Reading r;
    collect(r);

    const uint32_t slot = now / PV_HISTORY_SAMPLE_INTERVAL;
    if (_curSlot == 0) {
        _curSlot = slot;
    }
    if (slot != _curSlot) {
        storeSample(_curSlot * PV_HISTORY_SAMPLE_INTERVAL);
        _acc.reset();
        _curSlot = slot;
    }
    _acc.add(r);
}

// ---------------------------------------------------------------------------
// Web
// ---------------------------------------------------------------------------

namespace {

struct ChunkCtx {
    std::string pending;
    bool done = false;
    std::function<bool(std::string&)> produce; // append data, return false when finished
};

AsyncWebServerResponse* chunkedResponse(AsyncWebServerRequest* request, const char* type, std::function<bool(std::string&)> produce)
{
    auto ctx = std::make_shared<ChunkCtx>();
    ctx->produce = std::move(produce);
    return request->beginChunkedResponse(type, [ctx](uint8_t* buffer, size_t maxLen, size_t) -> size_t {
        while (!ctx->done && ctx->pending.size() < maxLen) {
            if (!ctx->produce(ctx->pending)) {
                ctx->done = true;
            }
        }
        const size_t n = std::min(maxLen, ctx->pending.size());
        memcpy(buffer, ctx->pending.data(), n);
        ctx->pending.erase(0, n);
        return n;
    });
}

uint32_t paramU32(AsyncWebServerRequest* request, const char* name, uint32_t def)
{
    if (!request->hasParam(name)) {
        return def;
    }
    return static_cast<uint32_t>(strtoul(request->getParam(name)->value().c_str(), nullptr, 10));
}

void appendNum(std::string& out, double v, int decimals, char decSep = '.')
{
    char buf[24];
    snprintf(buf, sizeof(buf), "%.*f", decimals, v);
    if (decSep != '.') {
        for (char* p = buf; *p; p++) {
            if (*p == '.') {
                *p = decSep;
            }
        }
    }
    out += buf;
}

// One (possibly averaged) row of samples
struct Row {
    uint32_t ts = 0;
    uint32_t n = 0;
    double se = 0;
    double pac[HIST_MAX_INV] = {};
    double pdc[HIST_MAX_INV][HIST_MAX_DC] = {};
    double t[HIST_MAX_INV + 1] = {}; // [0] = SolarEdge
    uint32_t tn[HIST_MAX_INV + 1] = {};

    void add(const HistSample& s)
    {
        n++;
        se += s.sePac;
        if (s.seTemp != HIST_TEMP_NONE) {
            t[0] += s.seTemp / 10.0;
            tn[0]++;
        }
        for (int i = 0; i < HIST_MAX_INV; i++) {
            pac[i] += s.inv[i].pac;
            for (int c = 0; c < HIST_MAX_DC; c++) {
                pdc[i][c] += s.inv[i].pdc[c];
            }
            if (s.inv[i].temp != HIST_TEMP_NONE) {
                t[i + 1] += s.inv[i].temp / 10.0;
                tn[i + 1]++;
            }
        }
    }
};

struct InvInfo {
    String name;
    uint8_t dcCount = 0;
    String dcName[HIST_MAX_DC];
};

std::vector<InvInfo> inverterInfo()
{
    std::vector<InvInfo> out;
    const uint8_t count = std::min<uint8_t>(HIST_MAX_INV, Hoymiles.getNumInverters());
    for (uint8_t i = 0; i < count; i++) {
        InvInfo info;
        auto inv = Hoymiles.getInverterByPos(i);
        if (inv != nullptr) {
            info.name = inv->name();
            const INVERTER_CONFIG_T* cfg = Configuration.getInverterConfig(inv->serial());
            for (auto c : inv->Statistics()->getChannelsByType(TYPE_DC)) {
                if (c >= HIST_MAX_DC) {
                    continue;
                }
                info.dcCount = std::max<uint8_t>(info.dcCount, c + 1);
                const char* n = (cfg != nullptr) ? cfg->channel[c].Name : "";
                info.dcName[c] = (n != nullptr && n[0] != 0) ? String(n) : String("String ") + String(c + 1);
            }
        }
        out.push_back(info);
    }
    return out;
}

std::string csvName(const String& s)
{
    std::string out(s.c_str());
    for (auto& ch : out) {
        if (ch == ';' || ch == '"' || ch == '\n' || ch == '\r') {
            ch = ' ';
        }
    }
    return out;
}

} // namespace

void PvHistoryClass::initWeb(AsyncWebServer& server)
{
    using std::placeholders::_1;
    server.on("/history", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onPage, this, _1)));
    server.on("/api/history/live", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onLive, this, _1)));
    server.on("/api/history/samples", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onSamples, this, _1)));
    server.on("/api/history/days", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onDays, this, _1)));
    server.on("/api/history/config", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onConfigGet, this, _1)));
    server.on("/api/history/config", HTTP_POST, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onConfigPost, this, _1)));
    server.on("/api/history/display", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onDisplayGet, this, _1)));
    server.on("/api/history/display", HTTP_POST, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onDisplayPost, this, _1)));
    server.on("/api/history/screen", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onScreenGet, this, _1)));
    server.on("/api/history/screen", HTTP_POST, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onScreenPost, this, _1)));
    PvUpdate.initWeb(server);
    PvTuya.initWeb(server);
    server.on("/api/history/clear", HTTP_POST, static_cast<ArRequestHandlerFunction>(std::bind(&PvHistoryClass::onClear, this, _1)));
}

void PvHistoryClass::onPage(AsyncWebServerRequest* request)
{
    AsyncWebServerResponse* response = request->beginResponse(200, "text/html; charset=utf-8",
        reinterpret_cast<const uint8_t*>(PV_HISTORY_PAGE), strlen(PV_HISTORY_PAGE));
    response->addHeader("Cache-Control", "no-cache");
    request->send(response);
}

static void setNum(JsonObject obj, const char* key, double v, int decimals = -1)
{
    if (std::isnan(v) || std::isinf(v)) {
        obj[key] = nullptr;
    } else if (decimals >= 0) {
        const double f = std::pow(10.0, decimals);
        obj[key] = std::round(v * f) / f;
    } else {
        obj[key] = v;
    }
}

void PvHistoryClass::onLive(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }

    HistState st;
    {
        std::lock_guard<std::mutex> lock(_stateMutex);
        st = _state;
    }
    const time_t now = time(nullptr);
    const SolarEdgeSnapshot se = SolarEdge.getSnapshot();
    const SolarEdgeConfig seCfg = SolarEdge.getConfig();

    AsyncJsonResponse* response = new AsyncJsonResponse();
    auto& root = response->getRoot();
    root["time"] = static_cast<uint32_t>(now);
    root["synced"] = now >= MIN_VALID_EPOCH;
    root["interval"] = PV_HISTORY_SAMPLE_INTERVAL;
    root["maxInv"] = HIST_MAX_INV;
    root["maxDc"] = HIST_MAX_DC;
    root["stateDate"] = st.date;

    double totPac = 0;
    double totToday = 0;
    double totLifetime = 0;

    auto invArr = root["inverters"].to<JsonArray>();
    const auto infos = inverterInfo();
    for (uint8_t i = 0; i < infos.size(); i++) {
        auto inv = Hoymiles.getInverterByPos(i);
        if (inv == nullptr) {
            continue;
        }
        StatisticsParser* stat = inv->Statistics();
        JsonObject o = invArr.add<JsonObject>();
        o["slot"] = i;
        o["name"] = infos[i].name;
        o["serial"] = inv->serialString();
        o["reachable"] = inv->isReachable();
        o["producing"] = inv->isProducing();
        const uint32_t lu = stat->getLastUpdate();
        o["lastSeen"] = lu == 0 ? 0 : static_cast<uint32_t>(now - (millis() - lu) / 1000);

        const bool live = inv->isReachable() && lu != 0;
        const float pac = live ? fieldOr(stat, TYPE_AC, CH0, FLD_PAC, 0) : 0;
        setNum(o, "pac", pac, 1);
        setNum(o, "pacLast", fieldOr(stat, TYPE_AC, CH0, FLD_PAC, NAN), 1);
        setNum(o, "temp", fieldOr(stat, TYPE_INV, CH0, FLD_T, NAN), 1);
        const float yt = totalField(stat, FLD_YT);
        setNum(o, "totalKwh", yt, 3);
        o["todayWh"] = st.invAc[i].dayWh();
        setNum(o, "freq", fieldOr(stat, TYPE_AC, CH0, FLD_F, NAN), 2);
        setNum(o, "pf", fieldOr(stat, TYPE_AC, CH0, FLD_PF, NAN), 3);
        setNum(o, "eff", fieldOr(stat, TYPE_INV, CH0, FLD_EFF, NAN), 1);
        setNum(o, "pdcTotal", fieldOr(stat, TYPE_INV, CH0, FLD_PDC, NAN), 1);
        auto u = o["uac"].to<JsonArray>();
        const FieldId_t uf[3] = { FLD_UAC_1N, FLD_UAC_2N, FLD_UAC_3N };
        for (auto f : uf) {
            if (stat->hasChannelFieldValue(TYPE_AC, CH0, f)) {
                u.add(std::round(stat->getChannelFieldValue(TYPE_AC, CH0, f) * 10) / 10);
            }
        }
        if (u.size() == 0 && stat->hasChannelFieldValue(TYPE_AC, CH0, FLD_UAC)) {
            u.add(std::round(stat->getChannelFieldValue(TYPE_AC, CH0, FLD_UAC) * 10) / 10);
        }

        auto strs = o["strings"].to<JsonArray>();
        for (uint8_t c = 0; c < infos[i].dcCount; c++) {
            JsonObject s = strs.add<JsonObject>();
            const ChannelNum_t ch = static_cast<ChannelNum_t>(c);
            s["name"] = infos[i].dcName[c];
            setNum(s, "pdc", live ? fieldOr(stat, TYPE_DC, ch, FLD_PDC, 0) : 0, 1);
            setNum(s, "udc", fieldOr(stat, TYPE_DC, ch, FLD_UDC, NAN), 1);
            setNum(s, "idc", fieldOr(stat, TYPE_DC, ch, FLD_IDC, NAN), 2);
            setNum(s, "totalKwh", fieldOr(stat, TYPE_DC, ch, FLD_YT, NAN), 3);
            s["todayWh"] = st.invDc[i][c].dayWh();
        }

        totPac += pac;
        totToday += st.invAc[i].dayWh();
        if (!std::isnan(yt)) {
            totLifetime += yt;
        }
    }

    JsonObject s = root["solaredge"].to<JsonObject>();
    s["enabled"] = se.enabled;
    s["online"] = se.online;
    s["name"] = String(seCfg.name);
    s["host"] = String(seCfg.host);
    s["port"] = seCfg.port;
    s["transport"] = seCfg.transport == SolarEdgeTransport::Rtu ? "rtu" : "tcp";
    s["unit"] = seCfg.unitId;
    s["error"] = String(se.lastError);
    s["lastSeen"] = se.lastUpdateEpoch;
    s["manufacturer"] = String(se.common.manufacturer);
    s["model"] = String(se.common.model);
    s["serial"] = String(se.common.serial);
    s["version"] = String(se.common.version);
    if (se.inv.valid) {
        const double pac = se.online && !std::isnan(se.inv.pac) ? se.inv.pac : 0;
        setNum(s, "pac", pac, 0);
        setNum(s, "temp", se.inv.temp, 1);
        setNum(s, "totalKwh", se.inv.energyWh / 1000.0, 3);
        setNum(s, "freq", se.inv.freq, 2);
        setNum(s, "pf", se.inv.pf / 100.0, 3);
        setNum(s, "iac", se.inv.iac, 2);
        setNum(s, "udc", se.inv.udc, 1);
        setNum(s, "idc", se.inv.idc, 2);
        setNum(s, "pdc", se.inv.pdc, 0);
        s["status"] = se.inv.status;
        s["statusText"] = SunSpec::statusText(se.inv.status);
        s["phases"] = se.inv.did == 103 ? 3 : (se.inv.did == 102 ? 2 : 1);
        auto u = s["uac"].to<JsonArray>();
        const int phases = se.inv.did == 103 ? 3 : (se.inv.did == 102 ? 2 : 1);
        for (int p = 0; p < phases; p++) {
            if (!std::isnan(se.inv.uacLN[p])) {
                u.add(std::round(se.inv.uacLN[p] * 10) / 10);
            }
        }
        totPac += pac;
        if (!std::isnan(se.inv.energyWh)) {
            totLifetime += se.inv.energyWh / 1000.0;
        }
    }
    s["todayWh"] = st.se.dayWh();
    totToday += st.se.dayWh();

    JsonObject t = root["total"].to<JsonObject>();
    setNum(t, "pac", totPac, 0);
    t["todayWh"] = static_cast<uint32_t>(totToday);
    setNum(t, "totalKwh", totLifetime, 1);
    t["peakW"] = st.peakW;

    JsonObject fs = root["storage"].to<JsonObject>();
    fs["fsTotal"] = static_cast<uint32_t>(LittleFS.totalBytes());
    fs["fsUsed"] = static_cast<uint32_t>(LittleFS.usedBytes());
    fs["reserve"] = static_cast<uint32_t>(_store.reserveBytes());
    const auto dates = _store.listSampleDates();
    fs["sampleDays"] = static_cast<uint32_t>(dates.size());
    fs["oldestSample"] = dates.empty() ? 0 : dates.front();
    fs["dayRecords"] = static_cast<uint32_t>(_store.dayRecordCount());
    fs["oldestDay"] = _store.oldestDayDate();

    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvHistoryClass::onSamples(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    const uint32_t now = static_cast<uint32_t>(time(nullptr));
    const uint32_t to = paramU32(request, "to", now);
    const uint32_t from = paramU32(request, "from", to > 86400 ? to - 86400 : 0);
    uint32_t step = paramU32(request, "step", PV_HISTORY_SAMPLE_INTERVAL);
    step = std::max<uint32_t>(step, PV_HISTORY_SAMPLE_INTERVAL);
    const bool csv = paramU32(request, "csv", 0) != 0;

    struct Ctx {
        std::unique_ptr<PvHistoryStore::SampleCursor> cursor;
        Row row;
        uint8_t phase = 0; // 0 = header, 1 = rows, 2 = footer
        bool first = true;
        uint32_t step;
        bool csv;
        bool seEnabled;
        std::vector<InvInfo> infos;
        String seName;
    };
    auto ctx = std::make_shared<Ctx>();
    ctx->seEnabled = SolarEdge.getConfig().enabled;
    ctx->cursor.reset(new PvHistoryStore::SampleCursor(_store, from, to, _store.sampleDatesForRange(from, to)));
    ctx->step = step;
    ctx->csv = csv;
    if (csv) {
        ctx->infos = inverterInfo();
        ctx->seName = SolarEdge.getConfig().name;
    }

    auto emitRow = [ctx](std::string& out) {
        const Row& r = ctx->row;
        if (r.n == 0) {
            return;
        }
        const double n = r.n;
        double tot = r.se;
        for (int i = 0; i < HIST_MAX_INV; i++) {
            tot += r.pac[i];
        }
        if (ctx->csv) {
            char tbuf[24];
            time_t tt = r.ts;
            struct tm tm;
            localtime_r(&tt, &tm);
            strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M", &tm);
            out += tbuf;
            out += ';';
            appendNum(out, tot / n, 0);
            if (ctx->seEnabled) {
                out += ';';
                appendNum(out, r.se / n, 0);
            }
            for (size_t i = 0; i < ctx->infos.size(); i++) {
                out += ';';
                appendNum(out, r.pac[i] / n, 0);
                for (uint8_t c = 0; c < ctx->infos[i].dcCount; c++) {
                    out += ';';
                    appendNum(out, r.pdc[i][c] / n, 0);
                }
            }
            for (size_t k = ctx->seEnabled ? 0 : 1; k <= ctx->infos.size(); k++) {
                out += ';';
                if (r.tn[k] > 0) {
                    appendNum(out, r.t[k] / r.tn[k], 1, ',');
                }
            }
            out += "\r\n";
            return;
        }
        // JSON row: [ts, total, se, inv0, inv0dc0..5, inv1, inv1dc0..5, seT, inv0T, inv1T]
        out += ctx->first ? "[" : ",[";
        ctx->first = false;
        out += std::to_string(r.ts);
        out += ',';
        appendNum(out, tot / n, 0);
        out += ',';
        appendNum(out, r.se / n, 0);
        for (int i = 0; i < HIST_MAX_INV; i++) {
            out += ',';
            appendNum(out, r.pac[i] / n, 0);
            for (int c = 0; c < HIST_MAX_DC; c++) {
                out += ',';
                appendNum(out, r.pdc[i][c] / n, 0);
            }
        }
        for (int k = 0; k <= HIST_MAX_INV; k++) {
            out += ',';
            if (r.tn[k] > 0) {
                appendNum(out, r.t[k] / r.tn[k], 1);
            } else {
                out += "null";
            }
        }
        out += ']';
    };

    auto produce = [ctx, emitRow](std::string& out) -> bool {
        if (ctx->phase == 0) {
            ctx->phase = 1;
            if (ctx->csv) {
                out += "\xEF\xBB\xBF"; // UTF-8 BOM for Excel
                out += "Czas;Razem [W]";
                if (ctx->seEnabled) {
                    out += ";" + csvName(ctx->seName) + " [W]";
                }
                for (auto& inv : ctx->infos) {
                    out += ";" + csvName(inv.name) + " [W]";
                    for (uint8_t c = 0; c < inv.dcCount; c++) {
                        out += ";" + csvName(inv.name) + " " + csvName(inv.dcName[c]) + " [W DC]";
                    }
                }
                if (ctx->seEnabled) {
                    out += ";" + csvName(ctx->seName) + " temp. [°C]";
                }
                for (auto& inv : ctx->infos) {
                    out += ";" + csvName(inv.name) + " temp. [°C]";
                }
                out += "\r\n";
            } else {
                out += "{\"step\":" + std::to_string(ctx->step) + ",\"rows\":[";
            }
            return true;
        }
        if (ctx->phase == 1) {
            // emit up to ~20 rows per call
            for (int k = 0; k < 20; k++) {
                HistSample s;
                if (!ctx->cursor->next(s)) {
                    emitRow(out);
                    ctx->row = Row();
                    ctx->phase = 2;
                    return true;
                }
                const uint32_t bucket = s.ts / ctx->step * ctx->step;
                if (ctx->row.n > 0 && bucket != ctx->row.ts) {
                    emitRow(out);
                    ctx->row = Row();
                }
                if (ctx->row.n == 0) {
                    ctx->row.ts = bucket;
                }
                ctx->row.add(s);
            }
            return true;
        }
        if (!ctx->csv) {
            out += "]}";
        }
        return false;
    };

    AsyncWebServerResponse* response = chunkedResponse(request, csv ? "text/csv; charset=utf-8" : "application/json", produce);
    if (csv) {
        char fn[96];
        snprintf(fn, sizeof(fn), "attachment; filename=\"historia_%08u-%08u.csv\"",
            static_cast<unsigned>(PvHistoryStore::localDate(from)), static_cast<unsigned>(PvHistoryStore::localDate(to)));
        response->addHeader("Content-Disposition", fn);
    }
    response->addHeader("Cache-Control", "no-cache");
    request->send(response);
}

void PvHistoryClass::onDays(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    const uint32_t from = paramU32(request, "from", 0);
    const uint32_t to = paramU32(request, "to", 99991231);
    const bool csv = paramU32(request, "csv", 0) != 0;

    struct Ctx {
        std::unique_ptr<PvHistoryStore::DayCursor> cursor;
        uint8_t phase = 0;
        bool first = true;
        bool csv;
        bool seEnabled;
        HistDay today;
        bool haveToday = false;
        std::vector<InvInfo> infos;
        String seName;
    };
    auto ctx = std::make_shared<Ctx>();
    ctx->cursor.reset(new PvHistoryStore::DayCursor(_store, from, to));
    ctx->csv = csv;
    ctx->seEnabled = SolarEdge.getConfig().enabled;
    ctx->seName = SolarEdge.getConfig().name;
    ctx->infos = inverterInfo();
    {
        std::lock_guard<std::mutex> lock(_stateMutex);
        if (_state.magic == HIST_STATE_MAGIC && _state.date >= from && _state.date <= to && _state.date != 0) {
            ctx->today = PvHistoryLogic::dayFromState(_state);
            ctx->haveToday = true;
        }
    }

    auto emit = [ctx](std::string& out, const HistDay& d, bool partial) {
        const uint32_t tot = PvHistoryLogic::totalDayWh(d);
        if (ctx->csv) {
            char buf[16];
            snprintf(buf, sizeof(buf), "%04u-%02u-%02u", static_cast<unsigned>(d.date / 10000),
                static_cast<unsigned>(d.date / 100 % 100), static_cast<unsigned>(d.date % 100));
            out += buf;
            out += ';';
            appendNum(out, tot / 1000.0, 3, ',');
            if (ctx->seEnabled) {
                out += ';';
                appendNum(out, d.seWh / 1000.0, 3, ',');
            }
            for (size_t i = 0; i < ctx->infos.size(); i++) {
                out += ';';
                appendNum(out, d.inv[i].acWh / 1000.0, 3, ',');
                for (uint8_t c = 0; c < ctx->infos[i].dcCount; c++) {
                    out += ';';
                    appendNum(out, d.inv[i].dcWh[c] / 1000.0, 3, ',');
                }
            }
            out += ';';
            out += std::to_string(d.peakW);
            out += partial ? ";tak\r\n" : ";\r\n";
            return;
        }
        // [date, total, se, inv0, inv0dc0..5, inv1, inv1dc0..5, peakW, partial]
        out += ctx->first ? "[" : ",[";
        ctx->first = false;
        out += std::to_string(d.date) + "," + std::to_string(tot) + "," + std::to_string(d.seWh);
        for (int i = 0; i < HIST_MAX_INV; i++) {
            out += "," + std::to_string(d.inv[i].acWh);
            for (int c = 0; c < HIST_MAX_DC; c++) {
                out += "," + std::to_string(d.inv[i].dcWh[c]);
            }
        }
        out += "," + std::to_string(d.peakW) + (partial ? ",1]" : ",0]");
    };

    auto produce = [ctx, emit](std::string& out) -> bool {
        if (ctx->phase == 0) {
            ctx->phase = 1;
            if (ctx->csv) {
                out += "\xEF\xBB\xBF";
                out += "Data;Razem [kWh]";
                if (ctx->seEnabled) {
                    out += ";" + csvName(ctx->seName) + " [kWh]";
                }
                for (auto& inv : ctx->infos) {
                    out += ";" + csvName(inv.name) + " [kWh]";
                    for (uint8_t c = 0; c < inv.dcCount; c++) {
                        out += ";" + csvName(inv.name) + " " + csvName(inv.dcName[c]) + " [kWh]";
                    }
                }
                out += ";Szczyt [W];Dzień w toku\r\n";
            } else {
                out += "{\"rows\":[";
            }
            return true;
        }
        if (ctx->phase == 1) {
            for (int k = 0; k < 20; k++) {
                HistDay d;
                if (!ctx->cursor->next(d)) {
                    ctx->phase = 2;
                    return true;
                }
                if (ctx->haveToday && d.date == ctx->today.date) {
                    continue; // the live record below is newer
                }
                emit(out, d, false);
            }
            return true;
        }
        if (ctx->phase == 2) {
            ctx->phase = 3;
            if (ctx->haveToday) {
                emit(out, ctx->today, true);
            }
            return true;
        }
        if (!ctx->csv) {
            out += "]}";
        }
        return false;
    };

    AsyncWebServerResponse* response = chunkedResponse(request, csv ? "text/csv; charset=utf-8" : "application/json", produce);
    if (csv) {
        response->addHeader("Content-Disposition", "attachment; filename=\"historia_dzienna.csv\"");
    }
    response->addHeader("Cache-Control", "no-cache");
    request->send(response);
}

void PvHistoryClass::onConfigGet(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    const SolarEdgeConfig cfg = SolarEdge.getConfig();
    AsyncJsonResponse* response = new AsyncJsonResponse();
    auto& root = response->getRoot();
    root["enabled"] = cfg.enabled;
    root["transport"] = cfg.transport == SolarEdgeTransport::Rtu ? "rtu" : "tcp";
    root["unit"] = cfg.unitId;
    root["name"] = String(cfg.name);
    root["interval"] = cfg.intervalSec;
    root["host"] = String(cfg.host);
    root["port"] = cfg.port;
    root["baud"] = cfg.baud;
    const char par[2] = { cfg.parity, 0 };
    root["parity"] = String(par);
    root["rx"] = cfg.rxPin;
    root["tx"] = cfg.txPin;
    root["de"] = cfg.dePin;
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvHistoryClass::onConfigPost(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentials(request)) {
        return;
    }
    AsyncJsonResponse* response = new AsyncJsonResponse();
    JsonDocument doc;
    if (!WebApi.parseRequestData(request, response, doc)) {
        return;
    }
    auto& retMsg = response->getRoot();
    auto fail = [&](const String& msg) {
        retMsg["type"] = "warning";
        retMsg["message"] = msg;
        WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
    };

    SolarEdgeConfig cfg = SolarEdge.getConfig();
    const String transport = doc["transport"] | String(cfg.transport == SolarEdgeTransport::Rtu ? "rtu" : "tcp");
    const String host = doc["host"] | String(cfg.host);
    const int port = doc["port"] | static_cast<int>(cfg.port);
    const int unit = doc["unit"] | static_cast<int>(cfg.unitId);
    const int interval = doc["interval"] | static_cast<int>(cfg.intervalSec);
    const long baud = doc["baud"] | static_cast<long>(cfg.baud);
    const String parity = doc["parity"] | String(cfg.parity);
    const int rx = doc["rx"] | static_cast<int>(cfg.rxPin);
    const int tx = doc["tx"] | static_cast<int>(cfg.txPin);
    const int de = doc["de"] | static_cast<int>(cfg.dePin);

    if (transport != "tcp" && transport != "rtu") {
        return fail("Niepoprawny typ połączenia");
    }
    if (unit < 1 || unit > 247) {
        return fail("Adres Modbus (ID) musi być w zakresie 1-247");
    }
    if (interval < 5 || interval > 300) {
        return fail("Interwał odczytu: 5-300 s");
    }
    if (rx < -1 || rx > 48 || tx < -1 || tx > 48 || de < -1 || de > 48 || baud <= 0) {
        return fail("Niepoprawne ustawienia RS485");
    }

    cfg.enabled = doc["enabled"] | cfg.enabled;
    cfg.transport = transport == "rtu" ? SolarEdgeTransport::Rtu : SolarEdgeTransport::Tcp;
    cfg.unitId = unit;
    cfg.intervalSec = interval;
    const String name = doc["name"] | String(cfg.name);
    strlcpy(cfg.name, name.length() ? name.c_str() : "SolarEdge", sizeof(cfg.name));
    cfg.baud = baud;
    cfg.parity = parity.length() ? parity[0] : 'N';
    cfg.rxPin = rx;
    cfg.txPin = tx;
    cfg.dePin = de;

    if (cfg.transport == SolarEdgeTransport::Tcp) {
        if (host.length() == 0 || host.length() >= sizeof(cfg.host) || port < 1 || port > 65535) {
            return fail("Niepoprawny adres IP lub port");
        }
        strlcpy(cfg.host, host.c_str(), sizeof(cfg.host));
        cfg.port = port;
    } else if (cfg.enabled) {
        const String err = SolarEdgeClass::validateRtu(cfg);
        if (err.length() > 0) {
            return fail(err);
        }
    }

    if (SolarEdge.setConfig(cfg)) {
        retMsg["type"] = "success";
        retMsg["message"] = "Zapisano";
    } else {
        retMsg["type"] = "danger";
        retMsg["message"] = "Błąd zapisu";
    }
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvHistoryClass::onDisplayGet(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    const PvDisplayConfig cfg = PvDisplay.getConfig();
    AsyncJsonResponse* response = new AsyncJsonResponse();
    auto& root = response->getRoot();
    root["enabled"] = cfg.enabled;
    root["clk"] = cfg.clk;
    root["mosi"] = cfg.mosi;
    root["cs"] = cfg.cs;
    root["dc"] = cfg.dc;
    root["rst"] = cfg.rst;
    root["rotation"] = cfg.rotation;
    root["contrast"] = cfg.contrast;
    root["pageSec"] = cfg.pageSec;
    root["night"] = cfg.nightMode;
    root["shift"] = cfg.shift;
    root["btn"] = cfg.btn;
    root["running"] = PvDisplay.isRunning();
    root["problem"] = PvDisplayClass::validate(cfg);
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvHistoryClass::onDisplayPost(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentials(request)) {
        return;
    }
    AsyncJsonResponse* response = new AsyncJsonResponse();
    JsonDocument doc;
    if (!WebApi.parseRequestData(request, response, doc)) {
        return;
    }
    auto& retMsg = response->getRoot();
    PvDisplayConfig cfg = PvDisplay.getConfig();
    auto pin = [&](const char* key, int8_t cur) -> int {
        const int v = doc[key] | static_cast<int>(cur);
        return (v < -1 || v > 48) ? -2 : v;
    };
    const int clk = pin("clk", cfg.clk), mosi = pin("mosi", cfg.mosi), cs = pin("cs", cfg.cs), dc = pin("dc", cfg.dc), rst = pin("rst", cfg.rst), btn = pin("btn", cfg.btn);
    const int rotation = doc["rotation"] | static_cast<int>(cfg.rotation);
    const int contrast = doc["contrast"] | static_cast<int>(cfg.contrast);
    const int pageSec = doc["pageSec"] | static_cast<int>(cfg.pageSec);
    const int night = doc["night"] | static_cast<int>(cfg.nightMode);
    if (clk == -2 || mosi == -2 || cs == -2 || dc == -2 || rst == -2 || btn == -2 || contrast < 0 || contrast > 255 || pageSec < 0 || pageSec > 120 || night < 0 || night > 2) {
        retMsg["type"] = "warning";
        retMsg["message"] = "Niepoprawne ustawienia wyświetlacza";
        WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
        return;
    }
    cfg.enabled = doc["enabled"] | cfg.enabled;
    cfg.clk = clk;
    cfg.mosi = mosi;
    cfg.cs = cs;
    cfg.dc = dc;
    cfg.rst = rst;
    cfg.btn = btn;
    cfg.rotation = rotation == 2 ? 2 : 0;
    cfg.contrast = contrast;
    cfg.pageSec = pageSec;
    cfg.nightMode = night;
    cfg.shift = doc["shift"] | cfg.shift;

    const String err = PvDisplayClass::validate(cfg);
    if (err.length() > 0) {
        retMsg["type"] = "warning";
        retMsg["message"] = err;
        WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
        return;
    }
    if (PvDisplay.setConfig(cfg)) {
        retMsg["type"] = "success";
        retMsg["message"] = cfg.enabled ? "Zapisano - wyświetlacz uruchomiony" : "Zapisano - wyświetlacz wyłączony";
    } else {
        retMsg["type"] = "danger";
        retMsg["message"] = "Błąd zapisu";
    }
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

static void screenStateJson(JsonVariant root)
{
    const PvScreenState st = PvDisplay.getScreenState();
    root["running"] = st.running;
    root["page"] = st.page;
    root["count"] = st.count;
    root["mode"] = st.mode == 2 ? "pinned" : (st.mode == 1 ? "manual" : "auto");
    root["resumeIn"] = st.resumeIn;
    root["night"] = st.night;
    auto names = root["names"].to<JsonArray>();
    for (uint8_t i = 0; i < st.count && i < 8; i++) {
        names.add(st.names[i]);
    }
}

void PvHistoryClass::onScreenGet(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    AsyncJsonResponse* response = new AsyncJsonResponse();
    screenStateJson(response->getRoot());
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

// Switching pages is harmless, so read-only access is enough (like viewing the page)
void PvHistoryClass::onScreenPost(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    AsyncJsonResponse* response = new AsyncJsonResponse();
    JsonDocument doc;
    if (!WebApi.parseRequestData(request, response, doc)) {
        return;
    }
    const String action = doc["action"] | String("");
    const int index = doc["index"] | 0;
    PvScreenCmd cmd = PvScreenCmd::None;
    if (action == "next") {
        cmd = PvScreenCmd::Next;
    } else if (action == "prev") {
        cmd = PvScreenCmd::Prev;
    } else if (action == "goto") {
        cmd = PvScreenCmd::Goto;
    } else if (action == "pin") {
        cmd = PvScreenCmd::TogglePin;
    } else if (action == "auto") {
        cmd = PvScreenCmd::Auto;
    } else if (action == "wake") {
        cmd = PvScreenCmd::Wake;
    }
    auto& root = response->getRoot();
    if (cmd == PvScreenCmd::None || index < 0 || index > 7) {
        root["type"] = "warning";
        root["message"] = "Nieznana akcja";
    } else {
        PvDisplay.command(cmd, static_cast<uint8_t>(index));
        root["type"] = "success";
    }
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvHistoryClass::onClear(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentials(request)) {
        return;
    }
    _store.clearAll();
    ESP_LOGW(TAG, "History cleared via web");
    AsyncJsonResponse* response = new AsyncJsonResponse();
    auto& retMsg = response->getRoot();
    retMsg["type"] = "success";
    retMsg["message"] = "Historia usunięta";
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}
