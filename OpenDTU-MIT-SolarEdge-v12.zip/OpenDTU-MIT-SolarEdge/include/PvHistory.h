// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * PvHistory - records production of the Hoymiles inverters (OpenDTU) and a
 * SolarEdge inverter into LittleFS and serves a statistics page at /history.
 */

#include "PvHistoryLogic.h"
#include "PvHistoryStore.h"
#include <ESPAsyncWebServer.h>
#include <TaskSchedulerDeclarations.h>
#include <mutex>

#define PV_HISTORY_SAMPLE_INTERVAL 300 // seconds between stored samples
#define PV_HISTORY_TICK_MS 10000 // reading interval used for averaging

class PvHistoryClass {
public:
    PvHistoryClass();
    void init(Scheduler& scheduler);
    void initWeb(AsyncWebServer& server);

    PvHistoryStore& store() { return _store; }
    HistState getState(); // copy of today's energy counters

private:
    void loop();
    void handleDayChange(uint32_t now, uint32_t today);
    void collect(PvHistoryLogic::Accumulator::Reading& r);
    void storeSample(uint32_t slotTs);

    void onPage(AsyncWebServerRequest* request);
    void onLive(AsyncWebServerRequest* request);
    void onSamples(AsyncWebServerRequest* request);
    void onDays(AsyncWebServerRequest* request);
    void onConfigGet(AsyncWebServerRequest* request);
    void onConfigPost(AsyncWebServerRequest* request);
    void onDisplayGet(AsyncWebServerRequest* request);
    void onDisplayPost(AsyncWebServerRequest* request);
    void onScreenGet(AsyncWebServerRequest* request);
    void onScreenPost(AsyncWebServerRequest* request);
    void onClear(AsyncWebServerRequest* request);

    Task _loopTask;
    PvHistoryStore _store;

    std::mutex _stateMutex; // protects _state
    HistState _state;
    bool _stateReady = false;

    PvHistoryLogic::Accumulator _acc;
    uint32_t _curSlot = 0;
    bool _lastSampleZero = true;
};

extern PvHistoryClass PvHistory;
