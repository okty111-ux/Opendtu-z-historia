// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * Real-time status display: 3.12" OLED 256x64 (SSD1322) over 4-wire SPI.
 * Data is collected in the main loop (cheap), drawing and the slow software
 * SPI transfer run in a separate FreeRTOS task so the radios are not delayed.
 */

#include "PvDisplayRender.h"
#include <Arduino.h>
#include <TaskSchedulerDeclarations.h>
#include <mutex>

class U8G2;

struct PvDisplayConfig {
    bool enabled = false;
    int8_t clk = -1; // SCK / D0
    int8_t mosi = -1; // SDA / DIN / D1
    int8_t cs = -1;
    int8_t dc = -1;
    int8_t rst = -1; // -1 = not connected
    uint8_t rotation = 0; // 0 or 2 (180°)
    uint8_t contrast = 160; // 0..255
    uint8_t pageSec = 6; // seconds per page, 0 = only the summary page
    uint8_t nightMode = 1; // 0 = pages as by day, 1 = dimmed clock, 2 = display off
    bool shift = true; // move content by 1-2 px against burn-in
    int8_t btn = -1; // push button to GND (internal pull-up), -1 = none
};

enum class PvScreenCmd : uint8_t {
    None,
    Next,
    Prev,
    Goto, // index = page number
    TogglePin,
    Auto,
    Wake,
};

struct PvScreenState {
    bool running = false;
    uint8_t page = 0;
    uint8_t count = 0;
    uint8_t mode = 0; // 0 = auto, 1 = manual (auto resumes), 2 = pinned
    uint16_t resumeIn = 0; // seconds until auto rotation resumes (mode 1)
    bool night = false; // night mode active (dimmed clock / off)
    char names[8][40] = {};
};

class PvDisplayClass {
public:
    PvDisplayClass();
    void init(Scheduler& scheduler);

    PvDisplayConfig getConfig();
    bool setConfig(const PvDisplayConfig& cfg);

    // Empty when the pins can be used, otherwise a reason (Polish)
    static String validate(const PvDisplayConfig& cfg);

    bool isRunning() const { return _running; }

    // Screen control from the web page (handled by the drawing task)
    void command(PvScreenCmd cmd, uint8_t index = 0);
    PvScreenState getScreenState();

private:
    void collect(); // main loop
    static void taskEntry(void* arg);
    void taskLoop();
    void updateCurve(PvDisplayData& d);
    bool loadConfig();
    bool saveConfig();

    Task _collectTask;
    std::mutex _mutex;
    PvDisplayConfig _cfg;
    PvDisplayData _data;
    volatile bool _reinit = true;
    volatile bool _running = false;

    void pollButton(const PvDisplayConfig& cfg);

    PvScreenCmd _cmd = PvScreenCmd::None; // pending command, protected by _mutex
    uint8_t _cmdIndex = 0;
    PvScreenState _screen; // protected by _mutex

    // button state (drawing task only)
    int8_t _btnPinActive = -1;
    bool _btnDown = false;
    bool _btnLongDone = false;
    uint32_t _btnChange = 0;
    uint32_t _btnPressedAt = 0;

    U8G2* _u8g2 = nullptr;
    PvDisplayData _work; // copy used by the drawing task
    PvDisplayData _collectBuf; // built in loop()
    bool _off = false;
    uint8_t _contrastSet = 0;
    uint16_t _curve[PVD_CURVE_SLOTS] = {};
    bool _curveValid[PVD_CURVE_SLOTS] = {};
    uint32_t _curveDate = 0;
    uint32_t _curveUpdated = 0;
};

extern PvDisplayClass PvDisplay;
