// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

/*
 * PvTuya - sends the PV production (Hoymiles via OpenDTU + SolarEdge) to the
 * Tuya cloud as a "TuyaLink" device over MQTT/TLS (Tuya MQTT standard protocol).
 *
 * On the Tuya Developer Platform: create a product with "TuyaLink" as the
 * development mode, add the properties listed in pvTuyaProperties (same
 * identifiers), register a device and copy its DeviceID and DeviceSecret here.
 */

#include <Arduino.h>
#include <ESPAsyncWebServer.h>
#include <TaskSchedulerDeclarations.h>
#include <mutex>

class espMqttClientSecure;

struct PvTuyaConfig {
    bool enabled = false;
    char host[64] = "m1.tuyaeu.com"; // Central Europe data center
    uint16_t port = 8883;
    char deviceId[48] = "";
    char deviceSecret[72] = "";
    uint16_t intervalSec = 60;
    bool insecure = false; // skip TLS certificate check (fallback only)
};

enum class PvTuyaState : uint8_t {
    Disabled,
    NotConfigured,
    WaitingForNetwork,
    WaitingForTime,
    Connecting,
    Connected,
    Error,
};

struct PvTuyaStatus {
    PvTuyaState state = PvTuyaState::Disabled;
    char lastError[96] = {};
    uint32_t lastReportEpoch = 0;
    uint32_t reports = 0;
    int32_t lastResponseCode = -1; // code of the last report_response (0 = ok), -1 = none yet
    char lastResponse[96] = {};
};

struct PvTuyaProperty {
    const char* code; // property identifier on the Tuya platform
    const char* unit;
    uint8_t scale; // decimal places configured on the platform (value is sent as integer)
    const char* description; // Polish, shown on the settings page
};

extern const PvTuyaProperty pvTuyaProperties[];
extern const size_t pvTuyaPropertyCount;

class PvTuyaClass {
public:
    PvTuyaClass();
    void init(Scheduler& scheduler);
    void initWeb(AsyncWebServer& server);

    PvTuyaConfig getConfig();
    bool setConfig(const PvTuyaConfig& cfg);
    PvTuyaStatus getStatus();

private:
    void loop();
    bool loadConfig();
    bool saveConfig();
    void startConnect(const PvTuyaConfig& cfg);
    void report(const PvTuyaConfig& cfg);
    void setState(PvTuyaState s, const char* err = nullptr);

    void onGet(AsyncWebServerRequest* request);
    void onPost(AsyncWebServerRequest* request);

    Task _loopTask;
    std::mutex _mutex;
    PvTuyaConfig _cfg;
    PvTuyaStatus _status;

    espMqttClientSecure* _client = nullptr;
    volatile bool _reconfigure = false;
    volatile bool _connected = false;
    uint32_t _lastAttemptMs = 0;
    uint32_t _lastReportMs = 0;
    uint32_t _msgId = 1;

    // espMqttClient keeps pointers to these, so they must outlive the connection
    String _clientId;
    String _username;
    String _password;
    String _hostCopy;
    String _respTopic;
};

extern PvTuyaClass PvTuya;
