// SPDX-License-Identifier: GPL-2.0-or-later
/*
 * PvUpdate - firmware update pulled from the GitHub releases of the project
 */
#include "PvUpdate.h"
#include "PvUpdateCerts.h"
#include "RestartHelper.h"
#include "WebApi.h"
#include <ArduinoJson.h>
#include <AsyncJson.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <Update.h>
#include <WiFiClientSecure.h>
#include <cctype>
#include <mbedtls/sha256.h>
#include <mbedtls/version.h>

#undef TAG
static const char* TAG = "pvupdate";

#define PV_UPDATE_CONFIG_FILE "/pvupdate.json"
static constexpr uint16_t HTTP_TIMEOUT_MS = 20000;
static constexpr uint32_t STALL_TIMEOUT_MS = 30000; // no data for this long -> abort

PvUpdateClass PvUpdate;

#if MBEDTLS_VERSION_MAJOR >= 3
#define PV_SHA256_STARTS mbedtls_sha256_starts
#define PV_SHA256_UPDATE mbedtls_sha256_update
#define PV_SHA256_FINISH mbedtls_sha256_finish
#else
#define PV_SHA256_STARTS mbedtls_sha256_starts_ret
#define PV_SHA256_UPDATE mbedtls_sha256_update_ret
#define PV_SHA256_FINISH mbedtls_sha256_finish_ret
#endif

void PvUpdateClass::init()
{
    loadConfig();
    ESP_LOGI(TAG, "Build #%u (%s), update source: %s", static_cast<unsigned>(PV_BUILD_NUMBER), PIOENV, _cfg.repo);
}

// ---------------------------------------------------------------------------

PvUpdateStatus PvUpdateClass::getStatus()
{
    std::lock_guard<std::mutex> lock(_mutex);
    return _status;
}

PvUpdateConfig PvUpdateClass::getConfig()
{
    std::lock_guard<std::mutex> lock(_mutex);
    return _cfg;
}

bool PvUpdateClass::setConfig(const PvUpdateConfig& cfg)
{
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _cfg = cfg;
    }
    return saveConfig();
}

bool PvUpdateClass::loadConfig()
{
    File f = LittleFS.open(PV_UPDATE_CONFIG_FILE, "r", false);
    if (!f) {
        return false;
    }
    JsonDocument doc;
    const DeserializationError err = deserializeJson(doc, f);
    f.close();
    if (err) {
        return false;
    }
    std::lock_guard<std::mutex> lock(_mutex);
    strlcpy(_cfg.repo, doc["repo"] | _cfg.repo, sizeof(_cfg.repo));
    _cfg.insecure = doc["insecure"] | _cfg.insecure;
    return true;
}

bool PvUpdateClass::saveConfig()
{
    JsonDocument doc;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        doc["repo"] = _cfg.repo;
        doc["insecure"] = _cfg.insecure;
    }
    File f = LittleFS.open(PV_UPDATE_CONFIG_FILE, "w");
    if (!f) {
        return false;
    }
    const bool ok = serializeJson(doc, f) > 0;
    f.close();
    return ok;
}

void PvUpdateClass::setState(PvUpdateState s, const char* msg)
{
    std::lock_guard<std::mutex> lock(_mutex);
    _status.state = s;
    if (msg != nullptr) {
        strlcpy(_status.message, msg, sizeof(_status.message));
    }
}

void PvUpdateClass::fail(const char* msg)
{
    ESP_LOGW(TAG, "%s", msg);
    setState(PvUpdateState::Error, msg);
}

String PvUpdateClass::assetUrl(const PvUpdateConfig& cfg, const char* ext) const
{
    // e.g. https://github.com/owner/repo/releases/latest/download/opendtu-opendtufusionv2.bin
    return String("https://github.com/") + cfg.repo + "/releases/latest/download/opendtu-" + PIOENV + ext;
}

bool PvUpdateClass::startCheck() { return start(Job::Check); }
bool PvUpdateClass::startInstall() { return start(Job::Install); }

bool PvUpdateClass::start(Job job)
{
    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_busy) {
            return false;
        }
        _busy = true;
        _job = job;
        _status.done = 0;
    }
    // TLS handshake + HTTP need a large stack; runs on core 0 next to the network stack
    if (xTaskCreatePinnedToCore(taskEntry, "pvupdate", 12288, this, 1, nullptr, 0) != pdPASS) {
        _busy = false;
        fail("Nie można uruchomić zadania aktualizacji (za mało pamięci)");
        return false;
    }
    return true;
}

void PvUpdateClass::taskEntry(void* arg)
{
    auto* self = static_cast<PvUpdateClass*>(arg);
    self->run(self->_job);
    self->_busy = false;
    vTaskDelete(nullptr);
}

void PvUpdateClass::run(Job job)
{
    const PvUpdateConfig cfg = getConfig();
    setState(PvUpdateState::Checking, "Sprawdzanie najnowszej wersji na GitHubie…");

    PvUpdateInfo info;
    if (!fetchInfo(cfg, info)) {
        return; // fail() already called
    }
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _status.latest = info;
    }
    char msg[112];
    if (job == Job::Check) {
        if (info.build != 0 && info.build == PV_BUILD_NUMBER) {
            snprintf(msg, sizeof(msg), "Masz najnowszą wersję (kompilacja #%u).", static_cast<unsigned>(info.build));
        } else {
            snprintf(msg, sizeof(msg), "Dostępna kompilacja #%u.", static_cast<unsigned>(info.build));
        }
        setState(PvUpdateState::Checked, msg);
        return;
    }

    if (install(cfg, info)) {
        snprintf(msg, sizeof(msg), "Zainstalowano kompilację #%u – restart…", static_cast<unsigned>(info.build));
        setState(PvUpdateState::Done, msg);
        ESP_LOGI(TAG, "%s", msg);
        vTaskDelay(pdMS_TO_TICKS(1500));
        RestartHelper.triggerRestart();
    }
}

// Prepare a TLS client + HTTP request (follows the GitHub redirects to the download host)
static bool beginRequest(HTTPClient& http, WiFiClientSecure& client, const PvUpdateConfig& cfg, const String& url)
{
    if (cfg.insecure) {
        client.setInsecure();
    } else {
        client.setCACert(PV_UPDATE_ROOT_CAS);
    }
    client.setTimeout(HTTP_TIMEOUT_MS / 1000);
    http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
    http.setRedirectLimit(5);
    http.setTimeout(HTTP_TIMEOUT_MS);
    http.setConnectTimeout(HTTP_TIMEOUT_MS);
    http.useHTTP10(true); // no chunked transfer encoding -> plain byte stream
    http.setUserAgent("OpenDTU-PvUpdate");
    return http.begin(client, url);
}

static void httpError(char* out, size_t n, int code, bool insecure)
{
    if (code == 404) {
        snprintf(out, n, "Nie znaleziono wydania na GitHubie (404). Repozytorium musi być publiczne i mieć udaną kompilację.");
    } else if (code < 0) {
        snprintf(out, n, "Błąd połączenia: %s%s", HTTPClient::errorToString(code).c_str(),
            insecure ? "" : " (sprawdź internet; ewentualnie zaznacz „Pomiń weryfikację certyfikatu”)");
    } else {
        snprintf(out, n, "GitHub odpowiedział kodem HTTP %d", code);
    }
}

bool PvUpdateClass::fetchInfo(const PvUpdateConfig& cfg, PvUpdateInfo& info)
{
    WiFiClientSecure client;
    HTTPClient http;
    if (!beginRequest(http, client, cfg, assetUrl(cfg, ".txt"))) {
        fail("Niepoprawny adres repozytorium");
        return false;
    }
    const int code = http.GET();
    if (code != HTTP_CODE_OK) {
        char msg[112];
        httpError(msg, sizeof(msg), code, cfg.insecure);
        http.end();
        fail(msg);
        return false;
    }
    const String body = http.getString();
    http.end();

    // format: key=value lines (build, sha256, size, date)
    int pos = 0;
    while (pos < static_cast<int>(body.length())) {
        int nl = body.indexOf('\n', pos);
        if (nl < 0) {
            nl = body.length();
        }
        String line = body.substring(pos, nl);
        line.trim();
        pos = nl + 1;
        const int eq = line.indexOf('=');
        if (eq <= 0) {
            continue;
        }
        const String key = line.substring(0, eq);
        const String val = line.substring(eq + 1);
        if (key == "build") {
            info.build = strtoul(val.c_str(), nullptr, 10);
        } else if (key == "size") {
            info.size = strtoul(val.c_str(), nullptr, 10);
        } else if (key == "sha256") {
            strlcpy(info.sha256, val.c_str(), sizeof(info.sha256));
        } else if (key == "date") {
            strlcpy(info.date, val.c_str(), sizeof(info.date));
        }
    }
    bool shaOk = strlen(info.sha256) == 64;
    for (size_t i = 0; shaOk && i < 64; i++) {
        shaOk = isxdigit(static_cast<unsigned char>(info.sha256[i]));
    }
    if (info.size < 100000 || !shaOk) {
        fail("Niepoprawny opis wydania na GitHubie (brak rozmiaru lub sumy SHA-256)");
        return false;
    }
    return true;
}

bool PvUpdateClass::install(const PvUpdateConfig& cfg, const PvUpdateInfo& info)
{
    char msg[112];
    snprintf(msg, sizeof(msg), "Pobieranie kompilacji #%u…", static_cast<unsigned>(info.build));
    setState(PvUpdateState::Downloading, msg);

    WiFiClientSecure client;
    HTTPClient http;
    if (!beginRequest(http, client, cfg, assetUrl(cfg, ".bin"))) {
        fail("Niepoprawny adres repozytorium");
        return false;
    }
    const int code = http.GET();
    if (code != HTTP_CODE_OK) {
        httpError(msg, sizeof(msg), code, cfg.insecure);
        http.end();
        fail(msg);
        return false;
    }
    const int len = http.getSize();
    if (len > 0 && static_cast<uint32_t>(len) != info.size) {
        http.end();
        fail("Rozmiar pliku nie zgadza się z opisem wydania – spróbuj ponownie za chwilę");
        return false;
    }
    if (!Update.begin(info.size, U_FLASH)) {
        snprintf(msg, sizeof(msg), "Nie można rozpocząć aktualizacji: %s", Update.errorString());
        http.end();
        fail(msg);
        return false;
    }

    mbedtls_sha256_context sha;
    mbedtls_sha256_init(&sha);
    PV_SHA256_STARTS(&sha, 0);

    WiFiClient* stream = http.getStreamPtr();
    const size_t bufSize = 4096;
    uint8_t* buf = static_cast<uint8_t*>(malloc(bufSize));
    if (buf == nullptr) {
        Update.abort();
        http.end();
        fail("Za mało pamięci na bufor pobierania");
        return false;
    }

    uint32_t total = 0;
    uint32_t lastData = millis();
    bool ok = true;
    while (total < info.size) {
        const int avail = stream->available();
        if (avail > 0) {
            const size_t want = std::min<size_t>(std::min<size_t>(static_cast<size_t>(avail), bufSize), info.size - total);
            const int r = stream->read(buf, want);
            if (r <= 0) {
                vTaskDelay(pdMS_TO_TICKS(2));
                continue;
            }
            const size_t n = static_cast<size_t>(r);
            if (Update.write(buf, n) != n) {
                snprintf(msg, sizeof(msg), "Błąd zapisu do pamięci flash: %s", Update.errorString());
                ok = false;
                break;
            }
            PV_SHA256_UPDATE(&sha, buf, n);
            total += n;
            lastData = millis();
            std::lock_guard<std::mutex> lock(_mutex);
            _status.done = total;
        } else if (!stream->connected() && stream->available() == 0) {
            snprintf(msg, sizeof(msg), "Połączenie przerwane po %u z %u bajtów", static_cast<unsigned>(total), static_cast<unsigned>(info.size));
            ok = false;
            break;
        } else if (millis() - lastData > STALL_TIMEOUT_MS) {
            snprintf(msg, sizeof(msg), "Pobieranie stanęło (brak danych przez 30 s)");
            ok = false;
            break;
        } else {
            vTaskDelay(pdMS_TO_TICKS(5));
        }
    }
    free(buf);
    http.end();

    uint8_t digest[32];
    PV_SHA256_FINISH(&sha, digest);
    mbedtls_sha256_free(&sha);

    if (ok) {
        char hex[65];
        for (int i = 0; i < 32; i++) {
            snprintf(hex + 2 * i, 3, "%02x", digest[i]);
        }
        if (strcasecmp(hex, info.sha256) != 0) {
            snprintf(msg, sizeof(msg), "Suma SHA-256 się nie zgadza – plik uszkodzony, aktualizacja przerwana");
            ok = false;
        }
    }
    if (!ok) {
        Update.abort();
        fail(msg);
        return false;
    }
    if (!Update.end(true)) {
        snprintf(msg, sizeof(msg), "Nie można zakończyć aktualizacji: %s", Update.errorString());
        fail(msg);
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// Web
// ---------------------------------------------------------------------------

static const char* stateName(PvUpdateState s)
{
    switch (s) {
    case PvUpdateState::Checking:
        return "checking";
    case PvUpdateState::Checked:
        return "checked";
    case PvUpdateState::Downloading:
        return "downloading";
    case PvUpdateState::Done:
        return "done";
    case PvUpdateState::Error:
        return "error";
    default:
        return "idle";
    }
}

void PvUpdateClass::initWeb(AsyncWebServer& server)
{
    using std::placeholders::_1;
    server.on("/api/history/update", HTTP_GET, static_cast<ArRequestHandlerFunction>(std::bind(&PvUpdateClass::onGet, this, _1)));
    server.on("/api/history/update", HTTP_POST, static_cast<ArRequestHandlerFunction>(std::bind(&PvUpdateClass::onPost, this, _1)));
}

void PvUpdateClass::onGet(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentialsReadonly(request)) {
        return;
    }
    const PvUpdateStatus st = getStatus();
    const PvUpdateConfig cfg = getConfig();
    AsyncJsonResponse* response = new AsyncJsonResponse();
    auto& root = response->getRoot();
    root["state"] = stateName(st.state);
    root["busy"] = _busy;
    root["message"] = st.message;
    root["current"] = static_cast<uint32_t>(PV_BUILD_NUMBER);
    root["env"] = PIOENV;
    root["repo"] = cfg.repo;
    root["insecure"] = cfg.insecure;
    root["done"] = st.done;
    if (st.latest.build != 0 || st.latest.size != 0) {
        JsonObject l = root["latest"].to<JsonObject>();
        l["build"] = st.latest.build;
        l["size"] = st.latest.size;
        l["date"] = st.latest.date;
    }
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}

void PvUpdateClass::onPost(AsyncWebServerRequest* request)
{
    if (!WebApi.checkCredentials(request)) {
        return;
    }
    AsyncJsonResponse* response = new AsyncJsonResponse();
    JsonDocument doc;
    if (!WebApi.parseRequestData(request, response, doc)) {
        return;
    }
    auto& retMsg = response->getRoot();
    const String action = doc["action"] | String("");

    if (action == "config") {
        PvUpdateConfig cfg = getConfig();
        String repo = doc["repo"] | String(cfg.repo);
        repo.trim();
        repo.replace("https://github.com/", "");
        repo.replace("github.com/", "");
        while (repo.endsWith("/")) {
            repo.remove(repo.length() - 1);
        }
        const int slash = repo.indexOf('/');
        if (slash <= 0 || slash != repo.lastIndexOf('/') || slash == static_cast<int>(repo.length()) - 1 || repo.length() >= sizeof(cfg.repo) || repo.indexOf(' ') >= 0) {
            retMsg["type"] = "warning";
            retMsg["message"] = "Podaj repozytorium w formie login/nazwa";
        } else {
            strlcpy(cfg.repo, repo.c_str(), sizeof(cfg.repo));
            cfg.insecure = doc["insecure"] | cfg.insecure;
            const bool ok = setConfig(cfg);
            retMsg["type"] = ok ? "success" : "danger";
            retMsg["message"] = ok ? "Zapisano" : "Błąd zapisu";
        }
    } else if (action == "check" || action == "install") {
        const bool started = action == "check" ? startCheck() : startInstall();
        retMsg["type"] = started ? "success" : "warning";
        retMsg["message"] = started ? "Uruchomiono" : "Aktualizacja już trwa";
    } else {
        retMsg["type"] = "warning";
        retMsg["message"] = "Nieznana akcja";
    }
    WebApi.sendJsonResponse(request, response, __FUNCTION__, __LINE__);
}
