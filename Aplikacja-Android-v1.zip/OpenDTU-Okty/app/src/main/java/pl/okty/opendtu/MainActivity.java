package pl.okty.opendtu;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.HttpAuthHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * OpenDTU Okty - a small Android shell around the OpenDTU web interface.
 * Tries the main address first, then the optional second one (e.g. a DDNS / tunnel address).
 * Away from home the phone reaches 192.168.0.x through UniFi Teleport (WiFiman app).
 */
public class MainActivity extends Activity {

    private static final String PREFS = "opendtu";
    private static final String DEFAULT_ADDR = "http://192.168.0.222";
    private static final String WIFIMAN_PKG = "com.ubnt.usurvey";
    private static final int PROBE_TIMEOUT_MS = 4000;

    private SharedPreferences prefs;
    private WebView web;
    private ProgressBar progress;
    private LinearLayout errorBox;
    private TextView errorText;
    private TextView title;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private String base = null; // address that answered
    private boolean authTried = false;

    // ------------------------------------------------------------------ setup

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.BLACK);
        setContentView(buildLayout());
        setupWebView();
        if (savedInstanceState != null && web.restoreState(savedInstanceState) != null) {
            base = savedInstanceState.getString("base");
        } else {
            connect(startPath());
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
        outState.putString("base", base);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button barButton(String text, View.OnClickListener l) {
        Button b = new Button(this, null, android.R.attr.borderlessButtonStyle);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setMinWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        return b;
    }

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#1c1c1e"));
        bar.setPadding(dp(8), 0, 0, 0);

        title = new TextView(this);
        title.setText("☀ OpenDTU");
        title.setTextColor(Color.parseColor("#ffc107"));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(barButton("Na żywo", v -> open("/")));
        bar.addView(barButton("Statystyki", v -> open("/history")));
        bar.addView(barButton("⟳", v -> reload()));
        Button more = barButton("⋮", null);
        more.setOnClickListener(this::showMenu);
        bar.addView(more);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setIndeterminate(false);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        FrameLayout frame = new FrameLayout(this);
        web = new WebView(this);
        frame.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        errorBox = new LinearLayout(this);
        errorBox.setOrientation(LinearLayout.VERTICAL);
        errorBox.setGravity(Gravity.CENTER);
        errorBox.setPadding(dp(24), dp(24), dp(24), dp(24));
        errorBox.setBackgroundColor(Color.parseColor("#121212"));
        errorBox.setVisibility(View.GONE);
        errorText = new TextView(this);
        errorText.setTextColor(Color.WHITE);
        errorText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        errorText.setGravity(Gravity.CENTER);
        errorBox.addView(errorText);
        Button retry = new Button(this);
        retry.setText("Spróbuj ponownie");
        retry.setOnClickListener(v -> connect(startPath()));
        errorBox.addView(retry);
        Button tp = new Button(this);
        tp.setText("Włącz Teleport (WiFiman)");
        tp.setOnClickListener(v -> openWifiman());
        errorBox.addView(tp);
        Button st = new Button(this);
        st.setText("Ustawienia adresu");
        st.setOnClickListener(v -> showSettings());
        errorBox.addView(st);
        frame.addView(errorBox, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // OpenDTU keeps the login in localStorage
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true);
        web.setBackgroundColor(Color.BLACK);

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    if (base != null && u.toString().startsWith(base)) {
                        return false; // stay inside the app
                    }
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u)); // external links (GitHub etc.)
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                authTried = false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showError("Utracono połączenie z OpenDTU.\n(" + error.getDescription() + ")");
                }
            }

            @Override
            public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
                String user = prefs.getString("user", "admin");
                String pass = prefs.getString("pass", "");
                if (!authTried && !pass.isEmpty()) {
                    authTried = true;
                    handler.proceed(user, pass);
                } else {
                    askCredentials(handler);
                }
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mimeType);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                String pass = prefs.getString("pass", "");
                if (!pass.isEmpty()) {
                    String token = prefs.getString("user", "admin") + ":" + pass;
                    r.addRequestHeader("Authorization", "Basic " + Base64.encodeToString(token.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP));
                }
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Pobieranie: " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Nie udało się pobrać pliku: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    // ------------------------------------------------------------------ connection

    private String startPath() {
        return prefs.getString("start", "/");
    }

    private static String clean(String a) {
        a = a == null ? "" : a.trim();
        if (a.isEmpty()) {
            return a;
        }
        if (!a.startsWith("http://") && !a.startsWith("https://")) {
            a = "http://" + a;
        }
        while (a.endsWith("/")) {
            a = a.substring(0, a.length() - 1);
        }
        return a;
    }

    /** Finds the first address that answers, then loads the page. */
    private void connect(String path) {
        errorBox.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        title.setText("☀ łączenie…");
        final String a1 = clean(prefs.getString("addr1", DEFAULT_ADDR));
        final String a2 = clean(prefs.getString("addr2", ""));
        new Thread(() -> {
            String ok = null;
            if (!a1.isEmpty() && probe(a1)) {
                ok = a1;
            } else if (!a2.isEmpty() && probe(a2)) {
                ok = a2;
            }
            final String found = ok;
            ui.post(() -> {
                progress.setIndeterminate(false);
                if (found == null) {
                    title.setText("☀ OpenDTU");
                    showError("Nie można połączyć się z OpenDTU (" + a1 + ").\n\n"
                            + "Jeśli jesteś poza domem, włącz Teleport w aplikacji WiFiman i spróbuj ponownie.");
                } else {
                    base = found;
                    title.setText(found.equals(a1) ? "☀ OpenDTU" : "☀ OpenDTU (adres 2)");
                    web.loadUrl(base + path);
                }
            });
        }).start();
    }

    private static boolean probe(String addr) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(addr + "/api/system/status").openConnection();
            c.setConnectTimeout(PROBE_TIMEOUT_MS);
            c.setReadTimeout(PROBE_TIMEOUT_MS);
            c.setInstanceFollowRedirects(false);
            int code = c.getResponseCode();
            return code > 0; // any HTTP answer (also 401) means OpenDTU is reachable
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }

    private void open(String path) {
        if (base == null) {
            connect(path);
        } else {
            errorBox.setVisibility(View.GONE);
            web.loadUrl(base + path);
        }
    }

    private void reload() {
        if (base == null || errorBox.getVisibility() == View.VISIBLE) {
            connect(startPath());
        } else {
            web.reload();
        }
    }

    private void showError(String msg) {
        errorText.setText(msg);
        errorBox.setVisibility(View.VISIBLE);
    }

    private void openWifiman() {
        Intent i = getPackageManager().getLaunchIntentForPackage(WIFIMAN_PKG);
        try {
            if (i != null) {
                startActivity(i);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + WIFIMAN_PKG)));
            }
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + WIFIMAN_PKG)));
        }
    }

    // ------------------------------------------------------------------ menu & dialogs

    private void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Ustawienia adresu");
        m.getMenu().add(0, 2, 0, "Włącz Teleport (WiFiman)");
        m.getMenu().add(0, 3, 0, "Otwórz w przeglądarce");
        m.getMenu().add(0, 4, 0, "O aplikacji");
        m.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
            case 1:
                showSettings();
                return true;
            case 2:
                openWifiman();
                return true;
            case 3:
                String u = web.getUrl() != null ? web.getUrl() : clean(prefs.getString("addr1", DEFAULT_ADDR));
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            case 4:
                showAbout();
                return true;
            default:
                return false;
            }
        });
        m.show();
    }

    private EditText field(LinearLayout parent, String label, String value, String hint, int inputType) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setPadding(0, dp(10), 0, 0);
        parent.addView(t);
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(inputType);
        parent.addView(e);
        return e;
    }

    private void showSettings() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final int uriType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI;
        EditText a1 = field(l, "Adres OpenDTU", prefs.getString("addr1", DEFAULT_ADDR), DEFAULT_ADDR, uriType);
        EditText a2 = field(l, "Adres zapasowy (opcjonalnie)", prefs.getString("addr2", ""), "np. adres z tunelu / DDNS", uriType);
        CheckBox hist = new CheckBox(this);
        hist.setText("Po uruchomieniu otwieraj Statystyki PV");
        hist.setChecked("/history".equals(startPath()));
        l.addView(hist);
        TextView info = new TextView(this);
        info.setText("Poza domem: włącz Teleport w aplikacji WiFiman – wtedy adres 192.168.0.222 działa jak w domu.");
        info.setPadding(0, dp(12), 0, 0);
        l.addView(info);

        new AlertDialog.Builder(this)
                .setTitle("Ustawienia")
                .setView(l)
                .setPositiveButton("Zapisz", (d, w) -> {
                    prefs.edit()
                            .putString("addr1", clean(a1.getText().toString()).isEmpty() ? DEFAULT_ADDR : clean(a1.getText().toString()))
                            .putString("addr2", clean(a2.getText().toString()))
                            .putString("start", hist.isChecked() ? "/history" : "/")
                            .apply();
                    base = null;
                    connect(startPath());
                })
                .setNeutralButton("Zapomnij hasło", (d, w) -> {
                    prefs.edit().remove("pass").apply();
                    Toast.makeText(this, "Usunięto zapisane hasło", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void askCredentials(HttpAuthHandler handler) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        EditText u = field(l, "Użytkownik", prefs.getString("user", "admin"), "admin", InputType.TYPE_CLASS_TEXT);
        EditText p = field(l, "Hasło OpenDTU", "", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        CheckBox remember = new CheckBox(this);
        remember.setText("Zapamiętaj w telefonie");
        remember.setChecked(true);
        l.addView(remember);
        new AlertDialog.Builder(this)
                .setTitle("Logowanie do OpenDTU")
                .setView(l)
                .setCancelable(false)
                .setPositiveButton("Zaloguj", (d, w) -> {
                    String user = u.getText().toString().trim();
                    String pass = p.getText().toString();
                    SharedPreferences.Editor e = prefs.edit().putString("user", user);
                    if (remember.isChecked()) {
                        e.putString("pass", pass);
                    }
                    e.apply();
                    authTried = true;
                    handler.proceed(user, pass);
                })
                .setNegativeButton("Anuluj", (d, w) -> handler.cancel())
                .show();
    }

    private void showAbout() {
        String version = "";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        new AlertDialog.Builder(this)
                .setTitle("OpenDTU Okty " + version)
                .setMessage("Podgląd OpenDTU (Hoymiles MIT + SolarEdge) na telefonie.\n\n"
                        + "Przygotował Okty na podstawie dostępnych materiałów z GitHub "
                        + "(OpenDTU, licencja GPL-2.0).")
                .setPositiveButton("OK", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        if (errorBox.getVisibility() == View.VISIBLE) {
            super.onBackPressed();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
